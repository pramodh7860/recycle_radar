import { useState, useCallback, useEffect } from 'react';
import VoiceRecorder from '../utils/voiceRecorder';

interface UseVoiceRecorderOptions {
  maxDuration?: number; // in seconds
}

export default function useVoiceRecorder(options: UseVoiceRecorderOptions = {}) {
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingTime, setRecordingTime] = useState<number>(0);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  
  // Cleanup audio URL on unmount
  useEffect(() => {
    return () => {
      if (audioUrl) {
        URL.revokeObjectURL(audioUrl);
      }
    };
  }, [audioUrl]);
  
  // Create recorder instance
  const recorder = new VoiceRecorder({
    maxDuration: options.maxDuration || 60,
    onStart: () => {
      setIsRecording(true);
      setRecordingTime(0);
    },
    onStop: (blob) => {
      setIsRecording(false);
      setAudioBlob(blob);
      if (audioUrl) {
        URL.revokeObjectURL(audioUrl);
      }
      setAudioUrl(URL.createObjectURL(blob));
    },
    onError: (error) => {
      console.error('Recording error:', error);
      setIsRecording(false);
    }
  });
  
  // Update recording time
  useEffect(() => {
    let interval: number | null = null;
    
    if (isRecording) {
      interval = window.setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);
    }
    
    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [isRecording]);
  
  // Start recording
  const startRecording = useCallback(async () => {
    setAudioBlob(null);
    setAudioUrl(null);
    await recorder.start();
  }, [recorder]);
  
  // Stop recording
  const stopRecording = useCallback(async () => {
    await recorder.stop();
  }, [recorder]);
  
  // Cancel recording
  const cancelRecording = useCallback(() => {
    recorder.cancel();
    setIsRecording(false);
    setRecordingTime(0);
    setAudioBlob(null);
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
      setAudioUrl(null);
    }
  }, [recorder, audioUrl]);
  
  // Format recording time as MM:SS
  const formattedTime = useCallback(() => {
    const minutes = Math.floor(recordingTime / 60);
    const seconds = recordingTime % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }, [recordingTime]);
  
  return {
    isRecording,
    recordingTime,
    formattedTime,
    audioBlob,
    audioUrl,
    startRecording,
    stopRecording,
    cancelRecording
  };
}