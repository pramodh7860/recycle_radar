import { useState, useEffect } from 'react';
import { 
  isOnline, 
  setupNetworkListeners, 
  saveOfflineAction, 
  getPendingOfflineActions, 
  syncOfflineActions,
  cacheData,
  getCachedData
} from '../utils/offlineHandler';
import { OfflineAction } from '../types';

interface UseOfflineOptions {
  onSync?: () => void;
  processFn?: (action: OfflineAction) => Promise<void>;
}

export default function useOffline(options: UseOfflineOptions = {}) {
  const [online, setOnline] = useState<boolean>(isOnline());
  const [syncing, setSyncing] = useState<boolean>(false);
  const [pendingActions, setPendingActions] = useState<number>(0);
  
  // Load pending actions count
  useEffect(() => {
    const loadPendingActions = async () => {
      const actions = await getPendingOfflineActions();
      setPendingActions(actions.length);
    };
    
    loadPendingActions();
  }, []);
  
  // Handle online/offline events
  useEffect(() => {
    const handleOnline = async () => {
      setOnline(true);
      
      if (options.processFn) {
        setSyncing(true);
        try {
          await syncOfflineActions(options.processFn);
          const actions = await getPendingOfflineActions();
          setPendingActions(actions.length);
          
          if (options.onSync) {
            options.onSync();
          }
        } catch (error) {
          console.error('Error syncing offline actions:', error);
        } finally {
          setSyncing(false);
        }
      }
    };
    
    const handleOffline = () => {
      setOnline(false);
    };
    
    const cleanup = setupNetworkListeners(handleOnline, handleOffline);
    return cleanup;
  }, [options]);
  
  // Save an offline action
  const saveAction = async (
    type: 'create' | 'update' | 'delete',
    collection: string,
    data: any
  ): Promise<string> => {
    const actionId = await saveOfflineAction({
      type,
      collection,
      data
    });
    
    setPendingActions(prev => prev + 1);
    return actionId;
  };
  
  // Sync pending actions manually
  const syncActions = async (): Promise<boolean> => {
    if (!online || !options.processFn) {
      return false;
    }
    
    setSyncing(true);
    try {
      const success = await syncOfflineActions(options.processFn);
      const actions = await getPendingOfflineActions();
      setPendingActions(actions.length);
      
      if (options.onSync) {
        options.onSync();
      }
      
      return success;
    } catch (error) {
      console.error('Error syncing offline actions:', error);
      return false;
    } finally {
      setSyncing(false);
    }
  };
  
  return {
    online,
    syncing,
    pendingActions,
    saveAction,
    syncActions,
    cacheData,
    getCachedData
  };
}