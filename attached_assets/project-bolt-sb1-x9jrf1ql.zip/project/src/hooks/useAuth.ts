import { useState, useEffect, createContext, useContext } from 'react';
import { User as FirebaseUser } from 'firebase/auth';
import { auth, getUserProfile, loginWithEmail, registerWithEmail, logoutUser } from '../utils/firebase';
import { User, UserRole, Language } from '../types';

interface AuthContextType {
  currentUser: FirebaseUser | null;
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<User | null>;
  register: (email: string, password: string, name: string, role: UserRole, language: Language) => Promise<User | null>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  currentUser: null,
  user: null,
  loading: true,
  login: async () => null,
  register: async () => null,
  logout: async () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (firebaseUser) => {
      setCurrentUser(firebaseUser);
      
      if (firebaseUser) {
        const userProfile = await getUserProfile(firebaseUser.uid);
        if (userProfile) {
          setUser(userProfile);
        }
      } else {
        setUser(null);
      }
      
      setLoading(false);
    });
    
    return unsubscribe;
  }, []);

  const login = async (email: string, password: string): Promise<User | null> => {
    try {
      const firebaseUser = await loginWithEmail(email, password);
      const userProfile = await getUserProfile(firebaseUser.uid);
      setUser(userProfile);
      return userProfile;
    } catch (error) {
      console.error('Login error:', error);
      return null;
    }
  };

  const register = async (
    email: string, 
    password: string, 
    name: string, 
    role: UserRole,
    language: Language
  ): Promise<User | null> => {
    try {
      const firebaseUser = await registerWithEmail(email, password, name, role, language);
      const userProfile = await getUserProfile(firebaseUser.uid);
      setUser(userProfile);
      return userProfile;
    } catch (error) {
      console.error('Registration error:', error);
      return null;
    }
  };

  const logout = async (): Promise<void> => {
    try {
      await logoutUser();
      setUser(null);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const contextValue = {
    currentUser,
    user,
    loading,
    login,
    register,
    logout,
  };

  return <AuthContext.Provider value={contextValue}>{children}</AuthContext.Provider>;
};

export default function useAuth() {
  return useContext(AuthContext);
}