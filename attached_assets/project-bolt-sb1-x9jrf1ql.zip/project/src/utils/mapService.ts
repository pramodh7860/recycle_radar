import { GeoPoint } from '../types';
import { getCachedData, cacheData } from './offlineHandler';

// Interface for location search result
interface LocationSearchResult {
  id: string;
  name: string;
  address: string;
  location: GeoPoint;
}

// Cache keys
const CACHED_MAPS_KEY = 'cached_maps';
const CACHED_LOCATIONS_KEY = 'cached_locations';

// Get current user location
export const getCurrentLocation = (): Promise<GeoPoint> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by your browser'));
      return;
    }
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const geoPoint: GeoPoint = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        };
        
        // Cache the user's location
        cacheData('user_location', geoPoint);
        
        resolve(geoPoint);
      },
      (error) => {
        console.error('Error getting location:', error);
        
        // Try to get cached location
        getCachedData<GeoPoint>('user_location')
          .then(cachedLocation => {
            if (cachedLocation) {
              resolve(cachedLocation);
            } else {
              // Default to a central location if no cached location
              reject(new Error('Could not get your location'));
            }
          })
          .catch(err => {
            reject(err);
          });
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000 // 1 minute
      }
    );
  });
};

// Calculate distance between two points
export const calculateDistance = (point1: GeoPoint, point2: GeoPoint): number => {
  // Haversine formula to calculate distance between two points
  const R = 6371; // Radius of the Earth in km
  const dLat = deg2rad(point2.latitude - point1.latitude);
  const dLon = deg2rad(point2.longitude - point1.longitude);
  
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(point1.latitude)) * Math.cos(deg2rad(point2.latitude)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
    
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c; // Distance in km
  
  return distance;
};

// Convert degrees to radians
const deg2rad = (deg: number): number => {
  return deg * (Math.PI / 180);
};

// Get nearby points of interest within a radius
export const getNearbyPoints = async (
  center: GeoPoint,
  radiusKm: number,
  points: { location: GeoPoint; [key: string]: any }[]
): Promise<any[]> => {
  return points.filter(point => {
    const distance = calculateDistance(center, point.location);
    return distance <= radiusKm;
  }).sort((a, b) => {
    const distanceA = calculateDistance(center, a.location);
    const distanceB = calculateDistance(center, b.location);
    return distanceA - distanceB;
  });
};

// Search for a location by text
export const searchLocation = async (query: string): Promise<LocationSearchResult[]> => {
  try {
    // This is a placeholder for integrating with the Google Places API
    // In a real implementation, you would make an API call to a geocoding service
    
    // For now, return cached locations if offline
    if (!navigator.onLine) {
      const cachedLocations = await getCachedData<LocationSearchResult[]>(CACHED_LOCATIONS_KEY) || [];
      return cachedLocations.filter(location => 
        location.name.toLowerCase().includes(query.toLowerCase()) ||
        location.address.toLowerCase().includes(query.toLowerCase())
      );
    }
    
    // Mock implementation - would be replaced with actual API call
    const mockResults: LocationSearchResult[] = [
      {
        id: '1',
        name: 'Central Market',
        address: '123 Main St, City',
        location: { latitude: 28.6139, longitude: 77.2090 }
      },
      {
        id: '2',
        name: 'Tech Hub',
        address: '456 Innovation Ave, Town',
        location: { latitude: 12.9716, longitude: 77.5946 }
      }
    ];
    
    // Cache the results for offline use
    cacheData(CACHED_LOCATIONS_KEY, mockResults);
    
    return mockResults.filter(location => 
      location.name.toLowerCase().includes(query.toLowerCase()) ||
      location.address.toLowerCase().includes(query.toLowerCase())
    );
  } catch (error) {
    console.error('Error searching location:', error);
    return [];
  }
};

// Get address from coordinates (reverse geocoding)
export const getAddressFromCoordinates = async (location: GeoPoint): Promise<string> => {
  try {
    // This is a placeholder for integrating with the Google Geocoding API
    // In a real implementation, you would make an API call to a geocoding service
    
    // Mock implementation - would be replaced with actual API call
    return `Near ${location.latitude.toFixed(4)}, ${location.longitude.toFixed(4)}`;
  } catch (error) {
    console.error('Error getting address:', error);
    return `Location (${location.latitude.toFixed(4)}, ${location.longitude.toFixed(4)})`;
  }
};

// Cache map tile for offline use
export const cacheMapTile = async (tileUrl: string, tileData: Blob) => {
  try {
    const cachedMaps = await getCachedData<Record<string, string>>(CACHED_MAPS_KEY) || {};
    
    // Convert blob to base64 for storage
    const base64 = await blobToBase64(tileData);
    cachedMaps[tileUrl] = base64;
    
    await cacheData(CACHED_MAPS_KEY, cachedMaps);
  } catch (error) {
    console.error('Error caching map tile:', error);
  }
};

// Get cached map tile
export const getCachedMapTile = async (tileUrl: string): Promise<Blob | null> => {
  try {
    const cachedMaps = await getCachedData<Record<string, string>>(CACHED_MAPS_KEY) || {};
    const base64 = cachedMaps[tileUrl];
    
    if (!base64) {
      return null;
    }
    
    // Convert base64 back to blob
    return base64ToBlob(base64, 'image/png');
  } catch (error) {
    console.error('Error getting cached map tile:', error);
    return null;
  }
};

// Helper to convert blob to base64
const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

// Helper to convert base64 to blob
const base64ToBlob = (base64: string, mimeType: string): Blob => {
  const byteString = atob(base64.split(',')[1]);
  const ab = new ArrayBuffer(byteString.length);
  const ia = new Uint8Array(ab);
  
  for (let i = 0; i < byteString.length; i++) {
    ia[i] = byteString.charCodeAt(i);
  }
  
  return new Blob([ab], { type: mimeType });
};