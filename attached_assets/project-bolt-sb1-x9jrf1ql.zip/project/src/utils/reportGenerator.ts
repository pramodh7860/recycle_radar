import { jsPDF } from 'jspdf';
import { FeasibilityResult, SubsidyLink } from '../types';
import { translate } from './languageService';

export const generateFeasibilityReport = (result: FeasibilityResult): Blob => {
  const doc = new jsPDF();
  
  // Add a title
  doc.setFontSize(20);
  doc.setTextColor(46, 125, 50); // primary color
  doc.text('RecycleRadar - Feasibility Report', 105, 20, { align: 'center' });
  
  doc.setDrawColor(46, 125, 50); // primary color
  doc.line(20, 25, 190, 25);
  
  // Add date
  doc.setFontSize(10);
  doc.setTextColor(100);
  doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 20, 35);
  
  // Input summary
  doc.setFontSize(16);
  doc.setTextColor(0);
  doc.text('Input Summary', 20, 45);
  
  doc.setFontSize(12);
  doc.text(`Budget: ₹${result.input.budget.toLocaleString()}`, 25, 55);
  doc.text(`Location: ${result.input.location}`, 25, 65);
  doc.text(`Material Type: ${result.input.materialType.join(', ')}`, 25, 75);
  doc.text(`Scale: ${result.input.scalePlan}`, 25, 85);
  doc.text(`Existing Infrastructure: ${result.input.existingInfrastructure ? 'Yes' : 'No'}`, 25, 95);
  if (result.input.employmentGoal) {
    doc.text(`Employment Goal: ${result.input.employmentGoal} people`, 25, 105);
  }
  
  // Recommendations
  let yPos = 120;
  
  doc.setFontSize(16);
  doc.setTextColor(0);
  doc.text('Recommendations', 20, yPos);
  yPos += 10;
  
  result.recommendations.forEach((rec, index) => {
    // Check if we need a new page
    if (yPos > 250) {
      doc.addPage();
      yPos = 20;
    }
    
    doc.setFontSize(14);
    doc.setTextColor(46, 125, 50); // primary color
    doc.text(`${index + 1}. ${rec.unitType}`, 25, yPos);
    yPos += 10;
    
    doc.setFontSize(12);
    doc.setTextColor(0);
    
    // Description with text wrapping
    const description = doc.splitTextToSize(rec.description, 160);
    doc.text(description, 30, yPos);
    yPos += description.length * 7;
    
    // Cost & ROI
    doc.text(`Estimated Cost: ₹${rec.estimatedCost.toLocaleString()}`, 30, yPos);
    yPos += 7;
    doc.text(`Estimated ROI: ${rec.estimatedRoi}%`, 30, yPos);
    yPos += 7;
    doc.text(`Timeline: ${rec.timelineMonths} months`, 30, yPos);
    yPos += 7;
    doc.text(`Required Area: ${rec.requiredArea} sq. meters`, 30, yPos);
    yPos += 7;
    
    // Resources
    doc.text('Required Resources:', 30, yPos);
    yPos += 7;
    rec.requiredResources.forEach(resource => {
      doc.text(`- ${resource}`, 35, yPos);
      yPos += 7;
    });
    
    // Challenges
    doc.text('Potential Challenges:', 30, yPos);
    yPos += 7;
    rec.challenges.forEach(challenge => {
      doc.text(`- ${challenge}`, 35, yPos);
      yPos += 7;
    });
    
    yPos += 10;
  });
  
  // Subsidy information
  if (yPos > 220) {
    doc.addPage();
    yPos = 20;
  }
  
  doc.setFontSize(16);
  doc.setTextColor(0);
  doc.text('Available Subsidies & Support', 20, yPos);
  yPos += 10;
  
  result.subsidyLinks.forEach((subsidy, index) => {
    // Check if we need a new page
    if (yPos > 250) {
      doc.addPage();
      yPos = 20;
    }
    
    doc.setFontSize(14);
    doc.setTextColor(21, 101, 192); // secondary color
    doc.text(`${index + 1}. ${subsidy.name}`, 25, yPos);
    yPos += 7;
    
    doc.setFontSize(12);
    doc.setTextColor(0);
    doc.text(`Provider: ${subsidy.provider}`, 30, yPos);
    yPos += 7;
    
    // Description with text wrapping
    const description = doc.splitTextToSize(subsidy.description, 160);
    doc.text(description, 30, yPos);
    yPos += description.length * 7;
    
    // Eligibility
    const eligibility = doc.splitTextToSize(`Eligibility: ${subsidy.eligibility}`, 160);
    doc.text(eligibility, 30, yPos);
    yPos += eligibility.length * 7;
    
    // URL
    doc.setTextColor(21, 101, 192); // secondary color
    doc.text(`URL: ${subsidy.url}`, 30, yPos);
    yPos += 12;
  });
  
  // Footer
  const pageCount = doc.getNumberOfPages();
  
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text(`Page ${i} of ${pageCount}`, 105, 290, { align: 'center' });
    doc.text('RecycleRadar © 2025', 190, 290, { align: 'right' });
  }
  
  return doc.output('blob');
};

// Download the generated report
export const downloadReport = (result: FeasibilityResult) => {
  const blob = generateFeasibilityReport(result);
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement('a');
  a.href = url;
  a.download = `RecycleRadar_Feasibility_Report_${new Date().toISOString().split('T')[0]}.pdf`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

// Generate subsidy recommendations based on input
export const generateSubsidyRecommendations = (
  budget: number,
  materialType: string[],
  scale: string,
  location: string
): SubsidyLink[] => {
  // This is a placeholder for a more complex recommendation engine
  // In a real implementation, you would have a database of subsidies and match based on criteria
  
  const subsidies: SubsidyLink[] = [
    {
      name: 'MSME Technology Upgrade Scheme',
      provider: 'Ministry of Micro, Small & Medium Enterprises',
      description: 'Financial assistance for technology upgradation for small-scale recycling units.',
      eligibility: 'Small scale enterprises with annual turnover less than ₹5 crore.',
      url: 'https://msme.gov.in/schemes'
    },
    {
      name: 'Waste to Wealth Mission',
      provider: 'Department of Science & Technology',
      description: 'Support for innovative technologies that can efficiently convert waste to valuable products.',
      eligibility: 'Startups and businesses with proven waste management technologies.',
      url: 'https://dst.gov.in/waste-wealth-mission'
    }
  ];
  
  // Add location-specific subsidies
  if (location.toLowerCase().includes('tamil') || location.toLowerCase().includes('chennai')) {
    subsidies.push({
      name: 'Tamil Nadu Green Business Scheme',
      provider: 'Tamil Nadu Pollution Control Board',
      description: 'Special incentives for eco-friendly businesses operating in Tamil Nadu.',
      eligibility: 'Businesses registered in Tamil Nadu with sustainable practices.',
      url: 'https://tnpcb.gov.in/green-business'
    });
  }
  
  // Add scale-specific subsidies
  if (scale === 'small' && budget < 500000) {
    subsidies.push({
      name: 'Micro Recycling Unit Support',
      provider: 'Small Industries Development Bank of India (SIDBI)',
      description: 'Low interest loans for micro-recycling units with minimal setup requirements.',
      eligibility: 'First-time entrepreneurs with investment under ₹5 lakhs.',
      url: 'https://www.sidbi.in/en/microfinance'
    });
  }
  
  // Add material-specific subsidies
  if (materialType.some(type => type.toLowerCase().includes('plastic'))) {
    subsidies.push({
      name: 'Plastic Waste Management Fund',
      provider: 'Ministry of Environment, Forest and Climate Change',
      description: 'Financial support for innovative plastic recycling solutions.',
      eligibility: 'Businesses focused on plastic waste reduction and recycling.',
      url: 'https://moef.gov.in/plastic-waste-management'
    });
  }
  
  return subsidies;
};