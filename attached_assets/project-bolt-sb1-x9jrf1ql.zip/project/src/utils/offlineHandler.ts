import localforage from 'localforage';
import { OfflineAction } from '../types';

// Initialize localforage instances
const offlineActionsStore = localforage.createInstance({
  name: 'recycleRadar',
  storeName: 'offlineActions'
});

const dataCache = localforage.createInstance({
  name: 'recycleRadar',
  storeName: 'dataCache'
});

// Save actions performed while offline
export const saveOfflineAction = async (action: Omit<OfflineAction, 'id' | 'timestamp'>) => {
  try {
    const id = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const offlineAction: OfflineAction = {
      ...action,
      id,
      timestamp: Date.now()
    };
    
    await offlineActionsStore.setItem(id, offlineAction);
    return id;
  } catch (error) {
    console.error('Error saving offline action:', error);
    throw error;
  }
};

// Get all pending offline actions
export const getPendingOfflineActions = async (): Promise<OfflineAction[]> => {
  try {
    const actions: OfflineAction[] = [];
    await offlineActionsStore.iterate((value: OfflineAction) => {
      actions.push(value);
    });
    return actions.sort((a, b) => a.timestamp - b.timestamp);
  } catch (error) {
    console.error('Error getting pending offline actions:', error);
    return [];
  }
};

// Remove an offline action after it has been processed
export const removeOfflineAction = async (id: string) => {
  try {
    await offlineActionsStore.removeItem(id);
  } catch (error) {
    console.error('Error removing offline action:', error);
    throw error;
  }
};

// Cache data for offline use
export const cacheData = async <T>(key: string, data: T) => {
  try {
    await dataCache.setItem(key, data);
  } catch (error) {
    console.error('Error caching data:', error);
    throw error;
  }
};

// Get cached data
export const getCachedData = async <T>(key: string): Promise<T | null> => {
  try {
    return await dataCache.getItem<T>(key);
  } catch (error) {
    console.error('Error getting cached data:', error);
    return null;
  }
};

// Check if we're online
export const isOnline = (): boolean => {
  return navigator.onLine;
};

// Network status listener setup
export const setupNetworkListeners = (onOnline: () => void, onOffline: () => void) => {
  window.addEventListener('online', onOnline);
  window.addEventListener('offline', onOffline);
  
  return () => {
    window.removeEventListener('online', onOnline);
    window.removeEventListener('offline', onOffline);
  };
};

// Sync offline actions when we're back online
export const syncOfflineActions = async (processFn: (action: OfflineAction) => Promise<void>) => {
  if (!isOnline()) {
    return false;
  }
  
  const pendingActions = await getPendingOfflineActions();
  
  if (pendingActions.length === 0) {
    return true;
  }
  
  const results = await Promise.allSettled(
    pendingActions.map(async (action) => {
      try {
        await processFn(action);
        await removeOfflineAction(action.id);
        return true;
      } catch (error) {
        console.error(`Error processing offline action ${action.id}:`, error);
        return false;
      }
    })
  );
  
  return results.every((result) => result.status === 'fulfilled' && result.value === true);
};