import RecordRTC, { StereoAudioRecorder } from 'recordrtc';

interface VoiceRecorderOptions {
  onStart?: () => void;
  onStop?: (blob: Blob) => void;
  onError?: (error: Error) => void;
  maxDuration?: number; // in seconds
}

class VoiceRecorder {
  private recorder: RecordRTC | null = null;
  private stream: MediaStream | null = null;
  private timer: number | null = null;
  private options: VoiceRecorderOptions;
  
  constructor(options: VoiceRecorderOptions = {}) {
    this.options = {
      maxDuration: 60, // Default max duration: 60 seconds
      ...options
    };
  }
  
  async start() {
    try {
      if (this.recorder) {
        this.stop();
      }
      
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: true
      });
      
      this.recorder = new RecordRTC(this.stream, {
        type: 'audio',
        mimeType: 'audio/webm',
        recorderType: StereoAudioRecorder,
        numberOfAudioChannels: 1,
        desiredSampRate: 16000, // Lower sample rate for smaller file size
        disableLogs: true
      });
      
      this.recorder.startRecording();
      
      if (this.options.onStart) {
        this.options.onStart();
      }
      
      // Set a timer for max duration
      if (this.options.maxDuration) {
        this.timer = window.setTimeout(() => {
          this.stop();
        }, this.options.maxDuration * 1000);
      }
    } catch (error) {
      if (this.options.onError) {
        this.options.onError(error as Error);
      }
      console.error('Error starting voice recording:', error);
    }
  }
  
  stop() {
    return new Promise<Blob>((resolve, reject) => {
      if (!this.recorder) {
        reject(new Error('No recording in progress'));
        return;
      }
      
      if (this.timer) {
        clearTimeout(this.timer);
        this.timer = null;
      }
      
      this.recorder.stopRecording(() => {
        const blob = this.recorder!.getBlob();
        
        // Stop and release the microphone
        if (this.stream) {
          this.stream.getTracks().forEach(track => track.stop());
          this.stream = null;
        }
        
        this.recorder = null;
        
        if (this.options.onStop) {
          this.options.onStop(blob);
        }
        
        resolve(blob);
      });
    });
  }
  
  isRecording(): boolean {
    return !!this.recorder;
  }
  
  cancel() {
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
    
    if (this.recorder) {
      this.recorder.reset();
      this.recorder = null;
    }
  }
}

export default VoiceRecorder;