import { Language } from '../types';

interface TranslationObject {
  [key: string]: string;
}

interface Translations {
  [Language.ENGLISH]: TranslationObject;
  [Language.HINDI]: TranslationObject;
  [Language.TAMIL]: TranslationObject;
  [Language.TELUGU]: TranslationObject;
}

// Language translations
const translations: Translations = {
  [Language.ENGLISH]: {
    // Auth & Onboarding
    'welcome': 'Welcome to RecycleRadar',
    'chooseRole': 'Choose your role',
    'vendor': 'Waste Vendor',
    'factoryOwner': 'Factory Owner',
    'entrepreneur': 'Entrepreneur',
    'selectLanguage': 'Select language',
    'next': 'Next',
    'back': 'Back',
    'login': 'Login',
    'register': 'Register',
    'forgotPassword': 'Forgot password?',
    'name': 'Name',
    'email': 'Email',
    'phone': 'Phone',
    'password': 'Password',
    'confirmPassword': 'Confirm password',
    
    // Dashboard & Navigation
    'dashboard': 'Dashboard',
    'profile': 'Profile',
    'logout': 'Logout',
    'messages': 'Messages',
    'listings': 'Listings',
    'needs': 'Material Needs',
    'feasibility': 'Feasibility Check',
    
    // Vendor specific
    'uploadWaste': 'Upload Waste',
    'myListings': 'My Listings',
    'findFactories': 'Find Factories',
    'wasteType': 'Waste Type',
    'quantity': 'Quantity',
    'price': 'Price',
    'addPhoto': 'Add Photo',
    'recordVoice': 'Record Voice Note',
    'location': 'Location',
    
    // Factory Owner specific
    'postMaterialNeed': 'Post Material Need',
    'myNeeds': 'My Needs',
    'findVendors': 'Find Vendors',
    'materialType': 'Material Type',
    'priceOffered': 'Price Offered',
    
    // Entrepreneur specific
    'feasibilityTool': 'Feasibility Tool',
    'budget': 'Budget',
    'scale': 'Scale',
    'small': 'Small',
    'medium': 'Medium',
    'large': 'Large',
    'infrastructure': 'Existing Infrastructure',
    'generateReport': 'Generate Report',
    'recommendations': 'Recommendations',
    'subsidies': 'Subsidies',
    
    // Common actions
    'save': 'Save',
    'cancel': 'Cancel',
    'edit': 'Edit',
    'delete': 'Delete',
    'search': 'Search',
    'filter': 'Filter',
    'send': 'Send',
    'view': 'View',
    'download': 'Download',
    'share': 'Share',
    
    // Status messages
    'offline': 'You are offline',
    'syncing': 'Syncing your data...',
    'syncComplete': 'All data synced',
    'loading': 'Loading...',
    'error': 'An error occurred',
    'success': 'Success!',
    
    // Chat
    'typeMessage': 'Type your message',
    'sendPhoto': 'Send Photo',
    'sendVoice': 'Send Voice Note',
    'sendLocation': 'Send Location',
  },
  [Language.HINDI]: {
    // Basic Hindi translations - would need to be expanded
    'welcome': 'रीसाइकल रडार में आपका स्वागत है',
    'chooseRole': 'अपनी भूमिका चुनें',
    'vendor': 'कचरा विक्रेता',
    'factoryOwner': 'फैक्ट्री मालिक',
    'entrepreneur': 'उद्यमी',
    'selectLanguage': 'भाषा चुनें',
    'next': 'आगे',
    'back': 'पीछे',
    // Add more translations as needed
  },
  [Language.TAMIL]: {
    // Basic Tamil translations - would need to be expanded
    'welcome': 'ரீசைக்கிள் ரேடாருக்கு வரவேற்கிறோம்',
    'chooseRole': 'உங்கள் பாத்திரத்தைத் தேர்ந்தெடுக்கவும்',
    'vendor': 'கழிவு விற்பனையாளர்',
    'factoryOwner': 'தொழிற்சாலை உரிமையாளர்',
    'entrepreneur': 'தொழில் முனைவோர்',
    'selectLanguage': 'மொழியைத் தேர்ந்தெடுக்கவும்',
    'next': 'அடுத்து',
    'back': 'பின்',
    // Add more translations as needed
  },
  [Language.TELUGU]: {
    // Basic Telugu translations - would need to be expanded
    'welcome': 'రీసైకిల్ రాడార్‌కు స్వాగతం',
    'chooseRole': 'మీ పాత్రను ఎంచుకోండి',
    'vendor': 'వ్యర్థ విక్రేత',
    'factoryOwner': 'ఫ్యాక్టరీ యజమాని',
    'entrepreneur': 'వ్యవసాయదారుడు',
    'selectLanguage': 'భాషను ఎంచుకోండి',
    'next': 'తరువాత',
    'back': 'వెనుకకు',
    // Add more translations as needed
  }
};

// Current language - default to English
let currentLanguage = Language.ENGLISH;

// Get and set language functions
export const getCurrentLanguage = (): Language => {
  return currentLanguage;
};

export const setCurrentLanguage = (language: Language) => {
  currentLanguage = language;
  localStorage.setItem('preferredLanguage', language);
};

// Initialize language from localStorage if available
export const initializeLanguage = () => {
  const storedLanguage = localStorage.getItem('preferredLanguage') as Language;
  if (storedLanguage && Object.values(Language).includes(storedLanguage)) {
    currentLanguage = storedLanguage;
  }
};

// Get translation by key
export const translate = (key: string): string => {
  const translationsForLanguage = translations[currentLanguage] || translations[Language.ENGLISH];
  return translationsForLanguage[key] || translations[Language.ENGLISH][key] || key;
};

// Get all supported languages
export const getSupportedLanguages = (): { code: Language, name: string }[] => {
  return [
    { code: Language.ENGLISH, name: 'English' },
    { code: Language.HINDI, name: 'हिंदी' },
    { code: Language.TAMIL, name: 'தமிழ்' },
    { code: Language.TELUGU, name: 'తెలుగు' }
  ];
};