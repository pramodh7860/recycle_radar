import { initializeApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, updateProfile, PhoneAuthProvider, signInWithCredential } from 'firebase/auth';
import { getFirestore, collection, doc, setDoc, getDoc, updateDoc, query, where, getDocs, addDoc, serverTimestamp } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { User, UserRole, Language } from '../types';

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

// Authentication functions
export const registerWithEmail = async (email: string, password: string, name: string, role: UserRole, language: Language) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    await updateProfile(userCredential.user, { displayName: name });
    
    // Create user document in Firestore
    await createUserProfile(userCredential.user.uid, {
      id: userCredential.user.uid,
      name,
      email,
      role,
      preferredLanguage: language,
      createdAt: serverTimestamp()
    });
    
    return userCredential.user;
  } catch (error) {
    console.error('Error during registration:', error);
    throw error;
  }
};

export const loginWithEmail = async (email: string, password: string) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return userCredential.user;
  } catch (error) {
    console.error('Error during login:', error);
    throw error;
  }
};

export const logoutUser = async () => {
  try {
    await signOut(auth);
  } catch (error) {
    console.error('Error during logout:', error);
    throw error;
  }
};

// User profile functions
export const createUserProfile = async (userId: string, userData: Partial<User>) => {
  try {
    await setDoc(doc(db, 'users', userId), userData);
  } catch (error) {
    console.error('Error creating user profile:', error);
    throw error;
  }
};

export const getUserProfile = async (userId: string) => {
  try {
    const userDoc = await getDoc(doc(db, 'users', userId));
    if (userDoc.exists()) {
      return { id: userDoc.id, ...userDoc.data() } as User;
    }
    return null;
  } catch (error) {
    console.error('Error getting user profile:', error);
    throw error;
  }
};

export const updateUserProfile = async (userId: string, userData: Partial<User>) => {
  try {
    await updateDoc(doc(db, 'users', userId), { ...userData, updatedAt: serverTimestamp() });
  } catch (error) {
    console.error('Error updating user profile:', error);
    throw error;
  }
};

// File upload helpers
export const uploadFile = async (file: File, path: string) => {
  try {
    const storageRef = ref(storage, path);
    const snapshot = await uploadBytes(storageRef, file);
    const downloadURL = await getDownloadURL(snapshot.ref);
    return downloadURL;
  } catch (error) {
    console.error('Error uploading file:', error);
    throw error;
  }
};

// Waste listing functions
export const createWasteListing = async (wasteData: any) => {
  try {
    const listingRef = await addDoc(collection(db, 'wasteListings'), {
      ...wasteData,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      status: 'available'
    });
    return listingRef.id;
  } catch (error) {
    console.error('Error creating waste listing:', error);
    throw error;
  }
};

export const getWasteListings = async (filters?: any) => {
  try {
    let wasteQuery = collection(db, 'wasteListings');
    
    if (filters) {
      // Apply filters if provided
      wasteQuery = query(wasteQuery, ...Object.entries(filters).map(([key, value]) => 
        where(key, '==', value)
      ));
    }
    
    const querySnapshot = await getDocs(wasteQuery);
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    console.error('Error fetching waste listings:', error);
    throw error;
  }
};

// Material needs functions
export const createMaterialNeed = async (materialData: any) => {
  try {
    const needRef = await addDoc(collection(db, 'materialNeeds'), {
      ...materialData,
      createdAt: serverTimestamp(),
      status: 'active'
    });
    return needRef.id;
  } catch (error) {
    console.error('Error creating material need:', error);
    throw error;
  }
};

export const getMaterialNeeds = async (filters?: any) => {
  try {
    let needsQuery = collection(db, 'materialNeeds');
    
    if (filters) {
      // Apply filters if provided
      needsQuery = query(needsQuery, ...Object.entries(filters).map(([key, value]) => 
        where(key, '==', value)
      ));
    }
    
    const querySnapshot = await getDocs(needsQuery);
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    console.error('Error fetching material needs:', error);
    throw error;
  }
};

// Chat functions
export const createChat = async (participants: string[], participantNames: string[]) => {
  try {
    const chatRef = await addDoc(collection(db, 'chats'), {
      participantIds: participants,
      participantNames,
      unreadCount: participants.reduce((acc, id) => ({ ...acc, [id]: 0 }), {}),
      createdAt: serverTimestamp()
    });
    return chatRef.id;
  } catch (error) {
    console.error('Error creating chat:', error);
    throw error;
  }
};

export const sendMessage = async (chatId: string, senderId: string, content: string, contentType: 'text' | 'image' | 'voice' | 'location' = 'text') => {
  try {
    // Add message to messages collection
    const messageRef = await addDoc(collection(db, 'chats', chatId, 'messages'), {
      senderId,
      content,
      contentType,
      status: 'sent',
      createdAt: serverTimestamp()
    });
    
    // Update chat with last message info
    await updateDoc(doc(db, 'chats', chatId), {
      lastMessageContent: content,
      lastMessageTime: serverTimestamp()
    });
    
    return messageRef.id;
  } catch (error) {
    console.error('Error sending message:', error);
    throw error;
  }
};

export { db, auth, storage };