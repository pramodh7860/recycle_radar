export interface User {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  role: UserRole;
  preferredLanguage: Language;
  location?: GeoPoint;
  createdAt: Date | string;
  lastActive?: Date | string;
  profileImageUrl?: string;
}

export enum UserRole {
  VENDOR = 'vendor',
  FACTORY_OWNER = 'factory_owner',
  ENTREPRENEUR = 'entrepreneur'
}

export enum Language {
  ENGLISH = 'en',
  HINDI = 'hi',
  TAMIL = 'ta',
  TELUGU = 'te'
}

export interface GeoPoint {
  latitude: number;
  longitude: number;
}

export interface WasteListing {
  id: string;
  vendorId: string;
  title: string;
  description?: string;
  wasteType: string;
  quantity: number;
  unit: string;
  imageUrl?: string;
  voiceNoteUrl?: string;
  location: GeoPoint;
  price?: number;
  status: 'available' | 'pending' | 'sold';
  createdAt: Date | string;
  updatedAt: Date | string;
}

export interface MaterialNeed {
  id: string;
  factoryOwnerId: string;
  title: string;
  description?: string;
  materialType: string;
  quantity: number;
  unit: string;
  priceOffered?: number;
  location: GeoPoint;
  status: 'active' | 'fulfilled' | 'expired';
  createdAt: Date | string;
  expiresAt: Date | string;
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  content: string;
  contentType: 'text' | 'image' | 'voice' | 'location';
  status: 'sent' | 'delivered' | 'read';
  createdAt: Date | string;
}

export interface Chat {
  id: string;
  participantIds: string[];
  participantNames: string[];
  lastMessageContent?: string;
  lastMessageTime?: Date | string;
  unreadCount: Record<string, number>;
  createdAt: Date | string;
}

export interface FeasibilityInput {
  budget: number;
  location: string;
  materialType: string[];
  scalePlan: 'small' | 'medium' | 'large';
  existingInfrastructure: boolean;
  employmentGoal?: number;
}

export interface FeasibilityResult {
  id: string;
  userId: string;
  input: FeasibilityInput;
  recommendations: Recommendation[];
  subsidyLinks: SubsidyLink[];
  createdAt: Date | string;
}

export interface Recommendation {
  unitType: string;
  description: string;
  estimatedCost: number;
  estimatedRoi: number;
  timelineMonths: number;
  requiredArea: number;
  requiredResources: string[];
  challenges: string[];
}

export interface SubsidyLink {
  name: string;
  provider: string;
  description: string;
  eligibility: string;
  url: string;
}

export interface OfflineAction {
  id: string;
  type: 'create' | 'update' | 'delete';
  collection: string;
  data: any;
  timestamp: number;
}