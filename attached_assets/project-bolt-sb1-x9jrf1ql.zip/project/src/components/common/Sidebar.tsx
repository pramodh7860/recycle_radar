import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Home, 
  Trash2, 
  Factory, 
  MessageSquare, 
  FileText, 
  Settings, 
  MapPin, 
  Upload, 
  List, 
  Search, 
  Plus,
  BarChart,
  HelpCircle
} from 'lucide-react';
import { translate } from '../../utils/languageService';
import { UserRole } from '../../types';
import useAuth from '../../hooks/useAuth';

interface SidebarProps {
  isOpen: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen }) => {
  const { user } = useAuth();
  
  if (!user) return null;
  
  return (
    <aside 
      className={`fixed left-0 top-16 bottom-0 w-64 bg-white dark:bg-gray-800 shadow-md z-20 transition-transform duration-300 transform ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      } md:translate-x-0`}
    >
      <div className="h-full flex flex-col overflow-y-auto pb-16">
        <nav className="flex-1 px-4 py-6">
          <div className="space-y-1">
            <NavLink 
              to="/dashboard"
              className={({ isActive }) => 
                `flex items-center px-3 py-3 rounded-lg transition-colors ${
                  isActive 
                    ? 'bg-primary-light/10 text-primary' 
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`
              }
            >
              <Home className="h-5 w-5 mr-3" />
              <span className="text-sm font-medium">{translate('dashboard')}</span>
            </NavLink>
            
            {/* Vendor specific navigation */}
            {user.role === UserRole.VENDOR && (
              <>
                <NavLink 
                  to="/upload-waste"
                  className={({ isActive }) => 
                    `flex items-center px-3 py-3 rounded-lg transition-colors ${
                      isActive 
                        ? 'bg-primary-light/10 text-primary' 
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`
                  }
                >
                  <Upload className="h-5 w-5 mr-3" />
                  <span className="text-sm font-medium">{translate('uploadWaste')}</span>
                </NavLink>
                
                <NavLink 
                  to="/my-listings"
                  className={({ isActive }) => 
                    `flex items-center px-3 py-3 rounded-lg transition-colors ${
                      isActive 
                        ? 'bg-primary-light/10 text-primary' 
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`
                  }
                >
                  <List className="h-5 w-5 mr-3" />
                  <span className="text-sm font-medium">{translate('myListings')}</span>
                </NavLink>
                
                <NavLink 
                  to="/find-factories"
                  className={({ isActive }) => 
                    `flex items-center px-3 py-3 rounded-lg transition-colors ${
                      isActive 
                        ? 'bg-primary-light/10 text-primary' 
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`
                  }
                >
                  <Search className="h-5 w-5 mr-3" />
                  <span className="text-sm font-medium">{translate('findFactories')}</span>
                </NavLink>
              </>
            )}
            
            {/* Factory Owner specific navigation */}
            {user.role === UserRole.FACTORY_OWNER && (
              <>
                <NavLink 
                  to="/post-need"
                  className={({ isActive }) => 
                    `flex items-center px-3 py-3 rounded-lg transition-colors ${
                      isActive 
                        ? 'bg-primary-light/10 text-primary' 
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`
                  }
                >
                  <Plus className="h-5 w-5 mr-3" />
                  <span className="text-sm font-medium">{translate('postMaterialNeed')}</span>
                </NavLink>
                
                <NavLink 
                  to="/my-needs"
                  className={({ isActive }) => 
                    `flex items-center px-3 py-3 rounded-lg transition-colors ${
                      isActive 
                        ? 'bg-primary-light/10 text-primary' 
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`
                  }
                >
                  <List className="h-5 w-5 mr-3" />
                  <span className="text-sm font-medium">{translate('myNeeds')}</span>
                </NavLink>
                
                <NavLink 
                  to="/find-vendors"
                  className={({ isActive }) => 
                    `flex items-center px-3 py-3 rounded-lg transition-colors ${
                      isActive 
                        ? 'bg-primary-light/10 text-primary' 
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`
                  }
                >
                  <Search className="h-5 w-5 mr-3" />
                  <span className="text-sm font-medium">{translate('findVendors')}</span>
                </NavLink>
              </>
            )}
            
            {/* Entrepreneur specific navigation */}
            {user.role === UserRole.ENTREPRENEUR && (
              <>
                <NavLink 
                  to="/feasibility-tool"
                  className={({ isActive }) => 
                    `flex items-center px-3 py-3 rounded-lg transition-colors ${
                      isActive 
                        ? 'bg-primary-light/10 text-primary' 
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`
                  }
                >
                  <BarChart className="h-5 w-5 mr-3" />
                  <span className="text-sm font-medium">{translate('feasibilityTool')}</span>
                </NavLink>
                
                <NavLink 
                  to="/subsidies"
                  className={({ isActive }) => 
                    `flex items-center px-3 py-3 rounded-lg transition-colors ${
                      isActive 
                        ? 'bg-primary-light/10 text-primary' 
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                    }`
                  }
                >
                  <FileText className="h-5 w-5 mr-3" />
                  <span className="text-sm font-medium">{translate('subsidies')}</span>
                </NavLink>
              </>
            )}
            
            {/* Common navigation for all users */}
            <NavLink 
              to="/messages"
              className={({ isActive }) => 
                `flex items-center px-3 py-3 rounded-lg transition-colors ${
                  isActive 
                    ? 'bg-primary-light/10 text-primary' 
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`
              }
            >
              <MessageSquare className="h-5 w-5 mr-3" />
              <span className="text-sm font-medium">{translate('messages')}</span>
            </NavLink>
            
            <NavLink 
              to="/map"
              className={({ isActive }) => 
                `flex items-center px-3 py-3 rounded-lg transition-colors ${
                  isActive 
                    ? 'bg-primary-light/10 text-primary' 
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`
              }
            >
              <MapPin className="h-5 w-5 mr-3" />
              <span className="text-sm font-medium">{translate('location')}</span>
            </NavLink>
          </div>
          
          <hr className="my-6 border-gray-200 dark:border-gray-700" />
          
          <div className="space-y-1">
            <NavLink 
              to="/settings"
              className={({ isActive }) => 
                `flex items-center px-3 py-3 rounded-lg transition-colors ${
                  isActive 
                    ? 'bg-primary-light/10 text-primary' 
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`
              }
            >
              <Settings className="h-5 w-5 mr-3" />
              <span className="text-sm font-medium">Settings</span>
            </NavLink>
            
            <NavLink 
              to="/help"
              className={({ isActive }) => 
                `flex items-center px-3 py-3 rounded-lg transition-colors ${
                  isActive 
                    ? 'bg-primary-light/10 text-primary' 
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`
              }
            >
              <HelpCircle className="h-5 w-5 mr-3" />
              <span className="text-sm font-medium">Help</span>
            </NavLink>
          </div>
        </nav>
        
        <div className="px-4 py-6 border-t border-gray-200 dark:border-gray-700">
          <div className="flex items-center px-3 py-3 rounded-lg bg-primary-light/10">
            <div className="flex-shrink-0">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white">
                {user.role === UserRole.VENDOR && <Trash2 className="h-5 w-5" />}
                {user.role === UserRole.FACTORY_OWNER && <Factory className="h-5 w-5" />}
                {user.role === UserRole.ENTREPRENEUR && <BarChart className="h-5 w-5" />}
              </div>
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-800 dark:text-gray-200">
                {user.role === UserRole.VENDOR && translate('vendor')}
                {user.role === UserRole.FACTORY_OWNER && translate('factoryOwner')}
                {user.role === UserRole.ENTREPRENEUR && translate('entrepreneur')}
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {user.name}
              </p>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;