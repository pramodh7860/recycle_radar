import React from 'react';
import { getSupportedLanguages, setCurrentLanguage, translate } from '../../utils/languageService';
import { Language } from '../../types';

interface LanguageSelectorProps {
  onChange?: (language: Language) => void;
  className?: string;
}

const LanguageSelector: React.FC<LanguageSelectorProps> = ({ onChange, className = '' }) => {
  const languages = getSupportedLanguages();
  const [showDropdown, setShowDropdown] = React.useState(false);
  const [selectedLanguage, setSelectedLanguage] = React.useState<Language>(Language.ENGLISH);
  
  const handleLanguageChange = (language: Language) => {
    setCurrentLanguage(language);
    setSelectedLanguage(language);
    setShowDropdown(false);
    
    if (onChange) {
      onChange(language);
    }
  };
  
  const getLanguageNameInNative = (code: Language): string => {
    switch (code) {
      case Language.ENGLISH:
        return 'English';
      case Language.HINDI:
        return 'हिंदी';
      case Language.TAMIL:
        return 'தமிழ்';
      case Language.TELUGU:
        return 'తెలుగు';
      default:
        return 'English';
    }
  };
  
  return (
    <div className={`relative ${className}`}>
      <button
        className="flex items-center space-x-2 px-4 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
        onClick={() => setShowDropdown(!showDropdown)}
        aria-haspopup="listbox"
        aria-expanded={showDropdown}
      >
        <span className="text-sm font-medium">{getLanguageNameInNative(selectedLanguage)}</span>
        <svg 
          className="w-4 h-4 text-gray-500" 
          fill="none" 
          stroke="currentColor" 
          viewBox="0 0 24 24"
        >
          <path 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            strokeWidth="2" 
            d={showDropdown ? "M5 15l7-7 7 7" : "M19 9l-7 7-7-7"}
          />
        </svg>
      </button>
      
      {showDropdown && (
        <div 
          className="absolute z-10 mt-1 w-full bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg shadow-lg"
          role="listbox"
        >
          {languages.map((language) => (
            <button
              key={language.code}
              className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 ${
                selectedLanguage === language.code 
                  ? 'bg-primary-light/10 text-primary'
                  : 'text-gray-800 dark:text-gray-200'
              }`}
              onClick={() => handleLanguageChange(language.code)}
              role="option"
              aria-selected={selectedLanguage === language.code}
            >
              {getLanguageNameInNative(language.code)}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default LanguageSelector;