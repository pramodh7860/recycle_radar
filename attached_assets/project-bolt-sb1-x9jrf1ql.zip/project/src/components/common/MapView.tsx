import React, { useRef, useEffect, useState } from 'react';
import Map, { Marker, NavigationControl, GeolocateControl } from 'react-map-gl';
import { MapPin } from 'lucide-react';
import { GeoPoint } from '../../types';
import { getCurrentLocation, getAddressFromCoordinates } from '../../utils/mapService';

interface MapViewProps {
  markers?: Array<{
    id: string;
    location: GeoPoint;
    title?: string;
    color?: string;
  }>;
  initialViewState?: {
    latitude: number;
    longitude: number;
    zoom: number;
  };
  onMarkerClick?: (id: string) => void;
  onMapClick?: (location: GeoPoint) => void;
  interactive?: boolean;
  showControls?: boolean;
  width?: string | number;
  height?: string | number;
  className?: string;
}

const MapView: React.FC<MapViewProps> = ({
  markers = [],
  initialViewState,
  onMarkerClick,
  onMapClick,
  interactive = true,
  showControls = true,
  width = '100%',
  height = 400,
  className = '',
}) => {
  const mapRef = useRef<any>(null);
  const [viewState, setViewState] = useState(
    initialViewState || {
      latitude: 20.5937,  // Default to center of India
      longitude: 78.9629,
      zoom: 4,
    }
  );
  const [isLoaded, setIsLoaded] = useState(false);
  const [selectedMarker, setSelectedMarker] = useState<string | null>(null);
  const [address, setAddress] = useState<string>('');

  // Initialize the map with user's location if no initialViewState is provided
  useEffect(() => {
    if (!initialViewState) {
      getCurrentLocation()
        .then((location) => {
          setViewState({
            latitude: location.latitude,
            longitude: location.longitude,
            zoom: 12,
          });
        })
        .catch((error) => {
          console.error('Error getting location:', error);
        });
    }
  }, [initialViewState]);

  // Get address when a marker is selected
  useEffect(() => {
    if (selectedMarker && markers.length > 0) {
      const marker = markers.find((m) => m.id === selectedMarker);
      if (marker) {
        getAddressFromCoordinates(marker.location)
          .then((addr) => setAddress(addr))
          .catch((error) => {
            console.error('Error getting address:', error);
            setAddress('Location address unavailable');
          });
      }
    }
  }, [selectedMarker, markers]);

  const handleMapClick = (event: any) => {
    if (!interactive || !onMapClick) return;
    
    const { lng, lat } = event.lngLat;
    onMapClick({ latitude: lat, longitude: lng });
  };

  const handleMarkerClick = (id: string) => {
    setSelectedMarker(id);
    if (onMarkerClick) {
      onMarkerClick(id);
    }
  };

  return (
    <div className={`relative rounded-lg overflow-hidden ${className}`} style={{ width, height }}>
      {!isLoaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-100 dark:bg-gray-800">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      )}
      
      <Map
        ref={mapRef}
        mapboxAccessToken={import.meta.env.VITE_MAPBOX_ACCESS_TOKEN || "pk.eyJ1IjoiZGVtby11c2VyIiwiYSI6ImNrbTk1bGc2djBkcXMyb29mM25wbWkyd2EifQ.wJYAqCLm0sZAwtKxm7rHfQ"}
        mapStyle="mapbox://styles/mapbox/streets-v11"
        {...viewState}
        onMove={(evt) => setViewState(evt.viewState)}
        onClick={handleMapClick}
        onLoad={() => setIsLoaded(true)}
        interactive={interactive}
        attributionControl={false}
        style={{ width: '100%', height: '100%' }}
      >
        {showControls && (
          <>
            <GeolocateControl position="top-right" />
            <NavigationControl position="top-right" />
          </>
        )}
        
        {markers.map((marker) => (
          <Marker
            key={marker.id}
            latitude={marker.location.latitude}
            longitude={marker.location.longitude}
            onClick={() => handleMarkerClick(marker.id)}
          >
            <div 
              className={`relative cursor-pointer transform transition-transform ${
                selectedMarker === marker.id ? 'scale-125' : 'hover:scale-110'
              }`}
            >
              <MapPin
                size={32}
                className={`drop-shadow-md ${marker.color || 'text-primary'}`}
              />
              {marker.title && selectedMarker === marker.id && (
                <div className="absolute -top-10 left-1/2 transform -translate-x-1/2 bg-white dark:bg-gray-800 px-2 py-1 rounded shadow-md text-xs whitespace-nowrap">
                  {marker.title}
                </div>
              )}
            </div>
          </Marker>
        ))}
      </Map>
      
      {selectedMarker && address && (
        <div className="absolute bottom-0 left-0 right-0 bg-white dark:bg-gray-800 bg-opacity-90 dark:bg-opacity-90 p-3 text-sm">
          <strong>Address:</strong> {address}
        </div>
      )}
    </div>
  );
};

export default MapView;