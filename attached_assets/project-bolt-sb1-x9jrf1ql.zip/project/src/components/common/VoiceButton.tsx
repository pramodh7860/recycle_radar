import React, { useState } from 'react';
import { Mic, MicOff, StopCircle } from 'lucide-react';
import VoiceRecorder from '../../utils/voiceRecorder';

interface VoiceButtonProps {
  onRecordingComplete: (blob: Blob) => void;
  maxDuration?: number; // in seconds
  className?: string;
}

const VoiceButton: React.FC<VoiceButtonProps> = ({ 
  onRecordingComplete, 
  maxDuration = 60,
  className = ''
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [recorder] = useState(
    new VoiceRecorder({
      maxDuration,
      onStart: () => setIsRecording(true),
      onStop: (blob) => {
        setIsRecording(false);
        setRecordingDuration(0);
        onRecordingComplete(blob);
      },
      onError: (error) => {
        console.error('Recording error:', error);
        setIsRecording(false);
        setRecordingDuration(0);
      }
    })
  );
  
  // Timer for recording duration
  React.useEffect(() => {
    let interval: number | null = null;
    
    if (isRecording) {
      interval = window.setInterval(() => {
        setRecordingDuration((prev) => {
          if (prev >= maxDuration) {
            if (interval) clearInterval(interval);
            recorder.stop();
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRecording, maxDuration, recorder]);
  
  const handleToggleRecording = async () => {
    if (isRecording) {
      await recorder.stop();
    } else {
      await recorder.start();
    }
  };
  
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  return (
    <div className={`flex flex-col items-center ${className}`}>
      <button
        onClick={handleToggleRecording}
        className={`w-12 h-12 rounded-full flex items-center justify-center focus:outline-none transition-colors ${
          isRecording 
            ? 'bg-error text-white animate-pulse' 
            : 'bg-primary text-white hover:bg-primary-dark'
        }`}
        aria-label={isRecording ? 'Stop recording' : 'Start recording'}
      >
        {isRecording ? (
          <StopCircle className="w-6 h-6" />
        ) : (
          <Mic className="w-6 h-6" />
        )}
      </button>
      
      {isRecording && (
        <div className="mt-2 text-sm font-medium text-gray-800 dark:text-gray-200">
          {formatTime(recordingDuration)}
        </div>
      )}
      
      {!isRecording && (
        <div className="mt-2 text-xs text-gray-500 dark:text-gray-400">
          Tap to record
        </div>
      )}
    </div>
  );
};

export default VoiceButton;