import React, { useEffect, useState } from 'react';
import { Wifi, WifiOff } from 'lucide-react';
import { isOnline, setupNetworkListeners } from '../../utils/offlineHandler';
import { translate } from '../../utils/languageService';

const OfflineIndicator: React.FC = () => {
  const [online, setOnline] = useState(isOnline());
  const [visible, setVisible] = useState(!isOnline());
  
  const handleOnline = () => {
    setOnline(true);
    // Keep the message visible briefly when coming back online
    setTimeout(() => {
      setVisible(false);
    }, 3000);
  };
  
  const handleOffline = () => {
    setOnline(false);
    setVisible(true);
  };
  
  useEffect(() => {
    const cleanup = setupNetworkListeners(handleOnline, handleOffline);
    return cleanup;
  }, []);
  
  if (!visible) return null;
  
  return (
    <div 
      className={`fixed top-0 left-0 right-0 z-50 py-2 px-4 text-center flex items-center justify-center text-sm transition-colors ${
        online 
          ? 'bg-success text-white' 
          : 'bg-error text-white'
      }`}
    >
      {online ? (
        <>
          <Wifi className="w-4 h-4 mr-2" />
          <span>{translate('syncComplete')}</span>
        </>
      ) : (
        <>
          <WifiOff className="w-4 h-4 mr-2" />
          <span>{translate('offline')}</span>
        </>
      )}
    </div>
  );
};

export default OfflineIndicator;