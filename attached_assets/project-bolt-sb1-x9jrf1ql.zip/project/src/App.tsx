import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './hooks/useAuth';
import Header from './components/common/Header';
import Sidebar from './components/common/Sidebar';
import OfflineIndicator from './components/common/OfflineIndicator';
import { initializeLanguage } from './utils/languageService';

// Auth & Onboarding Pages
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import RoleSelection from './pages/auth/RoleSelection';
import LanguageSelectionPage from './pages/auth/LanguageSelection';

// Dashboard Pages
import Dashboard from './pages/Dashboard';

// Vendor Pages
import UploadWaste from './pages/vendor/UploadWaste';
import MyListings from './pages/vendor/MyListings';
import FindFactories from './pages/vendor/FindFactories';

// Factory Owner Pages
import PostNeed from './pages/factory/PostNeed';
import MyNeeds from './pages/factory/MyNeeds';
import FindVendors from './pages/factory/FindVendors';

// Entrepreneur Pages
import FeasibilityTool from './pages/entrepreneur/FeasibilityTool';
import Subsidies from './pages/entrepreneur/Subsidies';

// Common Pages
import Messages from './pages/Messages';
import ChatDetail from './pages/ChatDetail';
import MapPage from './pages/MapPage';
import Profile from './pages/Profile';
import Settings from './pages/Settings';
import Help from './pages/Help';
import NotFound from './pages/NotFound';

// Protected Route Component
import ProtectedRoute from './components/common/ProtectedRoute';

// Initialize language from localStorage
initializeLanguage();

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
          <OfflineIndicator />
          
          <Routes>
            {/* Authentication Routes */}
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/select-role" element={<RoleSelection />} />
            <Route path="/select-language" element={<LanguageSelectionPage />} />
            
            {/* Main Application with Layout */}
            <Route
              path="/*"
              element={
                <div className="flex flex-col min-h-screen">
                  <Header toggleSidebar={toggleSidebar} sidebarOpen={sidebarOpen} />
                  <div className="flex flex-1 mt-16">
                    <Sidebar isOpen={sidebarOpen} />
                    <main 
                      className={`flex-1 transition-all duration-300 pt-6 px-4 md:px-6 pb-24 ${
                        sidebarOpen ? 'md:ml-64' : ''
                      }`}
                    >
                      <Routes>
                        {/* Home Redirect */}
                        <Route path="/" element={<Navigate to="/dashboard" replace />} />
                        
                        {/* Dashboard */}
                        <Route 
                          path="/dashboard" 
                          element={
                            <ProtectedRoute>
                              <Dashboard />
                            </ProtectedRoute>
                          } 
                        />
                        
                        {/* Vendor Routes */}
                        <Route 
                          path="/upload-waste" 
                          element={
                            <ProtectedRoute allowedRoles={['vendor']}>
                              <UploadWaste />
                            </ProtectedRoute>
                          } 
                        />
                        <Route 
                          path="/my-listings" 
                          element={
                            <ProtectedRoute allowedRoles={['vendor']}>
                              <MyListings />
                            </ProtectedRoute>
                          } 
                        />
                        <Route 
                          path="/find-factories" 
                          element={
                            <ProtectedRoute allowedRoles={['vendor']}>
                              <FindFactories />
                            </ProtectedRoute>
                          } 
                        />
                        
                        {/* Factory Routes */}
                        <Route 
                          path="/post-need" 
                          element={
                            <ProtectedRoute allowedRoles={['factory_owner']}>
                              <PostNeed />
                            </ProtectedRoute>
                          } 
                        />
                        <Route 
                          path="/my-needs" 
                          element={
                            <ProtectedRoute allowedRoles={['factory_owner']}>
                              <MyNeeds />
                            </ProtectedRoute>
                          } 
                        />
                        <Route 
                          path="/find-vendors" 
                          element={
                            <ProtectedRoute allowedRoles={['factory_owner']}>
                              <FindVendors />
                            </ProtectedRoute>
                          } 
                        />
                        
                        {/* Entrepreneur Routes */}
                        <Route 
                          path="/feasibility-tool" 
                          element={
                            <ProtectedRoute allowedRoles={['entrepreneur']}>
                              <FeasibilityTool />
                            </ProtectedRoute>
                          } 
                        />
                        <Route 
                          path="/subsidies" 
                          element={
                            <ProtectedRoute allowedRoles={['entrepreneur']}>
                              <Subsidies />
                            </ProtectedRoute>
                          } 
                        />
                        
                        {/* Common Routes */}
                        <Route 
                          path="/messages" 
                          element={
                            <ProtectedRoute>
                              <Messages />
                            </ProtectedRoute>
                          } 
                        />
                        <Route 
                          path="/chat/:chatId" 
                          element={
                            <ProtectedRoute>
                              <ChatDetail />
                            </ProtectedRoute>
                          } 
                        />
                        <Route 
                          path="/map" 
                          element={
                            <ProtectedRoute>
                              <MapPage />
                            </ProtectedRoute>
                          } 
                        />
                        <Route 
                          path="/profile" 
                          element={
                            <ProtectedRoute>
                              <Profile />
                            </ProtectedRoute>
                          } 
                        />
                        <Route 
                          path="/settings" 
                          element={
                            <ProtectedRoute>
                              <Settings />
                            </ProtectedRoute>
                          } 
                        />
                        <Route 
                          path="/help" 
                          element={
                            <ProtectedRoute>
                              <Help />
                            </ProtectedRoute>
                          } 
                        />
                        
                        {/* 404 Page */}
                        <Route path="*" element={<NotFound />} />
                      </Routes>
                    </main>
                  </div>
                </div>
              }
            />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;