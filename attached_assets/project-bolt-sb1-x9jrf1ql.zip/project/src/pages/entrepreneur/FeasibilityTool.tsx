import React, { useState } from 'react';
import { BarChart, Download, CheckCircle, AlertTriangle, Info } from 'lucide-react';
import { translate } from '../../utils/languageService';
import useAuth from '../../hooks/useAuth';
import { FeasibilityInput, FeasibilityResult, Recommendation, SubsidyLink } from '../../types';
import { generateSubsidyRecommendations, downloadReport } from '../../utils/reportGenerator';

const materialTypes = [
  { id: 'plastic', name: 'Plastic' },
  { id: 'paper', name: 'Paper & Cardboard' },
  { id: 'metal', name: 'Metal' },
  { id: 'glass', name: 'Glass' },
  { id: 'e-waste', name: 'E-Waste' },
  { id: 'textile', name: 'Textile' },
  { id: 'organic', name: 'Organic Waste' },
];

const FeasibilityTool: React.FC = () => {
  const { user } = useAuth();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<FeasibilityResult | null>(null);
  
  const [input, setInput] = useState<FeasibilityInput>({
    budget: 500000,
    location: '',
    materialType: [],
    scalePlan: 'small',
    existingInfrastructure: false,
    employmentGoal: 5
  });
  
  const handleMaterialToggle = (materialId: string) => {
    setInput(prev => {
      if (prev.materialType.includes(materialId)) {
        return {
          ...prev,
          materialType: prev.materialType.filter(id => id !== materialId)
        };
      } else {
        return {
          ...prev,
          materialType: [...prev.materialType, materialId]
        };
      }
    });
  };
  
  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value, type } = e.target as HTMLInputElement;
    
    setInput(prev => ({
      ...prev,
      [name]: type === 'checkbox' 
        ? (e.target as HTMLInputElement).checked 
        : type === 'number' 
          ? parseFloat(value) 
          : value
    }));
  };
  
  const handleSubmit = async () => {
    setLoading(true);
    
    try {
      // In a real app, this would be a call to your backend
      // For demo purposes, we'll simulate processing
      setTimeout(() => {
        // Generate recommendations based on input
        const recommendations: Recommendation[] = generateRecommendations(input);
        
        // Generate subsidy links
        const subsidyLinks: SubsidyLink[] = generateSubsidyRecommendations(
          input.budget,
          input.materialType,
          input.scalePlan,
          input.location
        );
        
        const feasibilityResult: FeasibilityResult = {
          id: `feasibility-${Date.now()}`,
          userId: user?.id || 'anonymous',
          input,
          recommendations,
          subsidyLinks,
          createdAt: new Date().toISOString()
        };
        
        setResult(feasibilityResult);
        setStep(2);
        setLoading(false);
      }, 2000);
    } catch (error) {
      console.error('Error generating feasibility report:', error);
      setLoading(false);
    }
  };
  
  const generateRecommendations = (input: FeasibilityInput): Recommendation[] => {
    const recommendations: Recommendation[] = [];
    
    // Small scale plastic recycling
    if (input.materialType.includes('plastic') && input.budget < 1000000 && input.scalePlan === 'small') {
      recommendations.push({
        unitType: 'Small Scale Plastic Recycling Unit',
        description: 'A compact unit for processing PET bottles and similar plastic waste into flakes for resale to manufacturers.',
        estimatedCost: 500000,
        estimatedRoi: 25,
        timelineMonths: 8,
        requiredArea: 100,
        requiredResources: [
          'Basic plastic washing and cutting equipment',
          '3-5 workers',
          'Consistent supply of clean PET waste',
          'Water recycling system'
        ],
        challenges: [
          'Fluctuating plastic prices',
          'Quality control of input waste',
          'Water management'
        ]
      });
    }
    
    // Medium scale plastic recycling
    if (input.materialType.includes('plastic') && input.budget >= 1000000 && input.budget < 5000000 && (input.scalePlan === 'medium' || input.scalePlan === 'large')) {
      recommendations.push({
        unitType: 'Medium Scale Plastic Recycling Unit',
        description: 'An integrated facility capable of processing multiple types of plastic waste into pellets for direct use in manufacturing.',
        estimatedCost: 3000000,
        estimatedRoi: 30,
        timelineMonths: 14,
        requiredArea: 500,
        requiredResources: [
          'Complete plastic washing, cutting, and pelletizing line',
          '10-15 workers',
          'Sorting facility',
          'Quality testing lab',
          'Effluent treatment plant'
        ],
        challenges: [
          'Higher capital investment',
          'Skilled labor requirements',
          'Regulatory compliance',
          'Market competition'
        ]
      });
    }
    
    // Paper recycling
    if (input.materialType.includes('paper')) {
      recommendations.push({
        unitType: 'Paper Recycling Unit',
        description: 'A facility for converting waste paper into recycled paper products or pulp for paper mills.',
        estimatedCost: input.scalePlan === 'small' ? 800000 : 2500000,
        estimatedRoi: 22,
        timelineMonths: 10,
        requiredArea: input.scalePlan === 'small' ? 200 : 600,
        requiredResources: [
          'Paper pulping equipment',
          'Drying and pressing machinery',
          '5-12 workers',
          'Consistent water supply',
          'Waste water treatment'
        ],
        challenges: [
          'High water consumption',
          'Chemical management',
          'Quality control',
          'Competition from large mills'
        ]
      });
    }
    
    // E-waste recycling
    if (input.materialType.includes('e-waste')) {
      recommendations.push({
        unitType: 'E-Waste Dismantling and Recovery Unit',
        description: 'A specialized facility for safely dismantling electronic waste and recovering valuable metals and components.',
        estimatedCost: input.scalePlan === 'small' ? 1200000 : 4000000,
        estimatedRoi: 35,
        timelineMonths: 12,
        requiredArea: input.scalePlan === 'small' ? 150 : 400,
        requiredResources: [
          'Dismantling tools and workstations',
          'Safety equipment and protocols',
          'Storage for hazardous components',
          'Metal recovery systems',
          '6-10 skilled workers'
        ],
        challenges: [
          'Hazardous materials handling',
          'Strict regulatory requirements',
          'Technical expertise needed',
          'Rapidly changing e-waste composition'
        ]
      });
    }
    
    // If no specific recommendations, provide a general one
    if (recommendations.length === 0) {
      recommendations.push({
        unitType: 'General Waste Segregation and Processing Center',
        description: 'A multi-purpose facility for sorting and basic processing of various waste streams for further recycling.',
        estimatedCost: input.scalePlan === 'small' ? 600000 : 2000000,
        estimatedRoi: 18,
        timelineMonths: 6,
        requiredArea: input.scalePlan === 'small' ? 200 : 500,
        requiredResources: [
          'Sorting conveyor system',
          'Baling equipment',
          'Storage space',
          '5-15 workers depending on scale',
          'Basic material handling equipment'
        ],
        challenges: [
          'Mixed waste handling',
          'Finding buyers for all material streams',
          'Operational efficiency',
          'Worker training'
        ]
      });
    }
    
    return recommendations;
  };
  
  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
          <BarChart className="h-6 w-6 mr-2 text-primary" />
          {translate('feasibilityTool')}
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Evaluate the feasibility of starting a recycling business
        </p>
      </div>
      
      {step === 1 && (
        <div className="card">
          <h2 className="text-xl font-semibold mb-6">Enter Your Details</h2>
          
          <div className="space-y-6">
            <div>
              <label htmlFor="budget" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Budget (in ₹)
              </label>
              <input
                type="number"
                id="budget"
                name="budget"
                value={input.budget}
                onChange={handleInputChange}
                className="input-field"
                min="100000"
                step="50000"
              />
              <div className="mt-2 flex">
                <button 
                  className={`px-3 py-1 text-xs rounded-l-md ${input.budget === 500000 ? 'bg-primary text-white' : 'bg-gray-100 dark:bg-gray-700'}`}
                  onClick={() => setInput(prev => ({ ...prev, budget: 500000 }))}
                >
                  ₹5 Lakh
                </button>
                <button 
                  className={`px-3 py-1 text-xs ${input.budget === 1000000 ? 'bg-primary text-white' : 'bg-gray-100 dark:bg-gray-700'}`}
                  onClick={() => setInput(prev => ({ ...prev, budget: 1000000 }))}
                >
                  ₹10 Lakh
                </button>
                <button 
                  className={`px-3 py-1 text-xs ${input.budget === 5000000 ? 'bg-primary text-white' : 'bg-gray-100 dark:bg-gray-700'}`}
                  onClick={() => setInput(prev => ({ ...prev, budget: 5000000 }))}
                >
                  ₹50 Lakh
                </button>
                <button 
                  className={`px-3 py-1 text-xs rounded-r-md ${input.budget === 10000000 ? 'bg-primary text-white' : 'bg-gray-100 dark:bg-gray-700'}`}
                  onClick={() => setInput(prev => ({ ...prev, budget: 10000000 }))}
                >
                  ₹1 Crore
                </button>
              </div>
            </div>
            
            <div>
              <label htmlFor="location" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Location
              </label>
              <input
                type="text"
                id="location"
                name="location"
                value={input.location}
                onChange={handleInputChange}
                className="input-field"
                placeholder="City, State"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Material Types
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {materialTypes.map((material) => (
                  <button
                    key={material.id}
                    type="button"
                    onClick={() => handleMaterialToggle(material.id)}
                    className={`px-3 py-2 text-sm rounded-lg border ${
                      input.materialType.includes(material.id)
                        ? 'bg-primary-light/10 border-primary text-primary'
                        : 'border-gray-300 dark:border-gray-600'
                    }`}
                  >
                    {material.name}
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <label htmlFor="scalePlan" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Scale of Operation
              </label>
              <select
                id="scalePlan"
                name="scalePlan"
                value={input.scalePlan}
                onChange={handleInputChange}
                className="input-field"
              >
                <option value="small">Small (1-10 workers)</option>
                <option value="medium">Medium (11-50 workers)</option>
                <option value="large">Large (50+ workers)</option>
              </select>
            </div>
            
            <div>
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="existingInfrastructure"
                  name="existingInfrastructure"
                  checked={input.existingInfrastructure}
                  onChange={handleInputChange}
                  className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                />
                <label htmlFor="existingInfrastructure" className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                  I have existing infrastructure (land/building)
                </label>
              </div>
            </div>
            
            <div>
              <label htmlFor="employmentGoal" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Employment Goal (number of people)
              </label>
              <input
                type="number"
                id="employmentGoal"
                name="employmentGoal"
                value={input.employmentGoal}
                onChange={handleInputChange}
                className="input-field"
                min="1"
              />
            </div>
            
            <div className="flex justify-end pt-4">
              <button
                type="button"
                onClick={handleSubmit}
                disabled={loading || input.materialType.length === 0 || !input.location}
                className="btn btn-primary"
              >
                {loading ? (
                  <div className="flex items-center">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    <span>Analyzing...</span>
                  </div>
                ) : (
                  <span>{translate('generateReport')}</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
      
      {step === 2 && result && (
        <div className="space-y-6">
          <div className="card">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold">{translate('recommendations')}</h2>
              <button 
                onClick={() => downloadReport(result)}
                className="btn btn-sm btn-secondary flex items-center"
              >
                <Download className="h-4 w-4 mr-2" />
                {translate('download')} PDF
              </button>
            </div>
            
            <div className="space-y-6">
              {result.recommendations.map((rec, index) => (
                <div key={index} className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
                  <div className="bg-gray-50 dark:bg-gray-800 px-4 py-3 border-b border-gray-200 dark:border-gray-700">
                    <h3 className="font-semibold text-lg">{rec.unitType}</h3>
                  </div>
                  
                  <div className="p-4">
                    <p className="text-gray-600 dark:text-gray-400 mb-4">{rec.description}</p>
                    
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded">
                        <span className="text-sm text-gray-500 dark:text-gray-400 block">Estimated Cost</span>
                        <span className="text-lg font-semibold">₹{rec.estimatedCost.toLocaleString()}</span>
                      </div>
                      
                      <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded">
                        <span className="text-sm text-gray-500 dark:text-gray-400 block">Estimated ROI</span>
                        <span className="text-lg font-semibold">{rec.estimatedRoi}%</span>
                      </div>
                      
                      <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded">
                        <span className="text-sm text-gray-500 dark:text-gray-400 block">Timeline</span>
                        <span className="text-lg font-semibold">{rec.timelineMonths} months</span>
                      </div>
                      
                      <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded">
                        <span className="text-sm text-gray-500 dark:text-gray-400 block">Required Area</span>
                        <span className="text-lg font-semibold">{rec.requiredArea} m²</span>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-medium mb-2 flex items-center">
                          <CheckCircle className="h-4 w-4 text-primary mr-1" />
                          Required Resources
                        </h4>
                        <ul className="list-disc pl-5 space-y-1">
                          {rec.requiredResources.map((resource, idx) => (
                            <li key={idx} className="text-sm text-gray-600 dark:text-gray-400">{resource}</li>
                          ))}
                        </ul>
                      </div>
                      
                      <div>
                        <h4 className="font-medium mb-2 flex items-center">
                          <AlertTriangle className="h-4 w-4 text-warning mr-1" />
                          Challenges
                        </h4>
                        <ul className="list-disc pl-5 space-y-1">
                          {rec.challenges.map((challenge, idx) => (
                            <li key={idx} className="text-sm text-gray-600 dark:text-gray-400">{challenge}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="card">
            <h2 className="text-xl font-semibold mb-6">{translate('subsidies')}</h2>
            
            <div className="space-y-4">
              {result.subsidyLinks.map((subsidy, index) => (
                <div key={index} className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
                  <div className="bg-gray-50 dark:bg-gray-800 px-4 py-3 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
                    <h3 className="font-semibold">{subsidy.name}</h3>
                    <span className="text-sm text-secondary">{subsidy.provider}</span>
                  </div>
                  
                  <div className="p-4">
                    <p className="text-gray-600 dark:text-gray-400 mb-3">{subsidy.description}</p>
                    <div className="bg-secondary-light/10 p-3 rounded-lg mb-3">
                      <div className="flex items-start">
                        <Info className="h-5 w-5 text-secondary mr-2 flex-shrink-0 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-secondary mb-1">Eligibility</h4>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{subsidy.eligibility}</p>
                        </div>
                      </div>
                    </div>
                    <a
                      href={subsidy.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:underline text-sm flex items-center"
                    >
                      Visit website for more details
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 flex justify-between">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="btn btn-outline text-primary"
              >
                Modify Inputs
              </button>
              
              <button
                onClick={() => downloadReport(result)}
                className="btn btn-primary flex items-center"
              >
                <Download className="h-5 w-5 mr-2" />
                {translate('download')} Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FeasibilityTool;