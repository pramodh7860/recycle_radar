import React, { useState, useEffect } from 'react';
import { FileText, Search, ChevronDown, ChevronUp, ExternalLink, Download, Building } from 'lucide-react';
import { translate } from '../../utils/languageService';
import { SubsidyLink } from '../../types';
import { generateSubsidyRecommendations } from '../../utils/reportGenerator';

const Subsidies: React.FC = () => {
  const [subsidies, setSubsidies] = useState<SubsidyLink[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [openDetails, setOpenDetails] = useState<Set<number>>(new Set());
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>('all');
  
  useEffect(() => {
    // Generate sample subsidies
    const fetchSubsidies = async () => {
      try {
        // In a real app, you'd fetch this from an API
        const data = generateSubsidyRecommendations(
          1000000, // budget
          ['plastic', 'paper'], // materials
          'small', // scale
          'Delhi' // location
        );
        
        // Add some more mock data
        const additionalSubsidies: SubsidyLink[] = [
          {
            name: 'Sustainable Enterprise Fund',
            provider: 'Ministry of New and Renewable Energy',
            description: 'Financial support for businesses focused on sustainable practices and green technologies.',
            eligibility: 'Small and medium enterprises with initiatives in renewable energy or circular economy.',
            url: 'https://mnre.gov.in/sustainable-fund'
          },
          {
            name: 'Circular Economy Innovation Grant',
            provider: 'Department of Science & Technology',
            description: 'Grants for projects that promote circular economy principles in waste management.',
            eligibility: 'Startups and research organizations with innovative waste management solutions.',
            url: 'https://dst.gov.in/circular-economy'
          },
          {
            name: 'Green Manufacturing Subsidy Scheme',
            provider: 'Ministry of Heavy Industries',
            description: 'Subsidies for adopting green manufacturing practices in industrial processes.',
            eligibility: 'Manufacturing units implementing energy-efficient and pollution-reducing technologies.',
            url: 'https://heavyindustries.gov.in/schemes'
          },
          {
            name: 'Rural Entrepreneurship Development Program',
            provider: 'Ministry of Rural Development',
            description: 'Support for setting up rural waste management and recycling enterprises.',
            eligibility: 'Entrepreneurs establishing recycling units in rural areas employing local workforce.',
            url: 'https://rural.nic.in/entrepreneurs'
          }
        ];
        
        setSubsidies([...data, ...additionalSubsidies]);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching subsidies:', error);
        setLoading(false);
      }
    };
    
    fetchSubsidies();
  }, []);
  
  const toggleDetails = (index: number) => {
    const newOpenDetails = new Set(openDetails);
    if (newOpenDetails.has(index)) {
      newOpenDetails.delete(index);
    } else {
      newOpenDetails.add(index);
    }
    setOpenDetails(newOpenDetails);
  };
  
  const filteredSubsidies = subsidies.filter(subsidy => {
    if (filter !== 'all') {
      // Simple filtering logic - in a real app this would be more sophisticated
      if (filter === 'central' && !subsidy.provider.includes('Ministry')) {
        return false;
      }
      if (filter === 'state' && subsidy.provider.includes('Ministry')) {
        return false;
      }
    }
    
    if (!searchQuery) return true;
    
    return (
      subsidy.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      subsidy.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      subsidy.provider.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });
  
  const downloadSubsidyInfo = (subsidy: SubsidyLink) => {
    // This would generate a PDF with subsidy details in a real app
    console.log('Downloading subsidy info for:', subsidy.name);
    alert(`In a real app, this would download information about "${subsidy.name}"`);
  };
  
  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
          <FileText className="h-6 w-6 mr-2 text-primary" />
          {translate('subsidies')}
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Explore available subsidies and government support for recycling businesses
        </p>
      </div>
      
      <div className="card mb-6">
        <div className="flex flex-col md:flex-row md:items-center space-y-4 md:space-y-0 md:space-x-4">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search subsidies..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input-field pl-10 w-full"
            />
          </div>
          
          <div className="flex-shrink-0">
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="input-field"
            >
              <option value="all">All Subsidies</option>
              <option value="central">Central Government</option>
              <option value="state">State Government</option>
            </select>
          </div>
        </div>
      </div>
      
      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-400">Loading subsidies...</p>
        </div>
      ) : (
        <>
          {filteredSubsidies.length === 0 ? (
            <div className="card text-center py-12">
              <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="h-8 w-8 text-gray-400" />
              </div>
              <h2 className="text-xl font-semibold mb-2">No matching subsidies found</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                Try different search terms or filters
              </p>
              <button
                type="button"
                className="btn btn-sm btn-outline text-primary"
                onClick={() => {
                  setSearchQuery('');
                  setFilter('all');
                }}
              >
                Clear Filters
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {filteredSubsidies.map((subsidy, index) => (
                <div 
                  key={index} 
                  className="card transition-all duration-200 overflow-hidden"
                >
                  <div 
                    className="flex justify-between items-center cursor-pointer"
                    onClick={() => toggleDetails(index)}
                  >
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-secondary-light/20 rounded-full flex items-center justify-center mr-4">
                        <Building className="h-5 w-5 text-secondary" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg">{subsidy.name}</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {subsidy.provider}
                        </p>
                      </div>
                    </div>
                    
                    <button
                      className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
                      aria-label={openDetails.has(index) ? "Collapse details" : "Expand details"}
                    >
                      {openDetails.has(index) ? (
                        <ChevronUp className="h-5 w-5 text-gray-500" />
                      ) : (
                        <ChevronDown className="h-5 w-5 text-gray-500" />
                      )}
                    </button>
                  </div>
                  
                  {openDetails.has(index) && (
                    <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700 animate-fade-in">
                      <div className="space-y-4">
                        <div>
                          <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Description
                          </h4>
                          <p className="text-gray-600 dark:text-gray-400">
                            {subsidy.description}
                          </p>
                        </div>
                        
                        <div>
                          <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Eligibility
                          </h4>
                          <div className="bg-primary-light/10 p-3 rounded-lg">
                            <p className="text-gray-600 dark:text-gray-400">
                              {subsidy.eligibility}
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
                          <a
                            href={subsidy.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-primary hover:underline flex items-center"
                          >
                            Visit official website
                            <ExternalLink className="h-4 w-4 ml-1" />
                          </a>
                          
                          <button
                            onClick={() => downloadSubsidyInfo(subsidy)}
                            className="btn btn-sm btn-outline text-primary flex items-center"
                          >
                            <Download className="h-4 w-4 mr-1" />
                            Download information
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default Subsidies;