import React, { useState } from 'react';
import { User, Mail, Phone, MapPin, Camera, Save, Trash2, Factory, BarChart } from 'lucide-react';
import { translate } from '../utils/languageService';
import useAuth from '../hooks/useAuth';
import useOffline from '../hooks/useOffline';
import { updateUserProfile, uploadFile } from '../utils/firebase';
import MapView from '../components/common/MapView';
import { GeoPoint, UserRole } from '../types';
import { getCurrentLocation } from '../utils/mapService';

const Profile: React.FC = () => {
  const { user } = useAuth();
  const { online, saveAction } = useOffline();
  
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState(''); // This would come from user profile
  const [location, setLocation] = useState<GeoPoint | null>(user?.location || null);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(user?.profileImageUrl || null);
  const [loading, setLoading] = useState(false);
  
  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setPhotoFile(file);
      setPhotoPreview(URL.createObjectURL(file));
    }
  };
  
  const handleGetCurrentLocation = async () => {
    try {
      const userLocation = await getCurrentLocation();
      setLocation(userLocation);
    } catch (error) {
      console.error('Error getting location:', error);
    }
  };
  
  const handleSaveProfile = async () => {
    if (!user) return;
    
    setLoading(true);
    
    try {
      let profileImageUrl = user.profileImageUrl || '';
      
      if (online) {
        if (photoFile) {
          const path = `profile-images/${user.id}/${Date.now()}-${photoFile.name}`;
          profileImageUrl = await uploadFile(photoFile, path);
        }
        
        await updateUserProfile(user.id, {
          name,
          email,
          location,
          profileImageUrl,
          lastActive: new Date()
        });
      } else {
        // Save for later sync
        await saveAction('update', 'users', {
          id: user.id,
          name,
          email,
          location,
          hasNewPhoto: !!photoFile,
          photoFileName: photoFile ? photoFile.name : null,
          updatedAt: new Date().toISOString()
        });
      }
      
      setEditing(false);
    } catch (error) {
      console.error('Error updating profile:', error);
    } finally {
      setLoading(false);
    }
  };
  
  if (!user) return null;
  
  const getRoleIcon = () => {
    switch (user.role) {
      case UserRole.VENDOR:
        return <Trash2 className="h-6 w-6 text-white" />;
      case UserRole.FACTORY_OWNER:
        return <Factory className="h-6 w-6 text-white" />;
      case UserRole.ENTREPRENEUR:
        return <BarChart className="h-6 w-6 text-white" />;
      default:
        return <User className="h-6 w-6 text-white" />;
    }
  };
  
  const getRoleName = () => {
    switch (user.role) {
      case UserRole.VENDOR:
        return translate('vendor');
      case UserRole.FACTORY_OWNER:
        return translate('factoryOwner');
      case UserRole.ENTREPRENEUR:
        return translate('entrepreneur');
      default:
        return user.role;
    }
  };
  
  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
          <User className="h-6 w-6 mr-2 text-primary" />
          {translate('profile')}
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Manage your personal information and preferences
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="card">
            <div className="flex justify-between mb-6">
              <h2 className="text-xl font-semibold">Personal Information</h2>
              
              {!editing && (
                <button
                  type="button"
                  onClick={() => setEditing(true)}
                  className="btn btn-sm btn-outline text-primary"
                >
                  Edit Profile
                </button>
              )}
            </div>
            
            <div className="space-y-6">
              <div className="flex flex-col md:flex-row md:items-center">
                <div className="mb-4 md:mb-0 md:mr-6 relative">
                  <div className="w-24 h-24 rounded-full bg-primary-light/20 flex items-center justify-center overflow-hidden">
                    {photoPreview ? (
                      <img
                        src={photoPreview}
                        alt={user.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <User className="h-12 w-12 text-primary" />
                    )}
                  </div>
                  
                  {editing && (
                    <div className="absolute -bottom-1 -right-1">
                      <label className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white cursor-pointer hover:bg-primary-dark transition-colors">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handlePhotoChange}
                          className="hidden"
                        />
                        <Camera className="h-4 w-4" />
                      </label>
                    </div>
                  )}
                </div>
                
                <div>
                  <h3 className="text-lg font-medium">{user.name}</h3>
                  <div className="flex items-center mt-1 text-sm text-gray-600 dark:text-gray-400">
                    <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center mr-2">
                      {getRoleIcon()}
                    </div>
                    {getRoleName()}
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Full Name
                  </label>
                  {editing ? (
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <User className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="text"
                        id="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="input-field pl-10"
                        placeholder="Your full name"
                      />
                    </div>
                  ) : (
                    <div className="flex items-center text-gray-800 dark:text-gray-200">
                      <User className="h-5 w-5 text-gray-400 mr-3" />
                      {user.name}
                    </div>
                  )}
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Email
                  </label>
                  {editing ? (
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Mail className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="input-field pl-10"
                        placeholder="Your email address"
                      />
                    </div>
                  ) : (
                    <div className="flex items-center text-gray-800 dark:text-gray-200">
                      <Mail className="h-5 w-5 text-gray-400 mr-3" />
                      {user.email}
                    </div>
                  )}
                </div>
                
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Phone
                  </label>
                  {editing ? (
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Phone className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="tel"
                        id="phone"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="input-field pl-10"
                        placeholder="Your phone number"
                      />
                    </div>
                  ) : (
                    <div className="flex items-center text-gray-800 dark:text-gray-200">
                      <Phone className="h-5 w-5 text-gray-400 mr-3" />
                      {user.phone || 'Not provided'}
                    </div>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Preferred Language
                  </label>
                  <div className="flex items-center text-gray-800 dark:text-gray-200">
                    <svg className="h-5 w-5 text-gray-400 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129" />
                    </svg>
                    
                    {user.preferredLanguage === 'en' && 'English'}
                    {user.preferredLanguage === 'hi' && 'हिंदी'}
                    {user.preferredLanguage === 'ta' && 'தமிழ்'}
                    {user.preferredLanguage === 'te' && 'తెలుగు'}
                  </div>
                </div>
              </div>
            </div>
            
            {editing && (
              <div className="flex justify-end space-x-3 mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                <button
                  type="button"
                  onClick={() => setEditing(false)}
                  className="btn btn-outline text-gray-600"
                  disabled={loading}
                >
                  Cancel
                </button>
                
                <button
                  type="button"
                  onClick={handleSaveProfile}
                  disabled={loading || !online}
                  className={`btn btn-primary ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
                >
                  {loading ? (
                    <div className="flex items-center">
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                      <span>Saving...</span>
                    </div>
                  ) : (
                    <div className="flex items-center">
                      <Save className="h-5 w-5 mr-2" />
                      <span>Save Profile</span>
                    </div>
                  )}
                </button>
              </div>
            )}
          </div>
        </div>
        
        <div>
          <div className="card">
            <h2 className="text-xl font-semibold mb-6 flex items-center">
              <MapPin className="h-5 w-5 mr-2 text-primary" />
              Location
            </h2>
            
            {editing && (
              <button
                type="button"
                onClick={handleGetCurrentLocation}
                className="btn btn-sm btn-outline text-primary mb-4 w-full"
              >
                Use Current Location
              </button>
            )}
            
            {location ? (
              <MapView
                height={200}
                initialViewState={{
                  latitude: location.latitude,
                  longitude: location.longitude,
                  zoom: 14,
                }}
                markers={[
                  {
                    id: 'your-location',
                    location: location,
                    title: 'Your Location',
                    color: editing ? 'text-primary' : 'text-gray-500'
                  },
                ]}
                onMapClick={editing ? (newLocation) => setLocation(newLocation) : undefined}
                interactive={editing}
              />
            ) : (
              <div className="h-48 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                <p className="text-gray-500 dark:text-gray-400">
                  {editing ? 'Click "Use Current Location" or select on the map' : 'No location set'}
                </p>
              </div>
            )}
            
            {editing && (
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                Click on the map to set your exact location
              </p>
            )}
          </div>
          
          <div className="card mt-6">
            <h2 className="text-xl font-semibold mb-4">Account Info</h2>
            
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500 dark:text-gray-400">Member Since</span>
                <span className="text-sm text-gray-800 dark:text-gray-200">
                  {new Date(user.createdAt).toLocaleDateString()}
                </span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500 dark:text-gray-400">Last Activity</span>
                <span className="text-sm text-gray-800 dark:text-gray-200">
                  {user.lastActive 
                    ? new Date(user.lastActive).toLocaleDateString() 
                    : 'Now'}
                </span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500 dark:text-gray-400">Account Type</span>
                <span className="text-sm font-medium px-2 py-1 bg-primary-light/10 text-primary rounded-full">
                  {getRoleName()}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;