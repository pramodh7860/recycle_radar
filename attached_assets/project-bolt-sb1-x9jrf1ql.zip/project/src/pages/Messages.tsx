import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, Search, ChevronRight } from 'lucide-react';
import { translate } from '../utils/languageService';
import useAuth from '../hooks/useAuth';
import { Chat } from '../types';

// Mock chats data
const mockChats: Chat[] = [
  {
    id: 'chat1',
    participantIds: ['user1', 'user2'],
    participantNames: ['Raj Recyclers', 'You'],
    lastMessageContent: 'Can you provide more details about the plastic waste?',
    lastMessageTime: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    unreadCount: { user1: 0, user2: 1 },
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'chat2',
    participantIds: ['user1', 'user3'],
    participantNames: ['Green Paper Co', 'You'],
    lastMessageContent: 'I\'m interested in your cardboard boxes. Are they still available?',
    lastMessageTime: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    unreadCount: { user1: 2, user3: 0 },
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 'chat3',
    participantIds: ['user1', 'user4'],
    participantNames: ['Metal Scrap Dealers', 'You'],
    lastMessageContent: 'The price is negotiable if you can provide regular supply.',
    lastMessageTime: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    unreadCount: { user1: 0, user4: 0 },
    createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()
  }
];

const Messages: React.FC = () => {
  const { user } = useAuth();
  const [chats, setChats] = useState<Chat[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // Simulate loading chats from backend
    setTimeout(() => {
      setChats(mockChats);
      setLoading(false);
    }, 1000);
  }, []);
  
  const filteredChats = chats.filter(chat => {
    if (!searchQuery) return true;
    
    const otherParticipantName = chat.participantNames.find(name => name !== 'You') || '';
    return otherParticipantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (chat.lastMessageContent && chat.lastMessageContent.toLowerCase().includes(searchQuery.toLowerCase()));
  });
  
  const formatTime = (dateString: string): string => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      // Today: show time
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diffDays === 1) {
      // Yesterday
      return 'Yesterday';
    } else if (diffDays < 7) {
      // Within a week: show day name
      return date.toLocaleDateString([], { weekday: 'short' });
    } else {
      // More than a week: show date
      return date.toLocaleDateString([], { day: 'numeric', month: 'short' });
    }
  };
  
  const getUnreadCount = (chat: Chat): number => {
    if (!user) return 0;
    return chat.unreadCount[user.id] || 0;
  };
  
  const getOtherParticipantName = (chat: Chat): string => {
    return chat.participantNames.find(name => name !== 'You') || '';
  };
  
  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
          <MessageSquare className="h-6 w-6 mr-2 text-primary" />
          {translate('messages')}
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Chat with vendors and factory owners
        </p>
      </div>
      
      <div className="card">
        <div className="mb-4">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search messages..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input-field pl-10"
            />
          </div>
        </div>
        
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mx-auto"></div>
            <p className="mt-4 text-gray-600 dark:text-gray-400">Loading your messages...</p>
          </div>
        ) : (
          <>
            {filteredChats.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MessageSquare className="h-8 w-8 text-gray-400" />
                </div>
                
                {searchQuery ? (
                  <>
                    <h2 className="text-xl font-semibold mb-2">No matching conversations</h2>
                    <p className="text-gray-600 dark:text-gray-400 mb-6">
                      Try different search terms
                    </p>
                    <button
                      type="button"
                      className="btn btn-sm btn-outline text-primary"
                      onClick={() => setSearchQuery('')}
                    >
                      Clear Search
                    </button>
                  </>
                ) : (
                  <>
                    <h2 className="text-xl font-semibold mb-2">No conversations yet</h2>
                    <p className="text-gray-600 dark:text-gray-400 mb-6">
                      Start by contacting vendors or factory owners
                    </p>
                  </>
                )}
              </div>
            ) : (
              <div className="divide-y divide-gray-200 dark:divide-gray-700">
                {filteredChats.map((chat) => (
                  <Link
                    key={chat.id}
                    to={`/chat/${chat.id}`}
                    className="block py-4 px-2 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors rounded-lg -mx-2"
                  >
                    <div className="flex items-center">
                      <div className="flex-shrink-0 w-12 h-12 bg-primary-light/20 rounded-full flex items-center justify-center">
                        <MessageSquare className="h-6 w-6 text-primary" />
                      </div>
                      
                      <div className="ml-4 flex-1">
                        <div className="flex items-center justify-between">
                          <h3 className="font-medium text-gray-900 dark:text-white">
                            {getOtherParticipantName(chat)}
                          </h3>
                          <span className="text-sm text-gray-500 dark:text-gray-400">
                            {formatTime(chat.lastMessageTime || chat.createdAt)}
                          </span>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <p className="text-sm text-gray-600 dark:text-gray-400 truncate max-w-xs">
                            {chat.lastMessageContent || 'Start a conversation'}
                          </p>
                          
                          <div className="flex items-center">
                            {getUnreadCount(chat) > 0 && (
                              <span className="w-5 h-5 bg-primary text-white text-xs rounded-full flex items-center justify-center mr-2">
                                {getUnreadCount(chat)}
                              </span>
                            )}
                            <ChevronRight className="h-4 w-4 text-gray-400" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default Messages;