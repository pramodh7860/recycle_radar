import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Send, Mic, MapPin, Image, ChevronDown } from 'lucide-react';
import { translate } from '../utils/languageService';
import useAuth from '../hooks/useAuth';
import VoiceButton from '../components/common/VoiceButton';
import { Message } from '../types';
import useVoiceRecorder from '../hooks/useVoiceRecorder';

// Mock messages data
const mockMessages: Record<string, Message[]> = {
  'chat1': [
    {
      id: 'm1',
      chatId: 'chat1',
      senderId: 'user2',
      content: 'Hello, I saw your listing for plastic waste. Is it still available?',
      contentType: 'text',
      status: 'read',
      createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString()
    },
    {
      id: 'm2',
      chatId: 'chat1',
      senderId: 'user1',
      content: 'Yes, it is available. I have about 200kg of clean PET bottles.',
      contentType: 'text',
      status: 'read',
      createdAt: new Date(Date.now() - 2.5 * 60 * 60 * 1000).toISOString()
    },
    {
      id: 'm3',
      chatId: 'chat1',
      senderId: 'user2',
      content: 'Great! What price are you looking for?',
      contentType: 'text',
      status: 'read',
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString()
    },
    {
      id: 'm4',
      chatId: 'chat1',
      senderId: 'user1',
      content: 'I was thinking ₹15 per kg. Is that reasonable?',
      contentType: 'text',
      status: 'delivered',
      createdAt: new Date(Date.now() - 1.5 * 60 * 60 * 1000).toISOString()
    },
    {
      id: 'm5',
      chatId: 'chat1',
      senderId: 'user2',
      content: 'Can you provide more details about the plastic waste?',
      contentType: 'text',
      status: 'sent',
      createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString()
    }
  ]
};

const ChatDetail: React.FC = () => {
  const { chatId } = useParams<{ chatId: string }>();
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [chatPartner, setChatPartner] = useState('');
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');
  const [showVoiceRecorder, setShowVoiceRecorder] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const { 
    isRecording, 
    audioBlob, 
    formattedTime,
    startRecording, 
    stopRecording, 
    cancelRecording 
  } = useVoiceRecorder();
  
  useEffect(() => {
    // Simulate loading messages from backend
    setTimeout(() => {
      if (chatId && mockMessages[chatId]) {
        setMessages(mockMessages[chatId]);
        // Set chat partner name (in a real app, this would come from the chat object)
        setChatPartner('Raj Recyclers');
      }
      setLoading(false);
    }, 1000);
  }, [chatId]);
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const handleSendMessage = () => {
    if (!message.trim() || !chatId || !user) return;
    
    const newMessage: Message = {
      id: `m${Date.now()}`,
      chatId,
      senderId: user.id,
      content: message,
      contentType: 'text',
      status: 'sent',
      createdAt: new Date().toISOString()
    };
    
    setMessages(prev => [...prev, newMessage]);
    setMessage('');
  };
  
  const handleVoiceRecordingComplete = (blob: Blob) => {
    if (!chatId || !user) return;
    
    // In a real app, you would upload the blob to storage
    // and then create a message with the URL
    const newMessage: Message = {
      id: `m${Date.now()}`,
      chatId,
      senderId: user.id,
      content: 'Voice message', // This would be a URL in a real app
      contentType: 'voice',
      status: 'sent',
      createdAt: new Date().toISOString()
    };
    
    setMessages(prev => [...prev, newMessage]);
    setShowVoiceRecorder(false);
  };
  
  const formatMessageTime = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  const formatMessageDate = (dateString: string): string => {
    const date = new Date(dateString);
    const today = new Date();
    
    if (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    ) {
      return 'Today';
    }
    
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (
      date.getDate() === yesterday.getDate() &&
      date.getMonth() === yesterday.getMonth() &&
      date.getFullYear() === yesterday.getFullYear()
    ) {
      return 'Yesterday';
    }
    
    return date.toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long' });
  };
  
  // Group messages by date
  const groupedMessages = messages.reduce<Record<string, Message[]>>((groups, message) => {
    const date = new Date(message.createdAt).toLocaleDateString();
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(message);
    return groups;
  }, {});
  
  return (
    <div className="animate-fade-in flex flex-col h-[calc(100vh-144px)]">
      <div className="flex items-center py-4 px-2 border-b border-gray-200 dark:border-gray-700">
        <Link to="/messages" className="mr-4">
          <ArrowLeft className="h-5 w-5 text-gray-500" />
        </Link>
        
        <div className="flex-shrink-0 w-10 h-10 bg-primary-light/20 rounded-full flex items-center justify-center">
          <div className="text-primary font-semibold">
            {chatPartner.charAt(0)}
          </div>
        </div>
        
        <div className="ml-3">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
            {chatPartner}
          </h2>
        </div>
      </div>
      
      {loading ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {Object.entries(groupedMessages).map(([date, dateMessages]) => (
            <div key={date}>
              <div className="flex justify-center mb-4">
                <span className="px-3 py-1 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 text-xs rounded-full">
                  {formatMessageDate(dateMessages[0].createdAt)}
                </span>
              </div>
              
              <div className="space-y-3">
                {dateMessages.map((msg) => {
                  const isCurrentUser = msg.senderId === user?.id;
                  
                  return (
                    <div 
                      key={msg.id} 
                      className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'}`}
                    >
                      <div 
                        className={`max-w-[75%] rounded-lg px-4 py-2 ${
                          isCurrentUser 
                            ? 'bg-primary text-white' 
                            : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-gray-100'
                        }`}
                      >
                        {msg.contentType === 'text' && (
                          <p>{msg.content}</p>
                        )}
                        
                        {msg.contentType === 'voice' && (
                          <div className="flex items-center space-x-2">
                            <div className="w-32 h-8 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
                            <button className="w-8 h-8 rounded-full bg-white dark:bg-gray-900 flex items-center justify-center">
                              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
                              </svg>
                            </button>
                          </div>
                        )}
                        
                        {msg.contentType === 'image' && (
                          <div className="w-48 h-48 bg-gray-200 dark:bg-gray-700 rounded-lg flex items-center justify-center">
                            <Image className="w-8 h-8 text-gray-400" />
                          </div>
                        )}
                        
                        {msg.contentType === 'location' && (
                          <div className="w-48 h-32 bg-gray-200 dark:bg-gray-700 rounded-lg flex items-center justify-center">
                            <MapPin className="w-8 h-8 text-gray-400" />
                          </div>
                        )}
                        
                        <div 
                          className={`text-xs mt-1 ${
                            isCurrentUser ? 'text-primary-light/80' : 'text-gray-500 dark:text-gray-400'
                          }`}
                        >
                          {formatMessageTime(msg.createdAt)}
                          {isCurrentUser && (
                            <span className="ml-1">
                              {msg.status === 'sent' && '✓'}
                              {msg.status === 'delivered' && '✓✓'}
                              {msg.status === 'read' && (
                                <span className="text-accent">✓✓</span>
                              )}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      )}
      
      <div className="border-t border-gray-200 dark:border-gray-700 p-4">
        {showVoiceRecorder ? (
          <div className="flex items-center bg-gray-50 dark:bg-gray-800 rounded-lg p-3">
            {isRecording ? (
              <div className="flex-1 flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-2 h-2 rounded-full bg-error animate-pulse mr-2"></div>
                  <span className="text-error">{formattedTime()}</span>
                </div>
                <div className="flex space-x-2">
                  <button 
                    onClick={cancelRecording}
                    className="p-2 rounded-full bg-gray-200 dark:bg-gray-700"
                  >
                    <svg className="w-5 h-5 text-error" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                  <button 
                    onClick={stopRecording}
                    className="p-2 rounded-full bg-primary text-white"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h14" />
                    </svg>
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex items-center justify-between">
                <span>Ready to record</span>
                <div className="flex space-x-2">
                  <button 
                    onClick={() => setShowVoiceRecorder(false)}
                    className="p-2 rounded-full bg-gray-200 dark:bg-gray-700"
                  >
                    <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                  <button 
                    onClick={startRecording}
                    className="p-2 rounded-full bg-primary text-white"
                  >
                    <Mic className="w-5 h-5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="flex items-center space-x-2">
            <button 
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
              onClick={() => setShowVoiceRecorder(true)}
            >
              <Mic className="w-5 h-5 text-gray-500" />
            </button>
            
            <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
              <MapPin className="w-5 h-5 text-gray-500" />
            </button>
            
            <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
              <Image className="w-5 h-5 text-gray-500" />
            </button>
            
            <div className="flex-1 relative">
              <input
                type="text"
                placeholder="Type your message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full py-2 px-4 bg-gray-100 dark:bg-gray-800 rounded-full focus:outline-none focus:ring-2 focus:ring-primary"
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    handleSendMessage();
                  }
                }}
              />
              <button
                className="absolute right-2 top-1/2 transform -translate-y-1/2 p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700"
                onClick={() => setMessage('')}
              >
                <ChevronDown className="w-5 h-5 text-gray-400" />
              </button>
            </div>
            
            <button 
              className="p-2 rounded-full bg-primary text-white disabled:opacity-50"
              onClick={handleSendMessage}
              disabled={!message.trim()}
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatDetail;