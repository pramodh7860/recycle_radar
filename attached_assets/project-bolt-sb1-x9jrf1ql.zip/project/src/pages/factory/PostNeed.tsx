import React, { useState } from 'react';
import { Plus, MapPin } from 'lucide-react';
import { translate } from '../../utils/languageService';
import useAuth from '../../hooks/useAuth';
import MapView from '../../components/common/MapView';
import { GeoPoint, MaterialNeed } from '../../types';
import { createMaterialNeed } from '../../utils/firebase';
import { getCurrentLocation } from '../../utils/mapService';
import useOffline from '../../hooks/useOffline';

const materialTypes = [
  { id: 'plastic', name: 'Plastic' },
  { id: 'paper', name: 'Paper & Cardboard' },
  { id: 'metal', name: 'Metal' },
  { id: 'glass', name: 'Glass' },
  { id: 'e-waste', name: 'E-Waste' },
  { id: 'textile', name: 'Textile' },
  { id: 'organic', name: 'Organic Waste' },
];

const PostNeed: React.FC = () => {
  const { user } = useAuth();
  const { online, saveAction } = useOffline();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [materialType, setMaterialType] = useState('');
  const [quantity, setQuantity] = useState(0);
  const [unit, setUnit] = useState('kg');
  const [priceOffered, setPriceOffered] = useState(0);
  const [location, setLocation] = useState<GeoPoint | null>(null);
  const [expiresInDays, setExpiresInDays] = useState(30);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  
  // Get current location on component mount
  React.useEffect(() => {
    const getLocation = async () => {
      try {
        const userLocation = await getCurrentLocation();
        setLocation(userLocation);
      } catch (error) {
        console.error('Error getting location:', error);
      }
    };
    
    getLocation();
  }, []);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user || !materialType || !location) return;
    
    setLoading(true);
    
    try {
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + expiresInDays);
      
      const materialNeed: Partial<MaterialNeed> = {
        factoryOwnerId: user.id,
        title,
        description,
        materialType,
        quantity,
        unit,
        priceOffered,
        location,
        status: 'active',
        expiresAt: expiryDate.toISOString()
      };
      
      if (online) {
        await createMaterialNeed(materialNeed);
      } else {
        await saveAction('create', 'materialNeeds', {
          ...materialNeed,
          createdAt: new Date().toISOString()
        });
      }
      
      setSuccess(true);
      
      // Reset form after short delay
      setTimeout(() => {
        setTitle('');
        setDescription('');
        setMaterialType('');
        setQuantity(0);
        setUnit('kg');
        setPriceOffered(0);
        setExpiresInDays(30);
        setSuccess(false);
      }, 3000);
    } catch (error) {
      console.error('Error posting material need:', error);
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
          <Plus className="h-6 w-6 mr-2 text-primary" />
          {translate('postMaterialNeed')}
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Post your requirements for waste materials
        </p>
      </div>
      
      {success ? (
        <div className="card text-center py-12">
          <div className="w-16 h-16 bg-success/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-success" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-xl font-semibold mb-2">Material Need Posted!</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Your material requirement has been successfully posted.
          </p>
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => setSuccess(false)}
          >
            Post Another Need
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="card">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label htmlFor="title" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Title
                </label>
                <input
                  type="text"
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="input-field"
                  placeholder="E.g., Need PET plastic waste for recycling"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Description (Optional)
                </label>
                <textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="input-field h-24"
                  placeholder="Add more details about your requirements..."
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Material Type
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {materialTypes.map((type) => (
                    <button
                      key={type.id}
                      type="button"
                      onClick={() => setMaterialType(type.id)}
                      className={`px-3 py-2 text-sm rounded-lg border ${
                        materialType === type.id
                          ? 'bg-primary-light/10 border-primary text-primary'
                          : 'border-gray-300 dark:border-gray-600'
                      }`}
                    >
                      {type.name}
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="quantity" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Quantity Needed
                  </label>
                  <input
                    type="number"
                    id="quantity"
                    value={quantity}
                    onChange={(e) => setQuantity(parseFloat(e.target.value))}
                    className="input-field"
                    min="0"
                    step="0.1"
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="unit" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Unit
                  </label>
                  <select
                    id="unit"
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    className="input-field"
                  >
                    <option value="kg">Kilograms (kg)</option>
                    <option value="ton">Tonnes</option>
                    <option value="pc">Pieces</option>
                  </select>
                </div>
              </div>
              
              <div>
                <label htmlFor="priceOffered" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Price Offered (₹ per {unit})
                </label>
                <input
                  type="number"
                  id="priceOffered"
                  value={priceOffered}
                  onChange={(e) => setPriceOffered(parseFloat(e.target.value))}
                  className="input-field"
                  min="0"
                  step="0.01"
                />
              </div>
              
              <div>
                <label htmlFor="expiresInDays" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Listing Expires In (Days)
                </label>
                <select
                  id="expiresInDays"
                  value={expiresInDays}
                  onChange={(e) => setExpiresInDays(parseInt(e.target.value))}
                  className="input-field"
                >
                  <option value={7}>7 days</option>
                  <option value={15}>15 days</option>
                  <option value={30}>30 days</option>
                  <option value={60}>60 days</option>
                  <option value={90}>90 days</option>
                </select>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center">
                <MapPin className="h-4 w-4 mr-1 text-primary" />
                Your Factory Location
              </label>
              
              {location ? (
                <MapView
                  height={300}
                  initialViewState={{
                    latitude: location.latitude,
                    longitude: location.longitude,
                    zoom: 14,
                  }}
                  markers={[
                    {
                      id: 'factory-location',
                      location: location,
                      title: 'Factory Location',
                      color: 'text-secondary'
                    },
                  ]}
                  onMapClick={(newLocation) => setLocation(newLocation)}
                />
              ) : (
                <div className="flex items-center justify-center py-8 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                </div>
              )}
              
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                Click on the map to adjust your exact location if needed
              </p>
            </div>
          </div>
          
          <div className="flex justify-end mt-6">
            <button
              type="submit"
              disabled={loading || !materialType || !location}
              className={`btn btn-primary ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {loading ? (
                <div className="flex items-center">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  <span>Posting...</span>
                </div>
              ) : (
                <span>Post Material Need</span>
              )}
            </button>
          </div>
        </form>
      )}
    </div>
  );
};

export default PostNeed;