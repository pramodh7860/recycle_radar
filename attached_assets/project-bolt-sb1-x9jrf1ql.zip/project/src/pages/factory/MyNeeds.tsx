import React, { useEffect, useState } from 'react';
import { List, Edit, Trash2, Search, Filter, AlertTriangle } from 'lucide-react';
import { translate } from '../../utils/languageService';
import useAuth from '../../hooks/useAuth';
import { MaterialNeed } from '../../types';
import { getMaterialNeeds } from '../../utils/firebase';
import useOffline from '../../hooks/useOffline';
import { getCachedData } from '../../utils/offlineHandler';

const MyNeeds: React.FC = () => {
  const { user } = useAuth();
  const { online } = useOffline();
  
  const [needs, setNeeds] = useState<MaterialNeed[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  useEffect(() => {
    const fetchNeeds = async () => {
      setLoading(true);
      
      try {
        if (user) {
          if (online) {
            // Fetch needs from Firebase
            const data = await getMaterialNeeds({ factoryOwnerId: user.id });
            setNeeds(data as MaterialNeed[]);
          } else {
            // Get cached needs from offline storage
            const cachedNeeds = await getCachedData<MaterialNeed[]>(`user_needs_${user.id}`);
            if (cachedNeeds) {
              setNeeds(cachedNeeds);
            }
          }
        }
      } catch (error) {
        console.error('Error fetching material needs:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchNeeds();
  }, [user, online]);
  
  const filteredNeeds = needs
    .filter(need => filterStatus === 'all' || need.status === filterStatus)
    .filter(need => 
      searchQuery === '' || 
      need.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      need.materialType.toLowerCase().includes(searchQuery.toLowerCase())
    );
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'fulfilled':
        return 'bg-blue-100 text-blue-800';
      case 'expired':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };
  
  const isExpired = (expiresAt: string) => {
    return new Date(expiresAt) < new Date();
  };
  
  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
          <List className="h-6 w-6 mr-2 text-primary" />
          {translate('myNeeds')}
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Manage your material requirements
        </p>
      </div>
      
      <div className="card mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <div className="relative w-full md:w-64">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search materials..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input-field pl-10"
            />
          </div>
          
          <div className="flex space-x-2 items-center">
            <Filter className="h-5 w-5 text-gray-500" />
            <div className="text-sm text-gray-600 dark:text-gray-400">Filter:</div>
            <div className="flex space-x-1">
              <button
                onClick={() => setFilterStatus('all')}
                className={`px-2 py-1 text-xs rounded-full ${
                  filterStatus === 'all' 
                    ? 'bg-primary text-white' 
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setFilterStatus('active')}
                className={`px-2 py-1 text-xs rounded-full ${
                  filterStatus === 'active' 
                    ? 'bg-green-500 text-white' 
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200'
                }`}
              >
                Active
              </button>
              <button
                onClick={() => setFilterStatus('fulfilled')}
                className={`px-2 py-1 text-xs rounded-full ${
                  filterStatus === 'fulfilled' 
                    ? 'bg-blue-500 text-white' 
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200'
                }`}
              >
                Fulfilled
              </button>
              <button
                onClick={() => setFilterStatus('expired')}
                className={`px-2 py-1 text-xs rounded-full ${
                  filterStatus === 'expired' 
                    ? 'bg-gray-500 text-white' 
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200'
                }`}
              >
                Expired
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-400">Loading your material needs...</p>
        </div>
      ) : (
        <>
          {!online && (
            <div className="mb-6 bg-warning/10 border border-warning/20 rounded-lg p-4 flex items-start">
              <AlertTriangle className="h-5 w-5 text-warning flex-shrink-0 mt-0.5 mr-3" />
              <div>
                <p className="font-medium text-warning">You're currently offline</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  You're viewing cached data. Some actions may be unavailable until you're back online.
                </p>
              </div>
            </div>
          )}
          
          {filteredNeeds.length === 0 ? (
            <div className="card text-center py-12">
              <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
                <List className="h-8 w-8 text-gray-400" />
              </div>
              
              {searchQuery || filterStatus !== 'all' ? (
                <>
                  <h2 className="text-xl font-semibold mb-2">No matching material needs found</h2>
                  <p className="text-gray-600 dark:text-gray-400 mb-6">
                    Try changing your search or filter criteria
                  </p>
                  <button
                    type="button"
                    className="btn btn-sm btn-outline text-primary"
                    onClick={() => {
                      setSearchQuery('');
                      setFilterStatus('all');
                    }}
                  >
                    Clear Filters
                  </button>
                </>
              ) : (
                <>
                  <h2 className="text-xl font-semibold mb-2">No material needs yet</h2>
                  <p className="text-gray-600 dark:text-gray-400 mb-6">
                    Start by posting your first material requirement
                  </p>
                  <a href="/post-need" className="btn btn-primary">
                    Post Material Need
                  </a>
                </>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredNeeds.map((need) => {
                const expired = isExpired(need.expiresAt);
                const actualStatus = expired && need.status === 'active' ? 'expired' : need.status;
                
                return (
                  <div key={need.id} className="card">
                    <div className="flex flex-col md:flex-row md:items-center">
                      <div className="flex-1">
                        <div className="flex items-center flex-wrap gap-2">
                          <h3 className="font-semibold text-lg">{need.title}</h3>
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(actualStatus)}`}>
                            {actualStatus.charAt(0).toUpperCase() + actualStatus.slice(1)}
                          </span>
                        </div>
                        
                        {need.description && (
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            {need.description}
                          </p>
                        )}
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                          <div>
                            <span className="text-xs text-gray-500 dark:text-gray-400 block">Material Type</span>
                            <span className="font-medium">
                              {need.materialType.charAt(0).toUpperCase() + need.materialType.slice(1)}
                            </span>
                          </div>
                          
                          <div>
                            <span className="text-xs text-gray-500 dark:text-gray-400 block">Quantity</span>
                            <span className="font-medium">{need.quantity} {need.unit}</span>
                          </div>
                          
                          <div>
                            <span className="text-xs text-gray-500 dark:text-gray-400 block">Price Offered</span>
                            <span className="font-medium">
                              {need.priceOffered ? `₹${need.priceOffered}/${need.unit}` : 'Negotiable'}
                            </span>
                          </div>
                          
                          <div>
                            <span className="text-xs text-gray-500 dark:text-gray-400 block">Expires On</span>
                            <span className={`font-medium ${expired ? 'text-error' : ''}`}>
                              {formatDate(need.expiresAt)}
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-4 md:mt-0 flex md:flex-col space-x-2 md:space-x-0 md:space-y-2">
                        <button 
                          className="flex-1 md:w-full btn btn-sm btn-outline text-primary"
                          disabled={!online || actualStatus !== 'active'}
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </button>
                        
                        <button 
                          className="flex-1 md:w-full btn btn-sm btn-outline text-error"
                          disabled={!online}
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default MyNeeds;