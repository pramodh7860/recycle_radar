import React, { useState, useEffect } from 'react';
import { Search, Users, MapPin, Filter, ArrowUpDown, MessageSquare } from 'lucide-react';
import { translate } from '../../utils/languageService';
import MapView from '../../components/common/MapView';
import useAuth from '../../hooks/useAuth';
import { GeoPoint, WasteListing } from '../../types';
import { getCurrentLocation } from '../../utils/mapService';

// Mock vendor listings data - would be fetched from Firebase in a real implementation
const mockListings = [
  {
    id: '1',
    vendorId: 'v1',
    vendorName: 'Raj Recyclers',
    title: 'Clean PET Bottles',
    description: 'Sorted and cleaned PET bottles ready for recycling',
    wasteType: 'plastic',
    quantity: 200,
    unit: 'kg',
    price: 15,
    location: { latitude: 28.6129, longitude: 77.2295 },
    status: 'available',
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: '2',
    vendorId: 'v2',
    vendorName: 'Green Paper Co',
    title: 'Used Cardboard Boxes',
    description: 'Flattened cardboard boxes from commercial packaging',
    wasteType: 'paper',
    quantity: 150,
    unit: 'kg',
    price: 8,
    location: { latitude: 28.6239, longitude: 77.2100 },
    status: 'available',
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: '3',
    vendorId: 'v3',
    vendorName: 'Metal Scrap Dealers',
    title: 'Aluminum Scrap',
    description: 'Clean aluminum scrap from industrial processes',
    wasteType: 'metal',
    quantity: 100,
    unit: 'kg',
    price: 120,
    location: { latitude: 28.5929, longitude: 77.2390 },
    status: 'available',
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: '4',
    vendorId: 'v4',
    vendorName: 'Glass Recovery',
    title: 'Mixed Glass Waste',
    description: 'Mixed color glass bottles and jars',
    wasteType: 'glass',
    quantity: 180,
    unit: 'kg',
    price: 6,
    location: { latitude: 28.6339, longitude: 77.2290 },
    status: 'available',
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
  }
];

const FindVendors: React.FC = () => {
  const { user } = useAuth();
  const [userLocation, setUserLocation] = useState<GeoPoint | null>(null);
  const [selectedListing, setSelectedListing] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'distance' | 'price' | 'date'>('distance');
  const [mapView, setMapView] = useState(true);
  
  useEffect(() => {
    const getLocation = async () => {
      try {
        const location = await getCurrentLocation();
        setUserLocation(location);
      } catch (error) {
        console.error('Error getting location:', error);
      }
    };
    
    getLocation();
  }, []);
  
  const filteredListings = mockListings
    .filter(listing => 
      searchQuery === '' || 
      listing.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      listing.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      listing.vendorName.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .filter(listing => 
      filterType === 'all' || 
      listing.wasteType === filterType
    );
  
  const sortedListings = [...filteredListings].sort((a, b) => {
    if (sortBy === 'price') {
      return a.price - b.price;
    } else if (sortBy === 'date') {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
    
    // Sort by distance if userLocation is available
    if (userLocation) {
      const distA = calculateDistance(userLocation, a.location);
      const distB = calculateDistance(userLocation, b.location);
      return distA - distB;
    }
    
    return 0;
  });
  
  const calculateDistance = (point1: GeoPoint, point2: GeoPoint): number => {
    // Simple distance calculation between two points (in km)
    const R = 6371; // Radius of the Earth in km
    const dLat = deg2rad(point2.latitude - point1.latitude);
    const dLon = deg2rad(point2.longitude - point1.longitude);
    
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(deg2rad(point1.latitude)) * Math.cos(deg2rad(point2.latitude)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
      
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c;
    
    return distance;
  };
  
  const deg2rad = (deg: number): number => {
    return deg * (Math.PI / 180);
  };
  
  const formatDistance = (distance: number): string => {
    if (distance < 1) {
      return `${(distance * 1000).toFixed(0)} m`;
    }
    return `${distance.toFixed(1)} km`;
  };
  
  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      return 'Today';
    } else if (diffDays === 1) {
      return 'Yesterday';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else {
      return date.toLocaleDateString();
    }
  };
  
  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
          <Users className="h-6 w-6 mr-2 text-primary" />
          {translate('findVendors')}
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Find vendors with available waste materials nearby
        </p>
      </div>
      
      <div className="card mb-6">
        <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
          <div className="relative w-full md:w-64">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search waste materials..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input-field pl-10"
            />
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <Filter className="h-5 w-5 text-gray-500 mr-2" />
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="input-field text-sm py-2"
              >
                <option value="all">All Materials</option>
                <option value="plastic">Plastic</option>
                <option value="paper">Paper</option>
                <option value="metal">Metal</option>
                <option value="glass">Glass</option>
                <option value="textile">Textile</option>
                <option value="e-waste">E-Waste</option>
              </select>
            </div>
            
            <div className="flex items-center">
              <ArrowUpDown className="h-5 w-5 text-gray-500 mr-2" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'distance' | 'price' | 'date')}
                className="input-field text-sm py-2"
              >
                <option value="distance">Sort by Distance</option>
                <option value="price">Sort by Price (Low to High)</option>
                <option value="date">Sort by Date (Newest)</option>
              </select>
            </div>
          </div>
          
          <div className="md:ml-auto flex space-x-2">
            <button
              onClick={() => setMapView(false)}
              className={`p-2 rounded-lg ${
                !mapView
                  ? 'bg-primary-light/10 text-primary'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
            >
              <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
              </svg>
            </button>
            <button
              onClick={() => setMapView(true)}
              className={`p-2 rounded-lg ${
                mapView
                  ? 'bg-primary-light/10 text-primary'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
            >
              <MapPin className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
      
      {mapView ? (
        <div className="card">
          <MapView
            height={500}
            initialViewState={
              userLocation
                ? { latitude: userLocation.latitude, longitude: userLocation.longitude, zoom: 12 }
                : undefined
            }
            markers={[
              ...(userLocation ? [{
                id: 'user',
                location: userLocation,
                title: 'Your Location',
                color: 'text-accent'
              }] : []),
              ...sortedListings.map(listing => ({
                id: listing.id,
                location: listing.location,
                title: listing.title,
                color: 'text-primary'
              }))
            ]}
            onMarkerClick={(id) => setSelectedListing(id === 'user' ? null : id)}
          />
          
          {selectedListing && (
            <div className="mt-4 border-t border-gray-200 dark:border-gray-700 pt-4">
              {sortedListings
                .filter(listing => listing.id === selectedListing)
                .map(listing => (
                  <div key={listing.id} className="flex flex-col sm:flex-row sm:items-center">
                    <div className="flex-1">
                      <div className="flex items-center">
                        <h3 className="font-semibold text-lg">{listing.title}</h3>
                        <span className="ml-2 text-sm text-gray-500">{listing.vendorName}</span>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                        {listing.description}
                      </p>
                      <div className="flex flex-wrap mt-2">
                        <span className="px-2 py-0.5 text-xs bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-full mr-1 mb-1">
                          {listing.wasteType.charAt(0).toUpperCase() + listing.wasteType.slice(1)}
                        </span>
                        <span className="px-2 py-0.5 text-xs bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-full mr-1 mb-1">
                          {listing.quantity} {listing.unit}
                        </span>
                        <span className="px-2 py-0.5 text-xs bg-primary-light/10 text-primary rounded-full mr-1 mb-1">
                          ₹{listing.price}/{listing.unit}
                        </span>
                      </div>
                    </div>
                    <div className="mt-4 sm:mt-0 flex space-x-2">
                      <button className="btn btn-sm btn-primary flex items-center">
                        <MessageSquare className="h-4 w-4 mr-1" />
                        Contact Vendor
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {sortedListings.length === 0 ? (
            <div className="card text-center py-8">
              <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-gray-400" />
              </div>
              <h2 className="text-xl font-semibold mb-2">No waste listings found</h2>
              <p className="text-gray-600 dark:text-gray-400">
                Try changing your search criteria or filters
              </p>
            </div>
          ) : (
            sortedListings.map(listing => (
              <div key={listing.id} className="card">
                <div className="flex flex-col md:flex-row md:items-center">
                  <div className="flex-1">
                    <div className="flex items-center">
                      <h3 className="font-semibold text-lg">{listing.title}</h3>
                      <span className="ml-2 text-sm text-gray-500 dark:text-gray-400">
                        by {listing.vendorName}
                      </span>
                    </div>
                    
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                      {listing.description}
                    </p>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                      <div>
                        <span className="text-xs text-gray-500 dark:text-gray-400 block">Material Type</span>
                        <span className="font-medium">
                          {listing.wasteType.charAt(0).toUpperCase() + listing.wasteType.slice(1)}
                        </span>
                      </div>
                      
                      <div>
                        <span className="text-xs text-gray-500 dark:text-gray-400 block">Quantity</span>
                        <span className="font-medium">{listing.quantity} {listing.unit}</span>
                      </div>
                      
                      <div>
                        <span className="text-xs text-gray-500 dark:text-gray-400 block">Price</span>
                        <span className="font-medium text-primary">₹{listing.price}/{listing.unit}</span>
                      </div>
                      
                      <div>
                        <span className="text-xs text-gray-500 dark:text-gray-400 block">Posted</span>
                        <span className="font-medium">{formatDate(listing.createdAt)}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center mt-3">
                      <MapPin className="h-4 w-4 text-accent mr-1" />
                      <span className="text-sm text-accent">
                        {userLocation
                          ? formatDistance(calculateDistance(userLocation, listing.location))
                          : 'Distance unavailable'}
                      </span>
                    </div>
                  </div>
                  
                  <div className="mt-4 md:mt-0">
                    <button className="w-full btn btn-primary flex items-center justify-center">
                      <MessageSquare className="h-4 w-4 mr-1" />
                      Contact Vendor
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};

export default FindVendors;