import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Trash2, Factory, BarChart } from 'lucide-react';
import { translate } from '../../utils/languageService';
import { UserRole } from '../../types';

const RoleSelection: React.FC = () => {
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const navigate = useNavigate();
  
  const handleContinue = () => {
    if (selectedRole) {
      navigate('/select-language', { state: { role: selectedRole } });
    }
  };
  
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 px-4 py-12 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white dark:bg-gray-800 p-8 rounded-xl shadow-md">
        <div>
          <h2 className="text-center text-3xl font-extrabold text-gray-900 dark:text-white">
            {translate('chooseRole')}
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600 dark:text-gray-400">
            Select your role in the recycling ecosystem
          </p>
        </div>
        
        <div className="mt-8 space-y-4">
          <button
            type="button"
            onClick={() => setSelectedRole(UserRole.VENDOR)}
            className={`w-full flex items-center p-4 rounded-lg transition-all ${
              selectedRole === UserRole.VENDOR
                ? 'bg-primary-light/10 border-2 border-primary'
                : 'bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700'
            }`}
          >
            <div className="w-12 h-12 rounded-full bg-primary-light/20 flex items-center justify-center">
              <Trash2 className="h-6 w-6 text-primary" />
            </div>
            <div className="ml-4 text-left">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                {translate('vendor')}
              </h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                I collect and sell waste materials
              </p>
            </div>
          </button>
          
          <button
            type="button"
            onClick={() => setSelectedRole(UserRole.FACTORY_OWNER)}
            className={`w-full flex items-center p-4 rounded-lg transition-all ${
              selectedRole === UserRole.FACTORY_OWNER
                ? 'bg-primary-light/10 border-2 border-primary'
                : 'bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700'
            }`}
          >
            <div className="w-12 h-12 rounded-full bg-primary-light/20 flex items-center justify-center">
              <Factory className="h-6 w-6 text-primary" />
            </div>
            <div className="ml-4 text-left">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                {translate('factoryOwner')}
              </h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                I buy waste materials for recycling
              </p>
            </div>
          </button>
          
          <button
            type="button"
            onClick={() => setSelectedRole(UserRole.ENTREPRENEUR)}
            className={`w-full flex items-center p-4 rounded-lg transition-all ${
              selectedRole === UserRole.ENTREPRENEUR
                ? 'bg-primary-light/10 border-2 border-primary'
                : 'bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700'
            }`}
          >
            <div className="w-12 h-12 rounded-full bg-primary-light/20 flex items-center justify-center">
              <BarChart className="h-6 w-6 text-primary" />
            </div>
            <div className="ml-4 text-left">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                {translate('entrepreneur')}
              </h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                I want to start a recycling business
              </p>
            </div>
          </button>
        </div>
        
        <div className="mt-8">
          <button
            type="button"
            onClick={handleContinue}
            disabled={!selectedRole}
            className={`w-full btn ${
              selectedRole ? 'btn-primary' : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            {translate('next')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default RoleSelection;