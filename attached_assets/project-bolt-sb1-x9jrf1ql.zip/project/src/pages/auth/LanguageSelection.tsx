import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { setCurrentLanguage } from '../../utils/languageService';
import { Language, UserRole } from '../../types';
import { translate } from '../../utils/languageService';

interface LocationState {
  role?: UserRole;
}

const LanguageSelection: React.FC = () => {
  const [selectedLanguage, setSelectedLanguage] = useState<Language | null>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const state = location.state as LocationState;
  
  const handleContinue = () => {
    if (selectedLanguage) {
      setCurrentLanguage(selectedLanguage);
      
      if (state?.role) {
        navigate('/register', { state: { role: state.role, language: selectedLanguage } });
      } else {
        navigate('/register', { state: { language: selectedLanguage } });
      }
    }
  };
  
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 px-4 py-12 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white dark:bg-gray-800 p-8 rounded-xl shadow-md">
        <div>
          <h2 className="text-center text-3xl font-extrabold text-gray-900 dark:text-white">
            {translate('selectLanguage')}
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600 dark:text-gray-400">
            Choose your preferred language for the application
          </p>
        </div>
        
        <div className="mt-8 grid grid-cols-2 gap-4">
          <button
            type="button"
            onClick={() => setSelectedLanguage(Language.ENGLISH)}
            className={`flex flex-col items-center justify-center p-6 rounded-lg transition-all ${
              selectedLanguage === Language.ENGLISH
                ? 'bg-primary-light/10 border-2 border-primary'
                : 'bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700'
            }`}
          >
            <span className="text-xl font-medium text-gray-900 dark:text-white">English</span>
          </button>
          
          <button
            type="button"
            onClick={() => setSelectedLanguage(Language.HINDI)}
            className={`flex flex-col items-center justify-center p-6 rounded-lg transition-all ${
              selectedLanguage === Language.HINDI
                ? 'bg-primary-light/10 border-2 border-primary'
                : 'bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700'
            }`}
          >
            <span className="text-xl font-medium text-gray-900 dark:text-white">हिंदी</span>
          </button>
          
          <button
            type="button"
            onClick={() => setSelectedLanguage(Language.TAMIL)}
            className={`flex flex-col items-center justify-center p-6 rounded-lg transition-all ${
              selectedLanguage === Language.TAMIL
                ? 'bg-primary-light/10 border-2 border-primary'
                : 'bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700'
            }`}
          >
            <span className="text-xl font-medium text-gray-900 dark:text-white">தமிழ்</span>
          </button>
          
          <button
            type="button"
            onClick={() => setSelectedLanguage(Language.TELUGU)}
            className={`flex flex-col items-center justify-center p-6 rounded-lg transition-all ${
              selectedLanguage === Language.TELUGU
                ? 'bg-primary-light/10 border-2 border-primary'
                : 'bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700'
            }`}
          >
            <span className="text-xl font-medium text-gray-900 dark:text-white">తెలుగు</span>
          </button>
        </div>
        
        <div className="mt-8 flex space-x-4">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="w-1/3 btn btn-outline text-primary"
          >
            {translate('back')}
          </button>
          
          <button
            type="button"
            onClick={handleContinue}
            disabled={!selectedLanguage}
            className={`w-2/3 btn ${
              selectedLanguage ? 'btn-primary' : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            {translate('next')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default LanguageSelection;