import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { UserPlus, Mail, Lock, User, AlertCircle, Phone } from 'lucide-react';
import useAuth from '../../hooks/useAuth';
import { translate } from '../../utils/languageService';
import LanguageSelector from '../../components/common/LanguageSelector';
import { UserRole, Language } from '../../types';

const Register: React.FC = () => {
  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState<UserRole | ''>('');
  const [language, setLanguage] = useState<Language>(Language.ENGLISH);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { register } = useAuth();
  const navigate = useNavigate();
  
  const validateStep1 = () => {
    if (!name) {
      setError('Please enter your name');
      return false;
    }
    if (!email && !phone) {
      setError('Please enter either email or phone');
      return false;
    }
    if (email && !/\S+@\S+\.\S+/.test(email)) {
      setError('Please enter a valid email');
      return false;
    }
    if (phone && !/^\d{10}$/.test(phone)) {
      setError('Please enter a valid 10-digit phone number');
      return false;
    }
    return true;
  };
  
  const validateStep2 = () => {
    if (!password) {
      setError('Please enter a password');
      return false;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return false;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return false;
    }
    return true;
  };
  
  const validateStep3 = () => {
    if (!role) {
      setError('Please select a role');
      return false;
    }
    return true;
  };
  
  const handleNextStep = () => {
    setError('');
    
    if (step === 1 && validateStep1()) {
      setStep(2);
    } else if (step === 2 && validateStep2()) {
      setStep(3);
    } else if (step === 3 && validateStep3()) {
      setStep(4);
    }
  };
  
  const handlePrevStep = () => {
    setError('');
    if (step > 1) {
      setStep(step - 1);
    }
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateStep1() || !validateStep2() || !validateStep3()) {
      return;
    }
    
    try {
      setError('');
      setLoading(true);
      
      if (role && role !== '') {
        const user = await register(email, password, name, role as UserRole, language);
        
        if (user) {
          navigate('/dashboard');
        } else {
          setError('Failed to register');
        }
      } else {
        setError('Please select a role');
      }
    } catch (err) {
      setError('Failed to create an account');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 px-4 sm:px-6 lg:px-8">
      <div className="absolute top-4 right-4">
        <LanguageSelector onChange={(lang) => setLanguage(lang)} />
      </div>
      
      <div className="max-w-md w-full space-y-8 bg-white dark:bg-gray-800 p-8 rounded-xl shadow-md">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900 dark:text-white">
            {translate('register')}
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600 dark:text-gray-400">
            {translate('welcome')}
          </p>
          
          <div className="flex justify-center mt-6">
            <div className="flex items-center">
              <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                step >= 1 ? 'bg-primary text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                1
              </div>
              <div className={`w-10 h-1 ${
                step > 1 ? 'bg-primary' : 'bg-gray-200'
              }`}></div>
              <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                step >= 2 ? 'bg-primary text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                2
              </div>
              <div className={`w-10 h-1 ${
                step > 2 ? 'bg-primary' : 'bg-gray-200'
              }`}></div>
              <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                step >= 3 ? 'bg-primary text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                3
              </div>
              <div className={`w-10 h-1 ${
                step > 3 ? 'bg-primary' : 'bg-gray-200'
              }`}></div>
              <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                step >= 4 ? 'bg-primary text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                4
              </div>
            </div>
          </div>
        </div>
        
        {error && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4 flex items-start">
            <AlertCircle className="text-red-500 mr-3 h-5 w-5 flex-shrink-0" />
            <p className="text-sm text-red-600 dark:text-red-400">{error}</p>
          </div>
        )}
        
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {/* Step 1: Personal Information */}
          {step === 1 && (
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">Personal Information</h3>
              
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {translate('name')}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="input-field pl-10"
                    placeholder="Full name"
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {translate('email')}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="input-field pl-10"
                    placeholder="name@example.com"
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {translate('phone')}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Phone className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    id="phone"
                    name="phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="input-field pl-10"
                    placeholder="10-digit number"
                  />
                </div>
                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  We'll need either email or phone for account verification
                </p>
              </div>
            </div>
          )}
          
          {/* Step 2: Password */}
          {step === 2 && (
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">Create Password</h3>
              
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {translate('password')}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    id="password"
                    name="password"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="input-field pl-10"
                    placeholder="••••••••"
                  />
                </div>
                <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                  Password must be at least 6 characters
                </p>
              </div>
              
              <div>
                <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {translate('confirmPassword')}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    id="confirmPassword"
                    name="confirmPassword"
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="input-field pl-10"
                    placeholder="••••••••"
                  />
                </div>
              </div>
            </div>
          )}
          
          {/* Step 3: Role Selection */}
          {step === 3 && (
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">{translate('chooseRole')}</h3>
              
              <div className="grid grid-cols-1 gap-4">
                <button
                  type="button"
                  onClick={() => setRole(UserRole.VENDOR)}
                  className={`flex items-center p-4 rounded-lg border-2 ${
                    role === UserRole.VENDOR 
                      ? 'border-primary bg-primary-light/10' 
                      : 'border-gray-300 dark:border-gray-600'
                  }`}
                >
                  <div className="w-10 h-10 bg-primary-light/20 rounded-full flex items-center justify-center mr-3">
                    <User className="w-5 h-5 text-primary" />
                  </div>
                  <div className="text-left">
                    <h4 className="font-medium text-gray-900 dark:text-white">{translate('vendor')}</h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Upload waste for recycling</p>
                  </div>
                </button>
                
                <button
                  type="button"
                  onClick={() => setRole(UserRole.FACTORY_OWNER)}
                  className={`flex items-center p-4 rounded-lg border-2 ${
                    role === UserRole.FACTORY_OWNER 
                      ? 'border-primary bg-primary-light/10' 
                      : 'border-gray-300 dark:border-gray-600'
                  }`}
                >
                  <div className="w-10 h-10 bg-primary-light/20 rounded-full flex items-center justify-center mr-3">
                    <UserPlus className="w-5 h-5 text-primary" />
                  </div>
                  <div className="text-left">
                    <h4 className="font-medium text-gray-900 dark:text-white">{translate('factoryOwner')}</h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Find waste materials for your factory</p>
                  </div>
                </button>
                
                <button
                  type="button"
                  onClick={() => setRole(UserRole.ENTREPRENEUR)}
                  className={`flex items-center p-4 rounded-lg border-2 ${
                    role === UserRole.ENTREPRENEUR 
                      ? 'border-primary bg-primary-light/10' 
                      : 'border-gray-300 dark:border-gray-600'
                  }`}
                >
                  <div className="w-10 h-10 bg-primary-light/20 rounded-full flex items-center justify-center mr-3">
                    <UserPlus className="w-5 h-5 text-primary" />
                  </div>
                  <div className="text-left">
                    <h4 className="font-medium text-gray-900 dark:text-white">{translate('entrepreneur')}</h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Get recommendations for recycling units</p>
                  </div>
                </button>
              </div>
            </div>
          )}
          
          {/* Step 4: Language Selection */}
          {step === 4 && (
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">{translate('selectLanguage')}</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setLanguage(Language.ENGLISH)}
                  className={`flex flex-col items-center p-4 rounded-lg border-2 ${
                    language === Language.ENGLISH 
                      ? 'border-primary bg-primary-light/10' 
                      : 'border-gray-300 dark:border-gray-600'
                  }`}
                >
                  <span className="text-lg font-medium">English</span>
                </button>
                
                <button
                  type="button"
                  onClick={() => setLanguage(Language.HINDI)}
                  className={`flex flex-col items-center p-4 rounded-lg border-2 ${
                    language === Language.HINDI 
                      ? 'border-primary bg-primary-light/10' 
                      : 'border-gray-300 dark:border-gray-600'
                  }`}
                >
                  <span className="text-lg font-medium">हिंदी</span>
                </button>
                
                <button
                  type="button"
                  onClick={() => setLanguage(Language.TAMIL)}
                  className={`flex flex-col items-center p-4 rounded-lg border-2 ${
                    language === Language.TAMIL 
                      ? 'border-primary bg-primary-light/10' 
                      : 'border-gray-300 dark:border-gray-600'
                  }`}
                >
                  <span className="text-lg font-medium">தமிழ்</span>
                </button>
                
                <button
                  type="button"
                  onClick={() => setLanguage(Language.TELUGU)}
                  className={`flex flex-col items-center p-4 rounded-lg border-2 ${
                    language === Language.TELUGU 
                      ? 'border-primary bg-primary-light/10' 
                      : 'border-gray-300 dark:border-gray-600'
                  }`}
                >
                  <span className="text-lg font-medium">తెలుగు</span>
                </button>
              </div>
            </div>
          )}
          
          <div className="flex justify-between">
            {step > 1 && (
              <button
                type="button"
                onClick={handlePrevStep}
                className="btn btn-outline text-primary"
              >
                {translate('back')}
              </button>
            )}
            
            {step < 4 ? (
              <button
                type="button"
                onClick={handleNextStep}
                className="btn btn-primary ml-auto"
              >
                {translate('next')}
              </button>
            ) : (
              <button
                type="submit"
                disabled={loading}
                className="btn btn-primary ml-auto"
              >
                {loading ? (
                  <div className="flex items-center justify-center">
                    <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-white mr-2"></div>
                    <span>Registering...</span>
                  </div>
                ) : (
                  <span>{translate('register')}</span>
                )}
              </button>
            )}
          </div>
          
          <div className="text-center mt-4">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Already have an account?{' '}
              <Link to="/login" className="font-medium text-primary hover:text-primary-dark">
                {translate('login')}
              </Link>
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Register;