import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Upload, 
  Search, 
  MessageSquare, 
  MapPin, 
  BarChart, 
  FileText,
  ChevronRight,
  Plus,
  Activity
} from 'lucide-react';
import { UserRole } from '../types';
import useAuth from '../hooks/useAuth';
import useOffline from '../hooks/useOffline';
import { translate } from '../utils/languageService';
import MapView from '../components/common/MapView';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const { online, pendingActions } = useOffline();
  const [recentActivity, setRecentActivity] = useState<any[]>([]);
  
  useEffect(() => {
    // Simulated recent activity data
    const activityData = [
      {
        id: '1',
        type: 'message',
        title: 'New message from Rahul',
        time: '2 hours ago'
      },
      {
        id: '2',
        type: 'listing',
        title: 'Your waste listing received an offer',
        time: '1 day ago'
      },
      {
        id: '3',
        type: 'need',
        title: 'New plastic waste available nearby',
        time: '2 days ago'
      }
    ];
    
    setRecentActivity(activityData);
  }, []);
  
  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          {translate('dashboard')}
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          {user?.name ? `${translate('welcome')}, ${user.name}` : translate('welcome')}
        </p>
      </div>
      
      {!online && pendingActions > 0 && (
        <div className="bg-warning/10 border border-warning/30 rounded-lg p-4 mb-6 flex items-center justify-between">
          <div>
            <p className="font-medium text-warning">{pendingActions} offline actions pending</p>
            <p className="text-sm text-gray-600 dark:text-gray-400">These will sync when you're back online</p>
          </div>
        </div>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-6">
          {/* Quick Actions */}
          <div className="card">
            <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {user?.role === UserRole.VENDOR && (
                <>
                  <Link 
                    to="/upload-waste" 
                    className="flex flex-col items-center p-4 bg-primary-light/10 rounded-lg hover:bg-primary-light/20 transition-colors"
                  >
                    <Upload className="h-6 w-6 text-primary mb-2" />
                    <span className="text-sm text-center font-medium">{translate('uploadWaste')}</span>
                  </Link>
                  
                  <Link 
                    to="/find-factories" 
                    className="flex flex-col items-center p-4 bg-secondary-light/10 rounded-lg hover:bg-secondary-light/20 transition-colors"
                  >
                    <Search className="h-6 w-6 text-secondary mb-2" />
                    <span className="text-sm text-center font-medium">{translate('findFactories')}</span>
                  </Link>
                </>
              )}
              
              {user?.role === UserRole.FACTORY_OWNER && (
                <>
                  <Link 
                    to="/post-need" 
                    className="flex flex-col items-center p-4 bg-primary-light/10 rounded-lg hover:bg-primary-light/20 transition-colors"
                  >
                    <Plus className="h-6 w-6 text-primary mb-2" />
                    <span className="text-sm text-center font-medium">{translate('postMaterialNeed')}</span>
                  </Link>
                  
                  <Link 
                    to="/find-vendors" 
                    className="flex flex-col items-center p-4 bg-secondary-light/10 rounded-lg hover:bg-secondary-light/20 transition-colors"
                  >
                    <Search className="h-6 w-6 text-secondary mb-2" />
                    <span className="text-sm text-center font-medium">{translate('findVendors')}</span>
                  </Link>
                </>
              )}
              
              {user?.role === UserRole.ENTREPRENEUR && (
                <>
                  <Link 
                    to="/feasibility-tool" 
                    className="flex flex-col items-center p-4 bg-primary-light/10 rounded-lg hover:bg-primary-light/20 transition-colors"
                  >
                    <BarChart className="h-6 w-6 text-primary mb-2" />
                    <span className="text-sm text-center font-medium">{translate('feasibilityTool')}</span>
                  </Link>
                  
                  <Link 
                    to="/subsidies" 
                    className="flex flex-col items-center p-4 bg-secondary-light/10 rounded-lg hover:bg-secondary-light/20 transition-colors"
                  >
                    <FileText className="h-6 w-6 text-secondary mb-2" />
                    <span className="text-sm text-center font-medium">{translate('subsidies')}</span>
                  </Link>
                </>
              )}
              
              {/* Common actions for all roles */}
              <Link 
                to="/messages" 
                className="flex flex-col items-center p-4 bg-accent-light/10 rounded-lg hover:bg-accent-light/20 transition-colors"
              >
                <MessageSquare className="h-6 w-6 text-accent mb-2" />
                <span className="text-sm text-center font-medium">{translate('messages')}</span>
              </Link>
              
              <Link 
                to="/map" 
                className="flex flex-col items-center p-4 bg-success/10 rounded-lg hover:bg-success/20 transition-colors"
              >
                <MapPin className="h-6 w-6 text-success mb-2" />
                <span className="text-sm text-center font-medium">{translate('location')}</span>
              </Link>
            </div>
          </div>
          
          {/* Recent Activity */}
          <div className="card">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Recent Activity</h2>
              <Link to="/activity" className="text-sm text-primary flex items-center">
                View all <ChevronRight className="h-4 w-4 ml-1" />
              </Link>
            </div>
            
            {recentActivity.length > 0 ? (
              <div className="space-y-3">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-start p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div className="bg-primary-light/20 p-2 rounded-full mr-3">
                      {activity.type === 'message' && <MessageSquare className="h-5 w-5 text-primary" />}
                      {activity.type === 'listing' && <Upload className="h-5 w-5 text-primary" />}
                      {activity.type === 'need' && <Activity className="h-5 w-5 text-primary" />}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">{activity.title}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-gray-500 dark:text-gray-400">
                <Activity className="h-10 w-10 mx-auto mb-2 opacity-30" />
                <p>No recent activity</p>
              </div>
            )}
          </div>
        </div>
        
        <div className="space-y-6">
          {/* Map Section */}
          <div className="card">
            <h2 className="text-lg font-semibold mb-4">Nearby Activity</h2>
            <MapView 
              height={300}
              showControls={true}
              markers={[
                { id: '1', location: { latitude: 28.6139, longitude: 77.2090 }, title: 'Factory', color: 'text-secondary' },
                { id: '2', location: { latitude: 28.6339, longitude: 77.2290 }, title: 'Vendor', color: 'text-accent' },
              ]}
            />
          </div>
          
          {/* Role-specific Section */}
          <div className="card">
            <h2 className="text-lg font-semibold mb-4">
              {user?.role === UserRole.VENDOR && 'Your Waste Listings'}
              {user?.role === UserRole.FACTORY_OWNER && 'Your Material Needs'}
              {user?.role === UserRole.ENTREPRENEUR && 'Recycling Insights'}
            </h2>
            
            {user?.role === UserRole.VENDOR && (
              <div className="space-y-3">
                <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg flex justify-between items-center">
                  <div>
                    <p className="font-medium">Plastic Waste (20kg)</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Posted 2 days ago</p>
                  </div>
                  <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">Available</span>
                </div>
                <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg flex justify-between items-center">
                  <div>
                    <p className="font-medium">Paper Waste (15kg)</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Posted 1 week ago</p>
                  </div>
                  <span className="px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full">Pending</span>
                </div>
                <Link to="/my-listings" className="text-sm text-primary flex items-center justify-center mt-2">
                  View all listings <ChevronRight className="h-4 w-4 ml-1" />
                </Link>
              </div>
            )}
            
            {user?.role === UserRole.FACTORY_OWNER && (
              <div className="space-y-3">
                <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg flex justify-between items-center">
                  <div>
                    <p className="font-medium">PET Plastic (100kg needed)</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Posted 3 days ago</p>
                  </div>
                  <span className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">Active</span>
                </div>
                <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg flex justify-between items-center">
                  <div>
                    <p className="font-medium">Cardboard (50kg needed)</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Posted 5 days ago</p>
                  </div>
                  <span className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">Active</span>
                </div>
                <Link to="/my-needs" className="text-sm text-primary flex items-center justify-center mt-2">
                  View all needs <ChevronRight className="h-4 w-4 ml-1" />
                </Link>
              </div>
            )}
            
            {user?.role === UserRole.ENTREPRENEUR && (
              <div className="space-y-3">
                <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <div className="flex justify-between mb-2">
                    <p className="font-medium">Market Trend</p>
                    <span className="text-sm text-success">↑ 12%</span>
                  </div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">PET plastic demand is increasing</p>
                </div>
                <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <div className="flex justify-between mb-2">
                    <p className="font-medium">New Subsidy Available</p>
                    <span className="text-xs px-2 py-1 bg-accent-light/20 text-accent rounded-full">New</span>
                  </div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">For small-scale paper recycling units</p>
                </div>
                <Link to="/subsidies" className="text-sm text-primary flex items-center justify-center mt-2">
                  View all subsidies <ChevronRight className="h-4 w-4 ml-1" />
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;