import React, { useState, useEffect } from 'react';
import { MapPin, Layers, Factory, Trash2, Search } from 'lucide-react';
import { translate } from '../utils/languageService';
import MapView from '../components/common/MapView';
import { GeoPoint } from '../types';
import { getCurrentLocation } from '../utils/mapService';
import useAuth from '../hooks/useAuth';

// Mock data for map markers
const mockVendors = [
  {
    id: 'v1',
    name: 'Raj Recyclers',
    type: 'vendor',
    wasteTypes: ['plastic'],
    location: { latitude: 28.6129, longitude: 77.2295 }
  },
  {
    id: 'v2',
    name: 'Green Paper Co',
    type: 'vendor',
    wasteTypes: ['paper'],
    location: { latitude: 28.6239, longitude: 77.2100 }
  },
  {
    id: 'v3',
    name: 'Metal Scrap Dealers',
    type: 'vendor',
    wasteTypes: ['metal'],
    location: { latitude: 28.5929, longitude: 77.2390 }
  }
];

const mockFactories = [
  {
    id: 'f1',
    name: 'Eco Plastics Processing',
    type: 'factory',
    materialTypes: ['plastic'],
    location: { latitude: 28.6339, longitude: 77.2290 }
  },
  {
    id: 'f2',
    name: 'Paper Recycling Mill',
    type: 'factory',
    materialTypes: ['paper'],
    location: { latitude: 28.5829, longitude: 77.2490 }
  },
  {
    id: 'f3',
    name: 'Metal Recovery Systems',
    type: 'factory',
    materialTypes: ['metal'],
    location: { latitude: 28.6439, longitude: 77.2890 }
  }
];

interface MapEntity {
  id: string;
  name: string;
  type: 'vendor' | 'factory';
  wasteTypes?: string[];
  materialTypes?: string[];
  location: GeoPoint;
}

const MapPage: React.FC = () => {
  const { user } = useAuth();
  const [userLocation, setUserLocation] = useState<GeoPoint | null>(null);
  const [allEntities, setAllEntities] = useState<MapEntity[]>([]);
  const [filteredEntities, setFilteredEntities] = useState<MapEntity[]>([]);
  const [selectedEntity, setSelectedEntity] = useState<MapEntity | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showVendors, setShowVendors] = useState(true);
  const [showFactories, setShowFactories] = useState(true);
  const [showDetails, setShowDetails] = useState(false);
  
  useEffect(() => {
    // Get user location
    const getLocation = async () => {
      try {
        const location = await getCurrentLocation();
        setUserLocation(location);
      } catch (error) {
        console.error('Error getting location:', error);
      }
    };
    
    getLocation();
    
    // Combine vendors and factories
    setAllEntities([...mockVendors, ...mockFactories]);
  }, []);
  
  // Filter entities based on search and filters
  useEffect(() => {
    let entities = allEntities;
    
    // Filter by type
    if (!showVendors) {
      entities = entities.filter(entity => entity.type !== 'vendor');
    }
    
    if (!showFactories) {
      entities = entities.filter(entity => entity.type !== 'factory');
    }
    
    // Filter by search query
    if (searchQuery) {
      entities = entities.filter(entity => 
        entity.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    setFilteredEntities(entities);
  }, [allEntities, showVendors, showFactories, searchQuery]);
  
  const handleMarkerClick = (id: string) => {
    const entity = allEntities.find(e => e.id === id);
    if (entity) {
      setSelectedEntity(entity);
      setShowDetails(true);
    }
  };
  
  const getMarkerColor = (type: string): string => {
    return type === 'vendor' ? 'text-primary' : 'text-secondary';
  };
  
  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
          <MapPin className="h-6 w-6 mr-2 text-primary" />
          {translate('location')}
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Find vendors and factories on the map
        </p>
      </div>
      
      <div className="card mb-6">
        <div className="flex flex-col md:flex-row md:items-center space-y-4 md:space-y-0">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search locations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input-field pl-10 w-full"
            />
          </div>
          
          <div className="flex md:ml-4 space-x-4">
            <div className="flex items-center">
              <Layers className="h-5 w-5 text-gray-500 mr-2" />
              <span className="text-sm text-gray-600 dark:text-gray-400 mr-2">Show:</span>
              <div className="flex space-x-1">
                <button
                  onClick={() => setShowVendors(!showVendors)}
                  className={`flex items-center space-x-1 px-2 py-1 rounded-lg text-sm ${
                    showVendors 
                      ? 'bg-primary-light/10 text-primary' 
                      : 'bg-gray-100 dark:bg-gray-800 text-gray-500'
                  }`}
                >
                  <Trash2 className="h-4 w-4" />
                  <span>Vendors</span>
                </button>
                
                <button
                  onClick={() => setShowFactories(!showFactories)}
                  className={`flex items-center space-x-1 px-2 py-1 rounded-lg text-sm ${
                    showFactories 
                      ? 'bg-secondary-light/10 text-secondary' 
                      : 'bg-gray-100 dark:bg-gray-800 text-gray-500'
                  }`}
                >
                  <Factory className="h-4 w-4" />
                  <span>Factories</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <div className="card">
            <MapView
              height={500}
              initialViewState={
                userLocation
                  ? { latitude: userLocation.latitude, longitude: userLocation.longitude, zoom: 12 }
                  : undefined
              }
              markers={[
                ...(userLocation ? [{
                  id: 'user',
                  location: userLocation,
                  title: 'Your Location',
                  color: 'text-accent'
                }] : []),
                ...filteredEntities.map(entity => ({
                  id: entity.id,
                  location: entity.location,
                  title: entity.name,
                  color: getMarkerColor(entity.type)
                }))
              ]}
              onMarkerClick={handleMarkerClick}
            />
          </div>
        </div>
        
        <div>
          {selectedEntity && showDetails ? (
            <div className="card">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h2 className="text-xl font-semibold">{selectedEntity.name}</h2>
                  <div className="flex items-center mt-1">
                    {selectedEntity.type === 'vendor' ? (
                      <div className="flex items-center">
                        <Trash2 className="h-4 w-4 text-primary mr-1" />
                        <span className="text-sm">Waste Vendor</span>
                      </div>
                    ) : (
                      <div className="flex items-center">
                        <Factory className="h-4 w-4 text-secondary mr-1" />
                        <span className="text-sm">Recycling Factory</span>
                      </div>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => setShowDetails(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
                    {selectedEntity.type === 'vendor' ? 'Waste Types' : 'Material Types'}
                  </h3>
                  <div className="flex flex-wrap">
                    {(selectedEntity.wasteTypes || selectedEntity.materialTypes || []).map((type, index) => (
                      <span 
                        key={index}
                        className="px-2 py-1 text-xs rounded-full bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 mr-1 mb-1"
                      >
                        {type.charAt(0).toUpperCase() + type.slice(1)}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">
                    Location
                  </h3>
                  <p className="text-gray-800 dark:text-gray-200">
                    {`${selectedEntity.location.latitude.toFixed(4)}, ${selectedEntity.location.longitude.toFixed(4)}`}
                  </p>
                </div>
                
                <button className="w-full btn btn-primary">
                  Contact {selectedEntity.type === 'vendor' ? 'Vendor' : 'Factory'}
                </button>
              </div>
            </div>
          ) : (
            <div className="card">
              <h2 className="text-lg font-semibold mb-4">Nearby Locations</h2>
              
              {filteredEntities.length === 0 ? (
                <div className="text-center py-8">
                  <MapPin className="h-10 w-10 text-gray-300 mx-auto mb-2" />
                  <p className="text-gray-500">No locations found</p>
                  <p className="text-sm text-gray-400">Try adjusting your filters</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredEntities.slice(0, 5).map((entity) => (
                    <button
                      key={entity.id}
                      className="w-full text-left p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                      onClick={() => handleMarkerClick(entity.id)}
                    >
                      <div className="flex items-start">
                        <div className={`p-2 rounded-full ${
                          entity.type === 'vendor' 
                            ? 'bg-primary-light/20' 
                            : 'bg-secondary-light/20'
                        } mr-3`}>
                          {entity.type === 'vendor' ? (
                            <Trash2 className={`h-4 w-4 ${
                              entity.type === 'vendor' ? 'text-primary' : 'text-secondary'
                            }`} />
                          ) : (
                            <Factory className={`h-4 w-4 ${
                              entity.type === 'vendor' ? 'text-primary' : 'text-secondary'
                            }`} />
                          )}
                        </div>
                        
                        <div>
                          <div className="font-medium">{entity.name}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                            {entity.type === 'vendor' 
                              ? `Waste vendor - ${(entity.wasteTypes || []).join(', ')}` 
                              : `Recycling factory - ${(entity.materialTypes || []).join(', ')}`
                            }
                          </div>
                        </div>
                      </div>
                    </button>
                  ))}
                  
                  {filteredEntities.length > 5 && (
                    <button className="w-full text-center text-sm text-primary py-2 hover:underline">
                      Show {filteredEntities.length - 5} more locations
                    </button>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MapPage;