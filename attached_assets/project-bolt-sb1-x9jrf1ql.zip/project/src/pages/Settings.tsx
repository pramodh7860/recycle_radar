import React, { useState } from 'react';
import { Settings as SettingsIcon, Sun, Moon, Bell, VolumeX, Volume2, Lock, Languages } from 'lucide-react';
import { translate } from '../utils/languageService';
import useAuth from '../hooks/useAuth';
import LanguageSelector from '../components/common/LanguageSelector';

const Settings: React.FC = () => {
  const { user } = useAuth();
  
  const [darkMode, setDarkMode] = useState(() => {
    return document.documentElement.classList.contains('dark');
  });
  
  const [notifications, setNotifications] = useState(true);
  const [sound, setSound] = useState(true);
  const [locationSharing, setLocationSharing] = useState(true);
  const [dataSync, setDataSync] = useState(true);
  
  const toggleDarkMode = () => {
    const newDarkMode = !darkMode;
    setDarkMode(newDarkMode);
    
    if (newDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('darkMode', 'enabled');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('darkMode', 'disabled');
    }
  };
  
  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
          <SettingsIcon className="h-6 w-6 mr-2 text-primary" />
          Settings
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Customize your application preferences
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <div className="card">
            <h2 className="text-lg font-semibold mb-6">Appearance</h2>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  {darkMode ? (
                    <div className="w-10 h-10 bg-primary-light/20 rounded-full flex items-center justify-center mr-3">
                      <Moon className="h-5 w-5 text-primary" />
                    </div>
                  ) : (
                    <div className="w-10 h-10 bg-primary-light/20 rounded-full flex items-center justify-center mr-3">
                      <Sun className="h-5 w-5 text-primary" />
                    </div>
                  )}
                  
                  <div>
                    <div className="font-medium">Dark Mode</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      {darkMode ? 'Currently enabled' : 'Currently disabled'}
                    </div>
                  </div>
                </div>
                
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={darkMode}
                    onChange={toggleDarkMode}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary/20 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-primary-light/20 rounded-full flex items-center justify-center mr-3">
                    <Languages className="h-5 w-5 text-primary" />
                  </div>
                  
                  <div>
                    <div className="font-medium">Language</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      Choose your preferred language
                    </div>
                  </div>
                </div>
                
                <LanguageSelector className="w-40" />
              </div>
            </div>
          </div>
          
          <div className="card">
            <h2 className="text-lg font-semibold mb-6">Notifications</h2>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-primary-light/20 rounded-full flex items-center justify-center mr-3">
                    <Bell className="h-5 w-5 text-primary" />
                  </div>
                  
                  <div>
                    <div className="font-medium">Push Notifications</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      Receive notifications about new messages and offers
                    </div>
                  </div>
                </div>
                
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={notifications}
                    onChange={() => setNotifications(!notifications)}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary/20 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-primary-light/20 rounded-full flex items-center justify-center mr-3">
                    {sound ? (
                      <Volume2 className="h-5 w-5 text-primary" />
                    ) : (
                      <VolumeX className="h-5 w-5 text-primary" />
                    )}
                  </div>
                  
                  <div>
                    <div className="font-medium">Sound Effects</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      Play sounds for notifications and actions
                    </div>
                  </div>
                </div>
                
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={sound}
                    onChange={() => setSound(!sound)}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary/20 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                </label>
              </div>
            </div>
          </div>
        </div>
        
        <div className="space-y-6">
          <div className="card">
            <h2 className="text-lg font-semibold mb-6">Privacy & Data</h2>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-primary-light/20 rounded-full flex items-center justify-center mr-3">
                    <MapPin className="h-5 w-5 text-primary" />
                  </div>
                  
                  <div>
                    <div className="font-medium">Location Sharing</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      Allow the app to access your location
                    </div>
                  </div>
                </div>
                
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={locationSharing}
                    onChange={() => setLocationSharing(!locationSharing)}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary/20 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-primary-light/20 rounded-full flex items-center justify-center mr-3">
                    <svg className="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" />
                    </svg>
                  </div>
                  
                  <div>
                    <div className="font-medium">Offline Data Sync</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      Automatically sync data when back online
                    </div>
                  </div>
                </div>
                
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={dataSync}
                    onChange={() => setDataSync(!dataSync)}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary/20 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                </label>
              </div>
            </div>
          </div>
          
          <div className="card">
            <h2 className="text-lg font-semibold mb-6">Security</h2>
            
            <div className="space-y-4">
              <div>
                <button className="w-full flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-primary-light/20 rounded-full flex items-center justify-center mr-3">
                      <Lock className="h-5 w-5 text-primary" />
                    </div>
                    
                    <div className="text-left">
                      <div className="font-medium">Change Password</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">
                        Update your account password
                      </div>
                    </div>
                  </div>
                  
                  <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </div>
              
              <div>
                <button className="w-full flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-primary-light/20 rounded-full flex items-center justify-center mr-3">
                      <svg className="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                      </svg>
                    </div>
                    
                    <div className="text-left">
                      <div className="font-medium">Privacy Settings</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">
                        Manage your data and privacy preferences
                      </div>
                    </div>
                  </div>
                  
                  <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </div>
              
              <div>
                <button className="w-full flex items-center justify-between p-3 bg-error/10 rounded-lg hover:bg-error/20 transition-colors">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-error/20 rounded-full flex items-center justify-center mr-3">
                      <svg className="h-5 w-5 text-error" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </div>
                    
                    <div className="text-left">
                      <div className="font-medium text-error">Delete Account</div>
                      <div className="text-sm text-error/80">
                        Permanently delete your account and all data
                      </div>
                    </div>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="card mt-6">
        <h2 className="text-lg font-semibold mb-6">About</h2>
        
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <div>
            <div className="text-sm text-gray-500 dark:text-gray-400">Application Version</div>
            <div className="font-medium">RecycleRadar v0.1.0</div>
          </div>
          
          <div className="space-x-2">
            <a href="#" className="btn btn-sm btn-outline text-primary">Terms of Service</a>
            <a href="#" className="btn btn-sm btn-outline text-primary">Privacy Policy</a>
            <a href="#" className="btn btn-sm btn-outline text-primary">Contact Support</a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;