import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, Search, MessageSquare, Phone, Mail } from 'lucide-react';
import { translate } from '../utils/languageService';

interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

const faqItems: FAQItem[] = [
  {
    question: "How do I upload waste materials?",
    answer: "To upload waste materials, go to the 'Upload Waste' page from the sidebar. Fill in details about your waste materials, add a photo, record a voice note (optional), and confirm your location. Click 'Upload Waste Listing' to post your listing.",
    category: "vendor"
  },
  {
    question: "How do I find nearby recycling factories?",
    answer: "Go to the 'Find Factories' page from the sidebar. You'll see a map showing recycling factories near your location. You can filter by material type and sort by distance or ratings. Click on a factory marker to view details and contact them.",
    category: "vendor"
  },
  {
    question: "How do I post material needs for my factory?",
    answer: "Navigate to the 'Post Need' page from the sidebar. Fill in details about the materials you need, quantity, price offered, and location. Set how long the listing should remain active and submit. Your need will be visible to vendors with matching waste materials.",
    category: "factory"
  },
  {
    question: "How do I find vendors with available waste materials?",
    answer: "Use the 'Find Vendors' page from the sidebar. You can search for specific materials, filter by type, and sort by distance, price, or date posted. The map view shows vendor locations with available materials that match your needs.",
    category: "factory"
  },
  {
    question: "How does the feasibility tool work?",
    answer: "The feasibility tool helps entrepreneurs evaluate recycling business opportunities. Enter your budget, location, material interests, scale, and other details. The tool analyzes this information and provides recommendations for recycling unit types, estimated costs, ROI, and potential challenges.",
    category: "entrepreneur"
  },
  {
    question: "Where can I find information about subsidies?",
    answer: "Visit the 'Subsidies' page from the sidebar to explore available government subsidies and support programs for recycling businesses. You can filter by central or state government schemes and search for specific types of support. Detailed information and eligibility requirements are provided for each subsidy.",
    category: "entrepreneur"
  },
  {
    question: "How do I change my language preferences?",
    answer: "Go to the 'Settings' page and find the Language section under Appearance. Select your preferred language from the dropdown menu. The app supports English, Hindi, Tamil, and Telugu.",
    category: "general"
  },
  {
    question: "Can I use the application offline?",
    answer: "Yes! RecycleRadar works offline. Any actions you perform while offline will be saved locally and automatically synchronized when you're back online. You'll see an indicator when you're offline and when your data is being synced.",
    category: "general"
  },
  {
    question: "How do I contact another user?",
    answer: "When you find a vendor or factory owner you want to connect with, click the 'Contact' button on their listing or profile. This will start a chat conversation where you can discuss details. You can access all your conversations from the 'Messages' page.",
    category: "general"
  },
  {
    question: "How secure is my data?",
    answer: "We take data security seriously. All communications are encrypted, and your personal information is protected. Location data is only shared with your permission. You can review and adjust your privacy settings in the Settings page.",
    category: "general"
  }
];

const Help: React.FC = () => {
  const [openFAQ, setOpenFAQ] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  
  const toggleFAQ = (index: number) => {
    setOpenFAQ(openFAQ === index ? null : index);
  };
  
  const filteredFAQs = faqItems.filter(faq => {
    const matchesSearch = 
      searchQuery === '' || 
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
      
    const matchesCategory = activeCategory === 'all' || faq.category === activeCategory;
    
    return matchesSearch && matchesCategory;
  });
  
  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center">
          <HelpCircle className="h-6 w-6 mr-2 text-primary" />
          Help & Support
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Find answers to frequently asked questions and get support
        </p>
      </div>
      
      <div className="card mb-6">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search help topics..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="input-field pl-10 w-full"
          />
        </div>
      </div>
      
      <div className="mb-6 overflow-x-auto">
        <div className="flex space-x-2 min-w-max">
          <button
            onClick={() => setActiveCategory('all')}
            className={`px-4 py-2 rounded-full text-sm ${
              activeCategory === 'all'
                ? 'bg-primary text-white'
                : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}
          >
            All Topics
          </button>
          
          <button
            onClick={() => setActiveCategory('vendor')}
            className={`px-4 py-2 rounded-full text-sm ${
              activeCategory === 'vendor'
                ? 'bg-primary text-white'
                : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}
          >
            For Vendors
          </button>
          
          <button
            onClick={() => setActiveCategory('factory')}
            className={`px-4 py-2 rounded-full text-sm ${
              activeCategory === 'factory'
                ? 'bg-primary text-white'
                : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}
          >
            For Factory Owners
          </button>
          
          <button
            onClick={() => setActiveCategory('entrepreneur')}
            className={`px-4 py-2 rounded-full text-sm ${
              activeCategory === 'entrepreneur'
                ? 'bg-primary text-white'
                : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}
          >
            For Entrepreneurs
          </button>
          
          <button
            onClick={() => setActiveCategory('general')}
            className={`px-4 py-2 rounded-full text-sm ${
              activeCategory === 'general'
                ? 'bg-primary text-white'
                : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}
          >
            General
          </button>
        </div>
      </div>
      
      <div className="card mb-6">
        <h2 className="text-xl font-semibold mb-6">Frequently Asked Questions</h2>
        
        {filteredFAQs.length === 0 ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <HelpCircle className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium mb-2">No matching FAQs found</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Try adjusting your search query or category filter
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredFAQs.map((faq, index) => (
              <div 
                key={index} 
                className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden"
              >
                <button
                  className="w-full flex justify-between items-center p-4 text-left bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  onClick={() => toggleFAQ(index)}
                >
                  <h3 className="font-medium">{faq.question}</h3>
                  {openFAQ === index ? (
                    <ChevronUp className="h-5 w-5 text-gray-500" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-gray-500" />
                  )}
                </button>
                
                {openFAQ === index && (
                  <div className="p-4 bg-white dark:bg-gray-900 animate-fade-in">
                    <p className="text-gray-600 dark:text-gray-400">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
      
      <div className="card">
        <h2 className="text-xl font-semibold mb-6">Still Need Help?</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-primary-light/10 p-6 rounded-lg text-center">
            <div className="w-12 h-12 bg-primary-light/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="h-6 w-6 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">Chat Support</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
              Chat with our support team for immediate assistance
            </p>
            <button className="btn btn-sm btn-primary w-full">
              Start Chat
            </button>
          </div>
          
          <div className="bg-primary-light/10 p-6 rounded-lg text-center">
            <div className="w-12 h-12 bg-primary-light/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Phone className="h-6 w-6 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">Phone Support</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
              Call us for immediate assistance with your questions
            </p>
            <a href="tel:+18001234567" className="btn btn-sm btn-primary w-full">
              Call Support
            </a>
          </div>
          
          <div className="bg-primary-light/10 p-6 rounded-lg text-center">
            <div className="w-12 h-12 bg-primary-light/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mail className="h-6 w-6 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">Email Support</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
              Send us an email and we'll get back to you within 24 hours
            </p>
            <a href="mailto:support@recycleradar.com" className="btn btn-sm btn-primary w-full">
              Email Us
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Help;