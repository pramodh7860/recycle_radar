import localforage from "localforage";

// Initialize localforage
localforage.config({
  name: "RecycleRadar",
  storeName: "recycleradar_data",
  version: 1.0,
  description: "Local storage for RecycleRadar app"
});

// Key constants for storage
const KEYS = {
  USER: "user",
  LANGUAGE: "language",
  WASTE_MATERIALS: "waste_materials",
  FACTORY_REQUIREMENTS: "factory_requirements",
  BIDS: "bids",
  MESSAGES: "messages",
  BUSINESS_TYPES: "business_types",
  RESOURCES: "resources",
  PENDING_UPLOADS: "pending_uploads",
  PENDING_REQUESTS: "pending_requests"
};

// User data storage
export const setUserLocalStorage = async (user: any) => {
  return await localforage.setItem(KEYS.USER, user);
};

export const getUserLocalStorage = async () => {
  return await localforage.getItem(KEYS.USER);
};

export const removeUserLocalStorage = async () => {
  return await localforage.removeItem(KEYS.USER);
};

// Language preferences
export const setLanguageLocalStorage = (language: string) => {
  return localStorage.setItem(KEYS.LANGUAGE, language);
};

export const getLanguageLocalStorage = () => {
  return localStorage.getItem(KEYS.LANGUAGE);
};

// Waste materials cache
export const setWasteMaterialsCache = async (materials: any[]) => {
  return await localforage.setItem(KEYS.WASTE_MATERIALS, materials);
};

export const getWasteMaterialsCache = async () => {
  return await localforage.getItem(KEYS.WASTE_MATERIALS) as Promise<any[]>;
};

// Factory requirements cache
export const setFactoryRequirementsCache = async (requirements: any[]) => {
  return await localforage.setItem(KEYS.FACTORY_REQUIREMENTS, requirements);
};

export const getFactoryRequirementsCache = async () => {
  return await localforage.getItem(KEYS.FACTORY_REQUIREMENTS) as Promise<any[]>;
};

// Bids cache
export const setBidsCache = async (bids: any[]) => {
  return await localforage.setItem(KEYS.BIDS, bids);
};

export const getBidsCache = async () => {
  return await localforage.getItem(KEYS.BIDS) as Promise<any[]>;
};

// Messages cache
export const setMessagesCache = async (messages: any[]) => {
  return await localforage.setItem(KEYS.MESSAGES, messages);
};

export const getMessagesCache = async () => {
  return await localforage.getItem(KEYS.MESSAGES) as Promise<any[]>;
};

// Business types cache
export const setBusinessTypesCache = async (businessTypes: any[]) => {
  return await localforage.setItem(KEYS.BUSINESS_TYPES, businessTypes);
};

export const getBusinessTypesCache = async () => {
  return await localforage.getItem(KEYS.BUSINESS_TYPES) as Promise<any[]>;
};

// Resources cache
export const setResourcesCache = async (resources: any[]) => {
  return await localforage.setItem(KEYS.RESOURCES, resources);
};

export const getResourcesCache = async () => {
  return await localforage.getItem(KEYS.RESOURCES) as Promise<any[]>;
};

// Handling offline uploads (waste materials, bids, etc.)
export const addPendingUpload = async (type: string, data: any) => {
  const pendingUploads = await localforage.getItem(KEYS.PENDING_UPLOADS) as any[] || [];
  pendingUploads.push({ type, data, timestamp: new Date().toISOString() });
  return await localforage.setItem(KEYS.PENDING_UPLOADS, pendingUploads);
};

export const getPendingUploads = async () => {
  return await localforage.getItem(KEYS.PENDING_UPLOADS) as Promise<any[]>;
};

export const removePendingUpload = async (index: number) => {
  const pendingUploads = await localforage.getItem(KEYS.PENDING_UPLOADS) as any[] || [];
  pendingUploads.splice(index, 1);
  return await localforage.setItem(KEYS.PENDING_UPLOADS, pendingUploads);
};

// Handling offline API requests
export const addPendingRequest = async (method: string, url: string, data: any) => {
  const pendingRequests = await localforage.getItem(KEYS.PENDING_REQUESTS) as any[] || [];
  pendingRequests.push({ method, url, data, timestamp: new Date().toISOString() });
  return await localforage.setItem(KEYS.PENDING_REQUESTS, pendingRequests);
};

export const getPendingRequests = async () => {
  return await localforage.getItem(KEYS.PENDING_REQUESTS) as Promise<any[]>;
};

export const removePendingRequest = async (index: number) => {
  const pendingRequests = await localforage.getItem(KEYS.PENDING_REQUESTS) as any[] || [];
  pendingRequests.splice(index, 1);
  return await localforage.setItem(KEYS.PENDING_REQUESTS, pendingRequests);
};

// Check network status
export const isOnline = () => {
  return navigator.onLine;
};

// Sync pending data when online
export const syncPendingData = async () => {
  if (!isOnline()) return;
  
  // Process pending API requests
  const pendingRequests = await getPendingRequests() || [];
  for (let i = 0; i < pendingRequests.length; i++) {
    const request = pendingRequests[i];
    try {
      await fetch(request.url, {
        method: request.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request.data)
      });
      await removePendingRequest(i);
    } catch (error) {
      console.error('Error syncing pending request:', error);
    }
  }
  
  // Process pending uploads (files)
  const pendingUploads = await getPendingUploads() || [];
  for (let i = 0; i < pendingUploads.length; i++) {
    const upload = pendingUploads[i];
    try {
      // Handle different upload types differently
      switch(upload.type) {
        case 'wasteMaterial':
          // Implement wasteMaterial upload
          break;
        case 'voiceNote':
          // Implement voiceNote upload
          break;
        case 'photo':
          // Implement photo upload
          break;
      }
      await removePendingUpload(i);
    } catch (error) {
      console.error('Error syncing pending upload:', error);
    }
  }
};

// Listen for online status changes
if (typeof window !== 'undefined') {
  window.addEventListener('online', syncPendingData);
}

export default {
  setUserLocalStorage,
  getUserLocalStorage,
  removeUserLocalStorage,
  setLanguageLocalStorage,
  getLanguageLocalStorage,
  setWasteMaterialsCache,
  getWasteMaterialsCache,
  setFactoryRequirementsCache,
  getFactoryRequirementsCache,
  setBidsCache,
  getBidsCache,
  setMessagesCache,
  getMessagesCache,
  setBusinessTypesCache,
  getBusinessTypesCache,
  setResourcesCache,
  getResourcesCache,
  addPendingUpload,
  getPendingUploads,
  removePendingUpload,
  addPendingRequest,
  getPendingRequests,
  removePendingRequest,
  isOnline,
  syncPendingData
};
