import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import i18n from './i18n';

// Extend jsPDF type for autotable
declare module 'jspdf' {
  interface jsPDF {
    autoTable: (options: any) => jsPDF;
  }
}

interface InvestmentItem {
  name: string;
  amount: number;
}

interface RevenueItem {
  name: string;
  value: string | number;
}

interface BusinessReport {
  businessType: string;
  roiMonths: number;
  investment: InvestmentItem[];
  revenue: RevenueItem[];
  subsidies: string[];
  licenses: string[];
  location?: string;
  budget?: string;
  land?: number;
  capacity?: number;
}

export const generateFeasibilityReport = (
  reportData: BusinessReport, 
  lang: string = 'en'
): jsPDF => {
  const t = i18n.getFixedT(lang);
  const doc = new jsPDF();
  
  // Add Logo and Header
  doc.setFontSize(22);
  doc.setTextColor(46, 125, 50); // Primary green color
  doc.text("RecycleRadar", 105, 20, { align: 'center' });
  
  doc.setFontSize(16);
  doc.setTextColor(80, 80, 80);
  doc.text(t('entrepreneur.feasibilityReport'), 105, 30, { align: 'center' });
  
  // Add Date
  doc.setFontSize(10);
  doc.setTextColor(120, 120, 120);
  doc.text(`${t('generated')}: ${new Date().toLocaleDateString()}`, 195, 40, { align: 'right' });
  
  // Business Recommendation
  doc.setFontSize(14);
  doc.setTextColor(50, 50, 50);
  doc.text(t('entrepreneur.businessRecommendation'), 14, 50);
  
  doc.setFontSize(12);
  doc.setTextColor(0, 0, 0);
  doc.text(`${reportData.businessType} - ${t('estimatedRoi')} ${reportData.roiMonths} ${t('months')}`, 14, 60);
  
  // User Input Summary
  if (reportData.location || reportData.budget || reportData.land !== undefined || reportData.capacity !== undefined) {
    doc.setFontSize(14);
    doc.setTextColor(50, 50, 50);
    doc.text(t('userInputSummary'), 14, 75);
    
    doc.setFontSize(12);
    doc.setTextColor(0, 0, 0);
    let yPosition = 85;
    
    if (reportData.location) {
      doc.text(`${t('entrepreneur.location')}: ${reportData.location}`, 14, yPosition);
      yPosition += 7;
    }
    
    if (reportData.budget) {
      doc.text(`${t('entrepreneur.investmentBudget')}: ${reportData.budget}`, 14, yPosition);
      yPosition += 7;
    }
    
    if (reportData.land !== undefined) {
      doc.text(`${t('entrepreneur.availableLand')}: ${reportData.land} ${t('sqMeters')}`, 14, yPosition);
      yPosition += 7;
    }
    
    if (reportData.capacity !== undefined) {
      doc.text(`${t('entrepreneur.processingCapacity')}: ${reportData.capacity} ${t('kgPerDay')}`, 14, yPosition);
      yPosition += 7;
    }
  }
  
  // Investment Breakdown
  doc.setFontSize(14);
  doc.setTextColor(50, 50, 50);
  doc.text(t('entrepreneur.investmentBreakdown'), 14, 105);
  
  const investmentTableData = reportData.investment.map(item => [item.name, `₹${item.amount.toLocaleString()}`]);
  const totalInvestment = reportData.investment.reduce((sum, item) => sum + item.amount, 0);
  investmentTableData.push([t('totalInvestment'), `₹${totalInvestment.toLocaleString()}`]);
  
  doc.autoTable({
    startY: 110,
    head: [[t('item'), t('amount')]],
    body: investmentTableData,
    theme: 'grid',
    headStyles: { fillColor: [46, 125, 50], textColor: 255 },
    foot: [[t('total'), `₹${totalInvestment.toLocaleString()}`]],
    footStyles: { fillColor: [240, 240, 240], textColor: [0, 0, 0], fontStyle: 'bold' }
  });
  
  // Revenue Projection
  let currentY = (doc as any).lastAutoTable.finalY + 15;
  
  doc.setFontSize(14);
  doc.setTextColor(50, 50, 50);
  doc.text(t('entrepreneur.revenueProjection'), 14, currentY);
  
  const revenueTableData = reportData.revenue.map(item => [item.name, typeof item.value === 'number' && item.name.includes('₹') ? 
    `₹${item.value.toLocaleString()}` : item.value]);
  
  doc.autoTable({
    startY: currentY + 5,
    head: [[t('item'), t('value')]],
    body: revenueTableData,
    theme: 'grid',
    headStyles: { fillColor: [25, 118, 210], textColor: 255 }
  });
  
  // Eligible Subsidies
  currentY = (doc as any).lastAutoTable.finalY + 15;
  
  doc.setFontSize(14);
  doc.setTextColor(50, 50, 50);
  doc.text(t('entrepreneur.eligibleSubsidies'), 14, currentY);
  
  doc.autoTable({
    startY: currentY + 5,
    head: [[t('subsidy')]],
    body: reportData.subsidies.map(subsidy => [subsidy]),
    theme: 'grid',
    headStyles: { fillColor: [76, 175, 80], textColor: 255 }
  });
  
  // Required Licenses
  currentY = (doc as any).lastAutoTable.finalY + 15;
  
  doc.setFontSize(14);
  doc.setTextColor(50, 50, 50);
  doc.text(t('entrepreneur.requiredLicenses'), 14, currentY);
  
  doc.autoTable({
    startY: currentY + 5,
    head: [[t('license')]],
    body: reportData.licenses.map(license => [license]),
    theme: 'grid',
    headStyles: { fillColor: [255, 152, 0], textColor: 255 }
  });
  
  // Footer
  doc.setFontSize(10);
  doc.setTextColor(120, 120, 120);
  doc.text('RecycleRadar © ' + new Date().getFullYear(), 14, 280);
  doc.text(t('footer.tagline'), 105, 280, { align: 'center' });
  doc.text(t('disclaimer'), 195, 280, { align: 'right' });
  
  return doc;
};

export const downloadFeasibilityReport = (reportData: BusinessReport, fileName: string = 'feasibility-report.pdf', lang: string = 'en') => {
  const doc = generateFeasibilityReport(reportData, lang);
  doc.save(fileName);
};

export const emailFeasibilityReport = async (reportData: BusinessReport, email: string, lang: string = 'en') => {
  try {
    const doc = generateFeasibilityReport(reportData, lang);
    const pdfBlob = doc.output('blob');
    
    // Create form data to send the PDF
    const formData = new FormData();
    formData.append('email', email);
    formData.append('report', pdfBlob, 'feasibility-report.pdf');
    
    // Send using fetch API
    const response = await fetch('/api/email-report', {
      method: 'POST',
      body: formData
    });
    
    if (!response.ok) {
      throw new Error('Failed to send email');
    }
    
    return true;
  } catch (error) {
    console.error('Error emailing report:', error);
    return false;
  }
};

export default {
  generateFeasibilityReport,
  downloadFeasibilityReport,
  emailFeasibilityReport
};
