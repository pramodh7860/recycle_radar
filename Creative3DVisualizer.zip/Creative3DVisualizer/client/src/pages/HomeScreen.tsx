import { Link } from 'wouter';
import { useTranslation } from 'react-i18next';
import { Factory, BarChart3, Map, Camera, FileText, Home, User } from 'lucide-react';

const HomeScreen = () => {
  const { t } = useTranslation();

  const menuItems = [
    {
      id: 'vendor-factory',
      title: 'Vendor-Factory Match',
      icon: <Factory className="h-8 w-8" />,
      color: 'bg-blue-100 text-blue-600',
      link: '/vendor-form'
    },
    {
      id: 'feasibility',
      title: 'Feasibility Analyzer',
      icon: <BarChart3 className="h-8 w-8" />,
      color: 'bg-green-100 text-green-600',
      link: '/feasibility'
    },
    {
      id: 'smart-map',
      title: 'Smart Map',
      icon: <Map className="h-8 w-8" />,
      color: 'bg-purple-100 text-purple-600',
      link: '/map'
    },
    {
      id: 'feedback',
      title: 'Swachh Bharat Feedback',
      icon: <Camera className="h-8 w-8" />,
      color: 'bg-amber-100 text-amber-600',
      link: '/feedback'
    },
    {
      id: 'report',
      title: 'Request Report',
      icon: <FileText className="h-8 w-8" />,
      color: 'bg-red-100 text-red-600',
      link: '/report'
    }
  ];

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm p-4">
        <div className="flex justify-between items-center">
          <h1 className="text-xl font-bold text-primary flex items-center">
            <span className="mr-2">♻️</span> RecycleRadar
          </h1>
          <Link href="/profile">
            <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center cursor-pointer">
              <User className="h-6 w-6 text-gray-600" />
            </div>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Welcome!</h2>
        
        <div className="grid grid-cols-2 gap-4">
          {menuItems.map((item) => (
            <Link key={item.id} href={item.link} className="block">
              <div className={`rounded-xl p-6 ${item.color} h-36 flex flex-col items-center justify-center text-center transition-transform hover:scale-105 shadow-sm`}>
                <div className="mb-3">
                  {item.icon}
                </div>
                <span className="font-medium">{item.title}</span>
              </div>
            </Link>
          ))}
        </div>
      </main>

      {/* Bottom Navigation */}
      <nav className="bg-white shadow-t-sm p-2">
        <div className="flex justify-around">
          <div className="flex flex-col items-center text-primary">
            <Home className="h-6 w-6" />
            <span className="text-xs mt-1">Home</span>
          </div>
          <Link href="/map">
            <div className="flex flex-col items-center text-gray-500">
              <Map className="h-6 w-6" />
              <span className="text-xs mt-1">Map</span>
            </div>
          </Link>
          <Link href="/profile">
            <div className="flex flex-col items-center text-gray-500">
              <User className="h-6 w-6" />
              <span className="text-xs mt-1">Profile</span>
            </div>
          </Link>
        </div>
      </nav>
    </div>
  );
};

export default HomeScreen;