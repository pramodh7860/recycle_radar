import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { ChevronLeft, User, LogOut, Mail, Phone, MapPin, Settings, Moon, Sun, Globe } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import LanguageSelector from '../components/LanguageSelector';

const ProfileScreen = () => {
  const { t } = useTranslation();
  const [, navigate] = useLocation();
  const [darkMode, setDarkMode] = useState(false);
  
  // Mock user data
  const user = {
    name: 'Raj Kumar',
    email: 'raj.kumar@example.com',
    phone: '+91 98765 43210',
    location: 'Mumbai, Maharashtra',
    userType: 'vendor', // or 'factory', 'entrepreneur'
  };
  
  // Mock activity data
  const activities = [
    {
      id: 1,
      type: 'wasteMaterial',
      title: 'PET Bottles - 100kg',
      date: '15 Apr 2025',
      status: 'active',
    },
    {
      id: 2,
      type: 'factoryRequirement',
      title: 'Plastic Waste - 500kg',
      date: '10 Apr 2025',
      status: 'fulfilled',
    },
    {
      id: 3,
      type: 'feasibilityReport',
      title: 'Plastic Recycling Business',
      date: '05 Apr 2025',
      status: 'completed',
    },
  ];

  const handleLogout = () => {
    // In a real app, this would call a logout API
    navigate('/');
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    // In a real app, this would update a theme context
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/home">
              <button className="mr-4">
                <ChevronLeft className="h-6 w-6" />
              </button>
            </Link>
            <h1 className="text-xl font-semibold">Profile</h1>
          </div>
          <button 
            onClick={handleLogout}
            className="p-2 text-gray-600 hover:text-red-600"
          >
            <LogOut className="h-5 w-5" />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4 space-y-6">
        {/* User Profile Card */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center">
            <div className="h-20 w-20 bg-blue-100 rounded-full flex items-center justify-center">
              <User className="h-10 w-10 text-blue-600" />
            </div>
            <div className="ml-6">
              <h2 className="text-xl font-bold text-gray-800">{user.name}</h2>
              <p className="text-sm text-gray-500 capitalize">{user.userType}</p>
            </div>
          </div>

          <div className="mt-6 space-y-3">
            <div className="flex items-center text-gray-600">
              <Mail className="h-5 w-5 mr-3" />
              <span>{user.email}</span>
            </div>
            <div className="flex items-center text-gray-600">
              <Phone className="h-5 w-5 mr-3" />
              <span>{user.phone}</span>
            </div>
            <div className="flex items-center text-gray-600">
              <MapPin className="h-5 w-5 mr-3" />
              <span>{user.location}</span>
            </div>
          </div>

          <div className="mt-6">
            <Link href="/settings">
              <button className="w-full py-2 px-4 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 flex items-center justify-center">
                <Settings className="h-5 w-5 mr-2" />
                Edit Profile
              </button>
            </Link>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="font-medium text-gray-900">Recent Activity</h3>
          </div>
          
          <div className="divide-y divide-gray-200">
            {activities.map(activity => (
              <div key={activity.id} className="px-6 py-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="font-medium text-gray-900">{activity.title}</h4>
                    <p className="text-sm text-gray-500">{activity.date}</p>
                  </div>
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    activity.status === 'active' ? 'bg-green-100 text-green-800' : 
                    activity.status === 'fulfilled' ? 'bg-blue-100 text-blue-800' : 
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {activity.status.charAt(0).toUpperCase() + activity.status.slice(1)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Settings */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="font-medium text-gray-900">Settings</h3>
          </div>
          
          <div className="divide-y divide-gray-200">
            {/* Dark Mode Toggle */}
            <div className="px-6 py-4 flex justify-between items-center">
              <div className="flex items-center">
                {darkMode ? (
                  <Moon className="h-5 w-5 mr-3 text-gray-600" />
                ) : (
                  <Sun className="h-5 w-5 mr-3 text-gray-600" />
                )}
                <span>Dark Mode</span>
              </div>
              <button
                onClick={toggleDarkMode}
                className={`w-11 h-6 flex items-center rounded-full p-1 ${
                  darkMode ? 'bg-primary justify-end' : 'bg-gray-300 justify-start'
                }`}
              >
                <span className="bg-white w-4 h-4 rounded-full shadow-md transform transition-transform duration-300"></span>
              </button>
            </div>
            
            {/* Language Selector */}
            <div className="px-6 py-4 flex justify-between items-center">
              <div className="flex items-center">
                <Globe className="h-5 w-5 mr-3 text-gray-600" />
                <span>Language</span>
              </div>
              <LanguageSelector />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ProfileScreen;