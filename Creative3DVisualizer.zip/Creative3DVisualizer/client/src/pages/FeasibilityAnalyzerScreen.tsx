import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTranslation } from 'react-i18next';
import { ChevronLeft, MapPin, Download, FileText, Check, Map, Award } from 'lucide-react';
import { Link } from 'wouter';

// Form schema
const feasibilityFormSchema = z.object({
  wasteType: z.string().min(1, 'Please select a waste type'),
  budget: z.number().min(1000, 'Budget must be at least ₹1000'),
  land: z.number().min(10, 'Land area must be at least 10 sq. ft.'),
  location: z.string().optional(),
});

type FeasibilityFormValues = z.infer<typeof feasibilityFormSchema>;

interface FeasibilityResult {
  unitType: string;
  cost: number;
  roi: number;
  schemes: string[];
  licenses: string[];
  areaScore: 'High' | 'Medium' | 'Low';
  description: string;
}

const FeasibilityAnalyzerScreen = () => {
  const { t } = useTranslation();
  const [useCurrentLocation, setUseCurrentLocation] = useState(false);
  const [result, setResult] = useState<FeasibilityResult | null>(null);

  const { register, handleSubmit, setValue, formState: { errors } } = useForm<FeasibilityFormValues>({
    resolver: zodResolver(feasibilityFormSchema),
    defaultValues: {
      wasteType: '',
      budget: 0,
      land: 0,
      location: '',
    },
  });

  const wasteTypes = [
    { value: 'plastic', label: 'Plastic Waste' },
    { value: 'paper', label: 'Paper Waste' },
    { value: 'organic', label: 'Organic Waste' },
    { value: 'ewaste', label: 'Electronic Waste' },
    { value: 'mixed', label: 'Mixed Waste' },
  ];

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setValue('location', `${latitude}, ${longitude}`);
          setUseCurrentLocation(true);
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  };

  const onSubmit = (data: FeasibilityFormValues) => {
    console.log('Form data:', data);
    
    // For demonstration, set mock result based on inputs
    // In a real app, this would be calculated based on an algorithm or API call
    const mockResult: FeasibilityResult = {
      unitType: data.wasteType === 'plastic' ? 'Plastic Recycling Unit' : 
                data.wasteType === 'paper' ? 'Paper Recycling Mill' :
                data.wasteType === 'organic' ? 'Composting Facility' :
                data.wasteType === 'ewaste' ? 'E-Waste Dismantling Unit' : 'Material Recovery Facility',
      cost: data.budget < 500000 ? data.budget * 0.8 : data.budget * 0.7,
      roi: data.budget < 500000 ? 24 : 18,
      schemes: [
        'Swachh Bharat Mission - Urban (SBM-U)',
        'Pradhan Mantri MUDRA Yojana',
        'Credit Linked Capital Subsidy Scheme (CLCSS)'
      ],
      licenses: [
        'Pollution Control Board (PCB) Consent',
        'Municipal Solid Waste Authorization',
        'GST Registration',
        'Shop and Establishment License'
      ],
      areaScore: useCurrentLocation ? 'High' : 'Medium',
      description: `Based on your inputs, a ${data.wasteType} recycling business is feasible within your budget and land constraints. The payback period is estimated to be ${data.budget < 500000 ? '24' : '18'} months.`
    };
    
    setResult(mockResult);
  };

  const generatePDF = () => {
    alert('Generating PDF report. This would typically create a downloadable PDF with the feasibility analysis results.');
    // In a real app, you would use jsPDF or a similar library to generate a downloadable PDF
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm p-4">
        <div className="flex items-center">
          <Link href="/home">
            <button className="mr-4">
              <ChevronLeft className="h-6 w-6" />
            </button>
          </Link>
          <h1 className="text-xl font-semibold">Feasibility Analyzer</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4">
        {!result ? (
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            {/* Waste Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Waste Type
              </label>
              <select
                {...register('wasteType')}
                className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
              >
                <option value="">Select Waste Type</option>
                {wasteTypes.map(type => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
              {errors.wasteType && (
                <p className="mt-1 text-sm text-red-600">{errors.wasteType.message}</p>
              )}
            </div>

            {/* Budget */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Budget (₹)
              </label>
              <input
                type="number"
                {...register('budget', { valueAsNumber: true })}
                className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                placeholder="Enter your investment budget"
              />
              {errors.budget && (
                <p className="mt-1 text-sm text-red-600">{errors.budget.message}</p>
              )}
            </div>

            {/* Land Area */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Land (sq. ft.)
              </label>
              <input
                type="number"
                {...register('land', { valueAsNumber: true })}
                className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                placeholder="Enter available land area"
              />
              {errors.land && (
                <p className="mt-1 text-sm text-red-600">{errors.land.message}</p>
              )}
            </div>

            {/* Location */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Location (Optional)
              </label>
              <div className="flex">
                <input
                  type="text"
                  {...register('location')}
                  className="flex-1 py-2 px-3 border border-gray-300 bg-white rounded-l-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                  placeholder={useCurrentLocation ? 'Using current location' : 'Enter location or use current'}
                  readOnly={useCurrentLocation}
                />
                <button
                  type="button"
                  onClick={getCurrentLocation}
                  className="bg-blue-100 text-blue-600 py-2 px-3 rounded-r-md border border-l-0 border-gray-300"
                >
                  <MapPin className="h-5 w-5" />
                </button>
              </div>
              <p className="mt-1 text-xs text-gray-500">Providing location helps analyze local regulations and market potential</p>
            </div>

            {/* Submit Button */}
            <div>
              <button
                type="submit"
                className="w-full bg-primary hover:bg-primary-dark text-white font-medium py-3 px-4 rounded-md transition-colors"
              >
                Analyze Feasibility
              </button>
            </div>
          </form>
        ) : (
          <div className="space-y-6">
            {/* Results Header */}
            <div className="text-center">
              <h2 className="text-2xl font-bold text-gray-800">Feasibility Report</h2>
              <p className="text-gray-600">Based on your inputs</p>
            </div>
            
            {/* Suggested Unit */}
            <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
              <div className="flex justify-between items-start">
                <h3 className="font-medium text-gray-900">Suggested Recycling Unit</h3>
                <span className={`inline-block px-2 py-1 text-xs rounded-full ${result.areaScore === 'High' ? 'bg-green-100 text-green-800' : result.areaScore === 'Medium' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'}`}>
                  {result.areaScore} Area Score
                </span>
              </div>
              <p className="text-xl font-semibold text-primary mt-2">{result.unitType}</p>
              <p className="text-sm text-gray-600 mt-2">{result.description}</p>
            </div>
            
            {/* Financial Details */}
            <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
              <h3 className="font-medium text-gray-900 mb-4">Financial Overview</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Estimated Cost</span>
                  <span className="font-medium">₹{result.cost.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Return on Investment</span>
                  <span className="font-medium">{result.roi} months</span>
                </div>
              </div>
            </div>
            
            {/* Government Schemes */}
            <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
              <div className="flex items-center mb-4">
                <Award className="h-5 w-5 text-yellow-500 mr-2" />
                <h3 className="font-medium text-gray-900">Eligible Government Schemes</h3>
              </div>
              <ul className="space-y-2">
                {result.schemes.map((scheme, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-gray-600">{scheme}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            {/* Required Licenses */}
            <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
              <div className="flex items-center mb-4">
                <FileText className="h-5 w-5 text-blue-500 mr-2" />
                <h3 className="font-medium text-gray-900">Required Licenses</h3>
              </div>
              <ul className="space-y-2">
                {result.licenses.map((license, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-gray-600">{license}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            {/* Action Buttons */}
            <div className="flex flex-col space-y-3">
              <button
                onClick={generatePDF}
                className="w-full bg-primary hover:bg-primary-dark text-white font-medium py-3 px-4 rounded-md transition-colors flex items-center justify-center"
              >
                <Download className="h-5 w-5 mr-2" />
                Download Report as PDF
              </button>
              
              <Link href="/map" className="block w-full">
                <button
                  className="w-full bg-green-100 text-green-700 font-medium py-3 px-4 rounded-md transition-colors flex items-center justify-center"
                >
                  <Map className="h-5 w-5 mr-2" />
                  View Suggested Areas on Map
                </button>
              </Link>
              
              <Link href="/home">
                <button
                  className="w-full bg-gray-100 text-gray-700 font-medium py-3 px-4 rounded-md transition-colors"
                >
                  Return to Home
                </button>
              </Link>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default FeasibilityAnalyzerScreen;