import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { ChevronLeft, Filter, Phone, MessageSquare, ChevronDown } from 'lucide-react';
import { Link } from 'wouter';

interface Match {
  id: number;
  name: string;
  material: string;
  quantity: number;
  distance: number;
  price: number;
  description: string;
}

const MatchmakingResultsScreen = () => {
  const { t } = useTranslation();
  const [filterOpen, setFilterOpen] = useState(false);
  const [materialFilter, setMaterialFilter] = useState('all');
  const [distanceSort, setDistanceSort] = useState('nearest');

  // Mock data for demonstration
  const mockMatches: Match[] = [
    {
      id: 1,
      name: 'ABC Recycling Factory',
      material: 'plastic',
      quantity: 500,
      distance: 3.2,
      price: 15,
      description: 'Looking for clean PET bottles, preferably crushed.'
    },
    {
      id: 2,
      name: 'Green Paper Mills',
      material: 'paper',
      quantity: 1000,
      distance: 5.8,
      price: 8,
      description: 'Need office paper waste and cardboard.'
    },
    {
      id: 3,
      name: 'Metal Recyclers Ltd',
      material: 'metal',
      quantity: 300,
      distance: 7.1,
      price: 25,
      description: 'Accepting aluminum cans and scrap metal.'
    },
    {
      id: 4,
      name: 'E-Waste Solutions',
      material: 'ewaste',
      quantity: 200,
      distance: 10.5,
      price: 30,
      description: 'Looking for electronic components and circuit boards.'
    },
    {
      id: 5,
      name: 'Local Glass Recycling',
      material: 'glass',
      quantity: 400,
      distance: 4.3,
      price: 12,
      description: 'Need clean glass bottles and jars.'
    }
  ];

  // Apply filters and sorting
  const filteredMatches = mockMatches
    .filter(match => materialFilter === 'all' || match.material === materialFilter)
    .sort((a, b) => {
      if (distanceSort === 'nearest') {
        return a.distance - b.distance;
      } else {
        return b.price - a.price;
      }
    });

  const handleContact = (id: number) => {
    alert(`Contacting match #${id}`);
    // Here you would typically initiate a call or open a chat
  };

  const handleChat = (id: number) => {
    alert(`Opening chat with match #${id}`);
    // Here you would typically open a chat interface
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/home">
              <button className="mr-4">
                <ChevronLeft className="h-6 w-6" />
              </button>
            </Link>
            <h1 className="text-xl font-semibold">Available Matches</h1>
          </div>
          <button 
            onClick={() => setFilterOpen(!filterOpen)} 
            className="flex items-center px-3 py-1 bg-gray-100 rounded-md"
          >
            <Filter className="h-4 w-4 mr-1" />
            <span className="text-sm">Filter</span>
          </button>
        </div>

        {/* Filter Panel */}
        {filterOpen && (
          <div className="mt-4 p-4 bg-gray-100 rounded-md">
            <div className="flex flex-col space-y-4 sm:space-y-0 sm:flex-row sm:space-x-4">
              <div className="flex-1">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Material Type
                </label>
                <select
                  value={materialFilter}
                  onChange={(e) => setMaterialFilter(e.target.value)}
                  className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm text-sm"
                >
                  <option value="all">All Materials</option>
                  <option value="plastic">Plastic</option>
                  <option value="paper">Paper</option>
                  <option value="metal">Metal</option>
                  <option value="ewaste">E-Waste</option>
                  <option value="glass">Glass</option>
                  <option value="organic">Organic</option>
                </select>
              </div>
              <div className="flex-1">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Sort By
                </label>
                <select
                  value={distanceSort}
                  onChange={(e) => setDistanceSort(e.target.value)}
                  className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm text-sm"
                >
                  <option value="nearest">Nearest First</option>
                  <option value="price">Best Price First</option>
                </select>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4">
        {filteredMatches.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-500">No matches found. Try adjusting your filters.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredMatches.map(match => (
              <div 
                key={match.id} 
                className="bg-white rounded-lg shadow-sm p-4 border border-gray-100"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-medium text-gray-900">{match.name}</h3>
                    <div className="flex items-center mt-1">
                      <span className={`inline-block w-3 h-3 rounded-full mr-2 bg-${match.material === 'plastic' ? 'blue' : match.material === 'paper' ? 'yellow' : match.material === 'metal' ? 'gray' : match.material === 'ewaste' ? 'purple' : match.material === 'glass' ? 'green' : 'brown'}-500`}></span>
                      <span className="text-sm text-gray-600 capitalize">{match.material}</span>
                      <span className="mx-2 text-gray-300">•</span>
                      <span className="text-sm text-gray-600">{match.quantity} kg</span>
                      <span className="mx-2 text-gray-300">•</span>
                      <span className="text-sm text-gray-600">{match.distance} km away</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="font-medium text-green-600">₹{match.price}/kg</span>
                  </div>
                </div>
                
                <p className="text-sm text-gray-500 mt-2">{match.description}</p>
                
                <div className="flex mt-4 justify-end space-x-2">
                  <button 
                    onClick={() => handleChat(match.id)}
                    className="flex items-center px-3 py-1.5 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200"
                  >
                    <MessageSquare className="h-4 w-4 mr-1" />
                    <span className="text-sm">Chat</span>
                  </button>
                  <button 
                    onClick={() => handleContact(match.id)}
                    className="flex items-center px-3 py-1.5 bg-green-600 text-white rounded-md hover:bg-green-700"
                  >
                    <Phone className="h-4 w-4 mr-1" />
                    <span className="text-sm">Contact</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default MatchmakingResultsScreen;