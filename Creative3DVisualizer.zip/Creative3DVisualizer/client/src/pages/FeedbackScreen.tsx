import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { ChevronLeft, Camera, MapPin, Send, Clock, User, ThumbsUp } from 'lucide-react';
import { Link } from 'wouter';

interface FeedbackItem {
  id: number;
  image: string;
  location: string;
  description: string;
  timestamp: string;
  user: string;
  likes: number;
  isLiked: boolean;
}

const FeedbackScreen = () => {
  const { t } = useTranslation();
  const [image, setImage] = useState<string | null>(null);
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [feedItems, setFeedItems] = useState<FeedbackItem[]>([
    {
      id: 1,
      image: 'https://images.unsplash.com/photo-1636491712984-6564c896cdc0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      location: 'Andheri East, Mumbai',
      description: 'Plastic waste dumping near the railway tracks. Needs immediate attention.',
      timestamp: '2 hours ago',
      user: 'Rahul S.',
      likes: 12,
      isLiked: false,
    },
    {
      id: 2,
      image: 'https://images.unsplash.com/photo-1605600659726-be52a45a7b4d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      location: 'Powai, Mumbai',
      description: 'Clean-up needed at Powai Lake shore. Many plastic bottles and bags.',
      timestamp: '5 hours ago',
      user: 'Priya M.',
      likes: 8,
      isLiked: true,
    },
  ]);

  const handleImageCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          // In a real app, you would use a reverse geocoding service to get the address
          setLocation('Current Location (detected)');
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!image) {
      alert('Please upload an image');
      return;
    }
    
    if (!description) {
      alert('Please provide a description');
      return;
    }
    
    const newFeedItem: FeedbackItem = {
      id: Date.now(),
      image: image,
      location: location || 'Unknown location',
      description,
      timestamp: 'Just now',
      user: 'You',
      likes: 0,
      isLiked: false,
    };
    
    setFeedItems([newFeedItem, ...feedItems]);
    setImage(null);
    setDescription('');
    setLocation('');
  };

  const toggleLike = (id: number) => {
    setFeedItems(
      feedItems.map(item => {
        if (item.id === id) {
          return {
            ...item,
            likes: item.isLiked ? item.likes - 1 : item.likes + 1,
            isLiked: !item.isLiked,
          };
        }
        return item;
      })
    );
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm p-4">
        <div className="flex items-center">
          <Link href="/home">
            <button className="mr-4">
              <ChevronLeft className="h-6 w-6" />
            </button>
          </Link>
          <h1 className="text-xl font-semibold">Swachh Bharat Feedback</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4">
        {/* Upload Form */}
        <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
          <h2 className="font-medium text-gray-900 mb-4">Report Waste Issue</h2>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Image Upload */}
            <div>
              <div className="flex flex-col items-center border-2 border-dashed border-gray-300 rounded-md p-4 bg-gray-50">
                {image ? (
                  <div className="mb-4 w-full">
                    <img src={image} alt="Preview" className="w-full h-48 object-cover rounded-md" />
                  </div>
                ) : (
                  <div className="text-center mb-4">
                    <Camera className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-500">Upload a photo of the waste issue</p>
                  </div>
                )}
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageCapture}
                  className="hidden"
                  id="image-upload"
                />
                <label
                  htmlFor="image-upload"
                  className="cursor-pointer bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50"
                >
                  {image ? 'Change Photo' : 'Take Photo'}
                </label>
              </div>
            </div>

            {/* Description */}
            <div>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                placeholder="Describe the issue..."
              />
            </div>

            {/* Location */}
            <div className="flex">
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="flex-1 py-2 px-3 border border-gray-300 bg-white rounded-l-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                placeholder="Location (optional)"
              />
              <button
                type="button"
                onClick={getCurrentLocation}
                className="bg-blue-100 text-blue-600 py-2 px-3 rounded-r-md border border-l-0 border-gray-300"
              >
                <MapPin className="h-5 w-5" />
              </button>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full flex items-center justify-center bg-primary hover:bg-primary-dark text-white font-medium py-2 px-4 rounded-md transition-colors"
            >
              <Send className="h-4 w-4 mr-2" />
              Submit Feedback
            </button>
          </form>
        </div>

        {/* Feed of Issues */}
        <div className="space-y-4">
          <h2 className="font-medium text-gray-900">Recent Reports</h2>
          
          {feedItems.map((item) => (
            <div key={item.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
              <img 
                src={item.image} 
                alt="Waste issue" 
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-medium text-gray-900">{item.description}</h3>
                </div>
                <div className="flex items-center text-sm text-gray-500 mb-3">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span>{item.location}</span>
                  <span className="mx-2">•</span>
                  <Clock className="h-4 w-4 mr-1" />
                  <span>{item.timestamp}</span>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center text-sm text-gray-600">
                    <User className="h-4 w-4 mr-1" />
                    <span>{item.user}</span>
                  </div>
                  <button 
                    onClick={() => toggleLike(item.id)}
                    className={`flex items-center px-2 py-1 rounded-md ${
                      item.isLiked ? 'text-blue-600' : 'text-gray-600'
                    }`}
                  >
                    <ThumbsUp className={`h-4 w-4 mr-1 ${item.isLiked ? 'fill-current' : ''}`} />
                    <span>{item.likes}</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};

export default FeedbackScreen;