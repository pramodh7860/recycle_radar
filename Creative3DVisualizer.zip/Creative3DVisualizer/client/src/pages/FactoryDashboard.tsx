import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { toast } from '@/hooks/use-toast';
import useLocation from '@/hooks/useLocation';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { FactoryRequirement, WasteMaterial, Bid } from '@shared/schema';
import Map3D from '@/components/Map3D';
import MaterialTypeSelector from '@/components/MaterialTypeSelector';
import RequirementCard from '@/components/RequirementCard';

const FactoryDashboard = () => {
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  const { coordinates } = useLocation();
  
  // Form states
  const [materialType, setMaterialType] = useState('');
  const [quantity, setQuantity] = useState<number | ''>('');
  const [price, setPrice] = useState<number | ''>('');
  const [description, setDescription] = useState('');
  const [deadline, setDeadline] = useState('');
  const [isFormValid, setIsFormValid] = useState(false);
  
  // Check form validity
  useEffect(() => {
    setIsFormValid(
      materialType !== '' && 
      quantity !== '' && 
      Number(quantity) > 0 &&
      price !== '' &&
      Number(price) > 0 &&
      deadline !== ''
    );
  }, [materialType, quantity, price, deadline]);
  
  // Fetch nearby waste materials (vendors)
  const { data: nearbyVendors = [], isLoading: isLoadingVendors } = useQuery({
    queryKey: ['/api/waste-materials'],
    enabled: !!coordinates
  });
  
  // Fetch factory's requirements
  const { data: factoryRequirements = [], isLoading: isLoadingRequirements } = useQuery({
    queryKey: ['/api/factory-requirements', { factoryId: 1 }] // In a real app, this would be the logged-in factory's ID
  });
  
  // Fetch bids for factory's requirements
  const { data: bids = {}, isLoading: isLoadingBids } = useQuery({
    queryKey: ['/api/bids', { factoryId: 1 }], // Group bids by requirement ID for easier access
    select: (data: Bid[]) => {
      return data.reduce((acc: Record<number, Bid[]>, bid) => {
        if (!acc[bid.requirementId]) {
          acc[bid.requirementId] = [];
        }
        acc[bid.requirementId].push(bid);
        return acc;
      }, {});
    }
  });
  
  // Convert vendors to map pins
  const vendorPins = nearbyVendors.map((vendor: WasteMaterial) => ({
    id: vendor.id,
    lat: vendor.location?.lat || 0,
    lng: vendor.location?.lng || 0,
    title: `${vendor.materialType} - ${vendor.quantity}kg`,
    type: 'vendor' as const,
    subType: vendor.materialType
  }));
  
  // Post requirement mutation
  const postRequirementMutation = useMutation({
    mutationFn: async (requirement: Partial<FactoryRequirement>) => {
      const response = await apiRequest('POST', '/api/factory-requirements', requirement);
      return response.json();
    },
    onSuccess: () => {
      // Reset form and invalidate queries
      setMaterialType('');
      setQuantity('');
      setPrice('');
      setDescription('');
      setDeadline('');
      
      queryClient.invalidateQueries({ queryKey: ['/api/factory-requirements'] });
      
      toast({
        title: t('requirementPosted'),
        description: t('requirementSuccess'),
        variant: 'default'
      });
    },
    onError: (error) => {
      toast({
        title: t('postFailed'),
        description: error.message || t('tryAgainLater'),
        variant: 'destructive'
      });
    }
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isFormValid) return;
    
    // Create requirement object
    const requirement: Partial<FactoryRequirement> = {
      factoryId: 1, // In a real app, this would be the logged-in factory's ID
      materialType,
      quantityNeeded: Number(quantity),
      priceOffered: Number(price),
      description,
      deadline: new Date(deadline),
      location: coordinates ? {
        lat: coordinates.lat,
        lng: coordinates.lng,
        address: coordinates.address
      } : undefined,
      isActive: true
    };
    
    postRequirementMutation.mutate(requirement);
  };
  
  const handleVendorClick = (vendorId: number) => {
    const vendor = nearbyVendors.find((v: WasteMaterial) => v.id === vendorId);
    if (vendor) {
      // In a real app, this would open a chat or contact modal
      console.log(`Contacting vendor ${vendorId}`);
    }
  };
  
  const handleViewBids = (requirementId: number) => {
    // In a real app, this would open a modal with bids
    console.log(`Viewing bids for requirement ${requirementId}`);
    toast({
      title: t('viewingBids'),
      description: t('bidsCount', { count: (bids[requirementId] || []).length }),
      variant: 'default'
    });
  };
  
  return (
    <section>
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">{t('factory.dashboard')}</h2>
        <p className="text-gray-600">{t('factory.dashboardDesc')}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Requirement Form */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-xl font-semibold mb-4">{t('factory.postRequirement')}</h3>
            
            {/* Requirement Form */}
            <form id="requirement-form" onSubmit={handleSubmit} className="space-y-4">
              <div>
                <MaterialTypeSelector
                  value={materialType}
                  onChange={setMaterialType}
                  label={t('factory.materialType')}
                  required
                />
              </div>
              
              <div>
                <label className="block text-gray-700 mb-2">{t('factory.quantityNeeded')}</label>
                <div className="flex">
                  <Input
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value ? Number(e.target.value) : '')}
                    placeholder={t('enterQuantity')}
                    className="w-full rounded-lg"
                    min="1"
                    required
                  />
                  <span className="ml-2 flex items-center text-gray-500">kg</span>
                </div>
              </div>
              
              <div>
                <label className="block text-gray-700 mb-2">{t('factory.priceOffered')}</label>
                <div className="flex">
                  <span className="flex items-center pr-2 text-gray-500">₹</span>
                  <Input
                    type="number"
                    value={price}
                    onChange={(e) => setPrice(e.target.value ? Number(e.target.value) : '')}
                    placeholder={t('enterPricePerKg')}
                    className="w-full rounded-lg"
                    min="1"
                    required
                  />
                  <span className="ml-2 flex items-center text-gray-500">/kg</span>
                </div>
              </div>
              
              <div>
                <label className="block text-gray-700 mb-2">{t('factory.requirementDesc')}</label>
                <Textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder={t('describeRequirements')}
                  className="w-full rounded-lg h-24"
                />
              </div>
              
              <div>
                <label className="block text-gray-700 mb-2">{t('factory.deadline')}</label>
                <Input
                  type="date"
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                  className="w-full rounded-lg"
                  min={new Date().toISOString().split('T')[0]}
                  required
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full py-3 bg-secondary hover:bg-secondary-dark rounded-lg text-white font-medium transition-colors"
                disabled={!isFormValid || postRequirementMutation.isPending}
              >
                {postRequirementMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    {t('posting')}
                  </>
                ) : (
                  t('buttons.postRequirement')
                )}
              </Button>
            </form>
          </div>
        </div>
        
        {/* Right Column: Map and Active Requirements */}
        <div className="lg:col-span-2">
          {/* 3D Map */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden mb-6">
            <Map3D
              pins={vendorPins}
              userLocation={coordinates || undefined}
              mapType="factory"
              onPinClick={handleVendorClick}
            />
          </div>
          
          {/* Active Requirements */}
          <div className="bg-white rounded-xl shadow-md p-6 mb-6">
            <h3 className="text-xl font-semibold mb-4">{t('factory.activeRequirements')}</h3>
            
            {isLoadingRequirements ? (
              <div className="py-4 text-center text-gray-500">
                <i className="fas fa-spinner fa-spin mr-2"></i>
                {t('loadingRequirements')}
              </div>
            ) : factoryRequirements.length === 0 ? (
              <div className="py-4 text-center text-gray-500">
                {t('noActiveRequirements')}
              </div>
            ) : (
              <div className="space-y-4">
                {factoryRequirements.map((requirement: FactoryRequirement) => (
                  <RequirementCard
                    key={requirement.id}
                    id={requirement.id}
                    materialType={requirement.materialType}
                    quantity={requirement.quantityNeeded}
                    price={requirement.priceOffered}
                    description={requirement.description}
                    deadline={new Date(requirement.deadline)}
                    createdAt={new Date(requirement.createdAt)}
                    bidsCount={(bids[requirement.id] || []).length}
                    onViewBids={handleViewBids}
                    isActive={requirement.isActive}
                  />
                ))}
              </div>
            )}
          </div>
          
          {/* Recent Vendor Bids */}
          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-xl font-semibold mb-4">{t('factory.recentBids')}</h3>
            
            {isLoadingBids ? (
              <div className="py-4 text-center text-gray-500">
                <i className="fas fa-spinner fa-spin mr-2"></i>
                {t('loadingBids')}
              </div>
            ) : Object.values(bids).flat().length === 0 ? (
              <div className="py-4 text-center text-gray-500">
                {t('noBidsReceived')}
              </div>
            ) : (
              <div className="space-y-4">
                {Object.values(bids).flat().slice(0, 3).map((bid: Bid) => (
                  <div key={bid.id} className="border-b border-gray-200 pb-4 mb-4 last:border-b-0 last:mb-0 last:pb-0">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium">Vendor #{bid.vendorId}</h4>
                        <p className="text-sm text-gray-500">
                          {t('bidReceivedTimeAgo', { 
                            time: new Date(bid.createdAt).toLocaleDateString() 
                          })}
                        </p>
                        <div className="mt-1">
                          <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2 py-1 rounded">
                            {t(`materials.${bid.requirementId}`)}
                          </span>
                          <span className="bg-gray-100 text-gray-800 text-xs font-medium px-2 py-1 rounded ml-2">
                            {bid.quantity}kg
                          </span>
                          <span className="bg-green-100 text-green-800 text-xs font-medium px-2 py-1 rounded ml-2">
                            ₹{bid.pricePerKg}/kg
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mt-2">
                          {bid.message || t('noBidMessage')}
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          variant="default"
                          className="bg-secondary hover:bg-secondary-dark"
                          onClick={() => {
                            toast({
                              title: t('bidAccepted'),
                              description: t('bidAcceptedSuccess'),
                              variant: 'default'
                            });
                          }}
                        >
                          {t('buttons.accept')}
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            toast({
                              title: t('messageSent'),
                              description: t('messageSentSuccess'),
                              variant: 'default'
                            });
                          }}
                        >
                          {t('buttons.message')}
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default FactoryDashboard;
