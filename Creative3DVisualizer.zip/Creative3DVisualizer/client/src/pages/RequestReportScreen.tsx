import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTranslation } from 'react-i18next';
import { ChevronLeft, FileText, Mail, Send } from 'lucide-react';
import { Link, useLocation } from 'wouter';

// Form schema
const reportRequestSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  email: z.string().email('Invalid email address'),
  wasteType: z.string().min(1, 'Please select a waste type'),
  budget: z.number().min(1000, 'Budget must be at least ₹1000'),
  land: z.number().min(10, 'Land area must be at least 10 sq. ft.'),
  additionalInfo: z.string().optional(),
});

type ReportRequestValues = z.infer<typeof reportRequestSchema>;

const RequestReportScreen = () => {
  const { t } = useTranslation();
  const [, navigate] = useLocation();
  const [isSubmitted, setIsSubmitted] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<ReportRequestValues>({
    resolver: zodResolver(reportRequestSchema),
    defaultValues: {
      name: '',
      email: '',
      wasteType: '',
      budget: 0,
      land: 0,
      additionalInfo: '',
    },
  });

  const wasteTypes = [
    { value: 'plastic', label: 'Plastic Waste' },
    { value: 'paper', label: 'Paper Waste' },
    { value: 'organic', label: 'Organic Waste' },
    { value: 'ewaste', label: 'Electronic Waste' },
    { value: 'mixed', label: 'Mixed Waste' },
  ];

  const onSubmit = (data: ReportRequestValues) => {
    console.log('Form data:', data);
    
    // In a real app, this would be sent to an API
    setIsSubmitted(true);
    
    // Redirect after 3 seconds
    setTimeout(() => {
      navigate('/home');
    }, 3000);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm p-4">
        <div className="flex items-center">
          <Link href="/home">
            <button className="mr-4">
              <ChevronLeft className="h-6 w-6" />
            </button>
          </Link>
          <h1 className="text-xl font-semibold">Request Consultancy Report</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4">
        {isSubmitted ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="bg-green-100 rounded-full p-4 mb-4">
              <FileText className="h-12 w-12 text-green-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-800 mb-2">Report Request Submitted!</h2>
            <p className="text-gray-600 mb-6">
              You'll receive your custom consultancy report via email shortly.
            </p>
            <div className="flex items-center text-gray-500 bg-gray-100 px-4 py-2 rounded-md">
              <Mail className="h-5 w-5 mr-2" />
              <span>Check your inbox for updates</span>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            {/* Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Your Name
              </label>
              <input
                type="text"
                {...register('name')}
                className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                placeholder="Enter your full name"
              />
              {errors.name && (
                <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
              )}
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email Address
              </label>
              <input
                type="email"
                {...register('email')}
                className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                placeholder="Enter your email"
              />
              {errors.email && (
                <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>
              )}
            </div>

            {/* Waste Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Waste Type
              </label>
              <select
                {...register('wasteType')}
                className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
              >
                <option value="">Select Waste Type</option>
                {wasteTypes.map(type => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
              {errors.wasteType && (
                <p className="mt-1 text-sm text-red-600">{errors.wasteType.message}</p>
              )}
            </div>

            {/* Budget */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Budget (₹)
              </label>
              <input
                type="number"
                {...register('budget', { valueAsNumber: true })}
                className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                placeholder="Enter your investment budget"
              />
              {errors.budget && (
                <p className="mt-1 text-sm text-red-600">{errors.budget.message}</p>
              )}
            </div>

            {/* Land Area */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Land Area (sq. ft.)
              </label>
              <input
                type="number"
                {...register('land', { valueAsNumber: true })}
                className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                placeholder="Enter available land area"
              />
              {errors.land && (
                <p className="mt-1 text-sm text-red-600">{errors.land.message}</p>
              )}
            </div>

            {/* Additional Info */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Additional Information (Optional)
              </label>
              <textarea
                {...register('additionalInfo')}
                rows={3}
                className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                placeholder="Any specific requirements or questions..."
              />
            </div>

            {/* Submit Button */}
            <div>
              <button
                type="submit"
                className="w-full bg-primary hover:bg-primary-dark text-white font-medium py-3 px-4 rounded-md transition-colors flex items-center justify-center"
              >
                <Send className="h-5 w-5 mr-2" />
                Generate Consultancy Report
              </button>
            </div>
          </form>
        )}
      </main>
    </div>
  );
};

export default RequestReportScreen;