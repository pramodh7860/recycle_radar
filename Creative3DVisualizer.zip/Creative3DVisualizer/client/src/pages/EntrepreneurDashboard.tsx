import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { toast } from '@/hooks/use-toast';
import FeasibilityForm from '@/components/FeasibilityForm';
import FeasibilityReport from '@/components/FeasibilityReport';
import ResourceCard from '@/components/ResourceCard';
import { Resource, BusinessType } from '@shared/schema';

// Types for form data
interface FeasibilityFormData {
  businessType: string;
  availableLand: number;
  investmentBudget: string;
  location: string;
  processingCapacity: number;
  materialType: string;
}

// Types for results
interface FeasibilityResults {
  businessType: string;
  roiMonths: number;
  investment: Array<{ name: string; amount: number }>;
  revenue: Array<{ name: string; value: string | number }>;
  subsidies: string[];
  licenses: string[];
  location?: string;
  budget?: string;
  land?: number;
  capacity?: number;
}

const EntrepreneurDashboard = () => {
  const { t } = useTranslation();
  const [isCalculating, setIsCalculating] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [feasibilityResults, setFeasibilityResults] = useState<FeasibilityResults | null>(null);
  const [selectedResource, setSelectedResource] = useState<Resource | null>(null);
  
  // Fetch business types
  const { data: businessTypes = [], isLoading: isLoadingBusinessTypes } = useQuery({
    queryKey: ['/api/business-types']
  });
  
  // Fetch resources
  const { data: resources = [], isLoading: isLoadingResources } = useQuery({
    queryKey: ['/api/resources']
  });
  
  // Handle form submission
  const handleSubmit = async (data: FeasibilityFormData) => {
    setIsCalculating(true);
    
    try {
      // In a real app, we would call the API to calculate results
      // For now, we'll simulate a response
      
      // Get business type details from our data
      const businessTypeDetails = businessTypes.find(
        (type: BusinessType) => type.name.toLowerCase().includes(data.businessType.split('_')[0])
      );
      
      if (!businessTypeDetails) {
        throw new Error('Business type not found');
      }
      
      // Create feasibility report
      const results: FeasibilityResults = {
        businessType: businessTypeDetails.name,
        roiMonths: businessTypeDetails.roiMonths,
        investment: [
          { name: t('investmentItems.machinery'), amount: Math.round(businessTypeDetails.minInvestment * 0.45) },
          { name: t('investmentItems.landBuilding'), amount: Math.round(businessTypeDetails.minInvestment * 0.25) },
          { name: t('investmentItems.licenses'), amount: Math.round(businessTypeDetails.minInvestment * 0.1) },
          { name: t('investmentItems.workingCapital'), amount: Math.round(businessTypeDetails.minInvestment * 0.2) }
        ],
        revenue: [
          { name: t('revenueItems.processingCapacity'), value: `${data.processingCapacity} kg/day` },
          { name: t('revenueItems.sellingPrice'), value: `₹${30}` },
          { name: t('revenueItems.monthlyRevenue'), value: Math.round(data.processingCapacity * 30 * 30) },
          { name: t('revenueItems.monthlyExpenses'), value: Math.round(data.processingCapacity * 30 * 30 * 0.65) },
          { name: t('revenueItems.monthlyProfit'), value: Math.round(data.processingCapacity * 30 * 30 * 0.35) }
        ],
        subsidies: (businessTypeDetails.subsidies as string[]) || [],
        licenses: (businessTypeDetails.licenseRequired as string[]) || [],
        location: data.location,
        budget: data.investmentBudget,
        land: data.availableLand,
        capacity: data.processingCapacity
      };
      
      setFeasibilityResults(results);
      setShowResults(true);
      
      // Scroll to results
      setTimeout(() => {
        window.scrollTo({
          top: document.getElementById('feasibility-results')?.offsetTop || 0,
          behavior: 'smooth'
        });
      }, 100);
    } catch (error) {
      console.error('Error calculating feasibility:', error);
      toast({
        title: t('calculationFailed'),
        description: t('tryAgainLater'),
        variant: 'destructive'
      });
    } finally {
      setIsCalculating(false);
    }
  };
  
  // Handle resource card click
  const handleResourceClick = (resource: Resource) => {
    setSelectedResource(resource);
    
    // In a real app, we would handle different resource types differently
    if (resource.type === 'guide') {
      window.open(resource.url, '_blank');
    } else if (resource.type === 'directory') {
      window.open(resource.url, '_blank');
    } else if (resource.type === 'mentorship') {
      toast({
        title: t('applicationSubmitted'),
        description: t('applicationSuccess'),
        variant: 'default'
      });
    } else {
      toast({
        title: t('viewingResource'),
        description: resource.title,
        variant: 'default'
      });
    }
  };
  
  return (
    <section>
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">{t('entrepreneur.dashboard')}</h2>
        <p className="text-gray-600">{t('entrepreneur.dashboardDesc')}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Feasibility Calculator */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-xl font-semibold mb-4">{t('entrepreneur.feasibilityCalc')}</h3>
            
            <FeasibilityForm 
              onSubmit={handleSubmit}
              isLoading={isCalculating}
            />
          </div>
        </div>
        
        {/* Right Column: Feasibility Report & Resources */}
        <div className="lg:col-span-2">
          {/* Feasibility Report */}
          {showResults && feasibilityResults && (
            <div id="feasibility-results" className="mb-6">
              <FeasibilityReport
                businessType={feasibilityResults.businessType}
                roiMonths={feasibilityResults.roiMonths}
                investment={feasibilityResults.investment}
                revenue={feasibilityResults.revenue}
                subsidies={feasibilityResults.subsidies}
                licenses={feasibilityResults.licenses}
                location={feasibilityResults.location}
                budget={feasibilityResults.budget}
                land={feasibilityResults.land}
                capacity={feasibilityResults.capacity}
              />
            </div>
          )}
          
          {/* Resource Library */}
          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-xl font-semibold mb-4">{t('entrepreneur.resourcesTraining')}</h3>
            
            {isLoadingResources ? (
              <div className="py-4 text-center text-gray-500">
                <i className="fas fa-spinner fa-spin mr-2"></i>
                {t('loadingResources')}
              </div>
            ) : resources.length === 0 ? (
              <div className="py-4 text-center text-gray-500">
                {t('noResourcesFound')}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {resources.map((resource: Resource) => (
                  <ResourceCard
                    key={resource.id}
                    resource={resource}
                    onViewDetails={handleResourceClick}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default EntrepreneurDashboard;
