import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { toast } from '@/hooks/use-toast';
import useLocation from '@/hooks/useLocation';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { WasteMaterial, FactoryRequirement } from '@shared/schema';
import Map3D from '@/components/Map3D';
import MaterialTypeSelector from '@/components/MaterialTypeSelector';
import WasteImageUploader from '@/components/WasteImageUploader';
import VoiceNoteRecorder from '@/components/VoiceNoteRecorder';

const VendorDashboard = () => {
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  const { coordinates } = useLocation();
  
  // Form states
  const [materialType, setMaterialType] = useState('');
  const [quantity, setQuantity] = useState<number | ''>('');
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [voiceNoteUrl, setVoiceNoteUrl] = useState<string | null>(null);
  const [isFormValid, setIsFormValid] = useState(false);
  
  // Check form validity
  useEffect(() => {
    setIsFormValid(
      materialType !== '' && 
      quantity !== '' && 
      Number(quantity) > 0
    );
  }, [materialType, quantity]);
  
  // Fetch nearby factories
  const { data: nearbyFactories = [], isLoading: isLoadingFactories } = useQuery({
    queryKey: ['/api/factory-requirements'],
    enabled: !!coordinates
  });
  
  // Convert factories to map pins
  const factoryPins = nearbyFactories.map((factory: FactoryRequirement) => ({
    id: factory.id,
    lat: factory.location?.lat || 0,
    lng: factory.location?.lng || 0,
    title: `${factory.materialType} - ₹${factory.priceOffered}/kg`,
    type: 'factory' as const,
    subType: factory.materialType.split('_')[0] // Extract main type (plastic, paper, etc.)
  }));
  
  // Upload waste material mutation
  const uploadWasteMutation = useMutation({
    mutationFn: async (wasteMaterial: Partial<WasteMaterial>) => {
      const response = await apiRequest('POST', '/api/waste-materials', wasteMaterial);
      return response.json();
    },
    onSuccess: () => {
      // Reset form and invalidate queries
      setMaterialType('');
      setQuantity('');
      setImageUrl(null);
      setVoiceNoteUrl(null);
      
      queryClient.invalidateQueries({ queryKey: ['/api/waste-materials'] });
      
      toast({
        title: t('wasteMaterialUploaded'),
        description: t('wasteMaterialSuccess'),
        variant: 'default'
      });
    },
    onError: (error) => {
      toast({
        title: t('uploadFailed'),
        description: error.message || t('tryAgainLater'),
        variant: 'destructive'
      });
    }
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isFormValid) return;
    
    // Create waste material object
    const wasteMaterial: Partial<WasteMaterial> = {
      vendorId: 1, // In a real app, this would be the logged-in user's ID
      materialType: materialType.split('_')[0], // e.g., "plastic" from "plastic_hdpe"
      subType: materialType,
      quantity: Number(quantity),
      imageUrl: imageUrl || undefined,
      voiceNoteUrl: voiceNoteUrl || undefined,
      location: coordinates ? {
        lat: coordinates.lat,
        lng: coordinates.lng,
        address: coordinates.address
      } : undefined,
      isAvailable: true
    };
    
    uploadWasteMutation.mutate(wasteMaterial);
  };
  
  const handleFactoryClick = (factoryId: number) => {
    const factory = nearbyFactories.find((f: FactoryRequirement) => f.id === factoryId);
    if (factory) {
      // In a real app, this would open a chat or contact modal
      console.log(`Contacting factory ${factoryId}`);
    }
  };
  
  const handleContactFactory = (factoryId: number) => {
    const factory = nearbyFactories.find((f: FactoryRequirement) => f.id === factoryId);
    if (factory) {
      toast({
        title: t('contactRequest'),
        description: t('contactRequestSent'),
        variant: 'default'
      });
    }
  };
  
  return (
    <section>
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">{t('vendor.dashboard')}</h2>
        <p className="text-gray-600">{t('vendor.dashboardDesc')}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Upload Form */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-xl font-semibold mb-4">{t('vendor.uploadWaste')}</h3>
            
            {/* Upload Form */}
            <form id="waste-upload-form" onSubmit={handleSubmit} className="space-y-4">
              <div>
                <MaterialTypeSelector
                  value={materialType}
                  onChange={setMaterialType}
                  label={t('vendor.materialType')}
                  required
                />
              </div>
              
              <div>
                <label className="block text-gray-700 mb-2">{t('vendor.quantity')}</label>
                <div className="flex">
                  <Input
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value ? Number(e.target.value) : '')}
                    placeholder={t('enterQuantity')}
                    className="w-full rounded-lg"
                    min="1"
                    required
                  />
                  <span className="ml-2 flex items-center text-gray-500">kg</span>
                </div>
              </div>
              
              <WasteImageUploader onImageUploaded={setImageUrl} />
              
              <VoiceNoteRecorder onRecordingComplete={setVoiceNoteUrl} />
              
              <Button 
                type="submit" 
                className="w-full py-3 bg-primary hover:bg-primary-dark rounded-lg text-white font-medium transition-colors"
                disabled={!isFormValid || uploadWasteMutation.isPending}
              >
                {uploadWasteMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    {t('uploading')}
                  </>
                ) : (
                  t('buttons.upload')
                )}
              </Button>
            </form>
          </div>
        </div>
        
        {/* Right Column: Map and Matches */}
        <div className="lg:col-span-2">
          {/* 3D Map */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden mb-6">
            <Map3D
              pins={factoryPins}
              userLocation={coordinates || undefined}
              mapType="vendor"
              onPinClick={handleFactoryClick}
            />
          </div>
          
          {/* Nearby Factories */}
          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-xl font-semibold mb-4">{t('vendor.nearbyFactories')}</h3>
            
            {isLoadingFactories ? (
              <div className="py-4 text-center text-gray-500">
                <i className="fas fa-spinner fa-spin mr-2"></i>
                {t('loadingFactories')}
              </div>
            ) : nearbyFactories.length === 0 ? (
              <div className="py-4 text-center text-gray-500">
                {t('noFactoriesFound')}
              </div>
            ) : (
              <div className="space-y-4">
                {nearbyFactories.map((factory: FactoryRequirement) => (
                  <div key={factory.id} className="border-b border-gray-200 pb-4 mb-4 last:border-b-0 last:mb-0 last:pb-0">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium text-lg">{`Factory #${factory.id}`}</h4>
                        <div className="flex items-center text-sm text-gray-500 mb-2">
                          <i className="fas fa-map-marker-alt mr-1"></i>
                          <span>{factory.location?.address || t('locationUnknown')}</span>
                        </div>
                        <div className="mb-2">
                          <span className="bg-green-100 text-green-800 text-xs font-medium px-2 py-1 rounded">
                            {t(`materials.${factory.materialType}`)}
                          </span>
                          <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2 py-1 rounded ml-2">
                            ₹{factory.priceOffered}/kg
                          </span>
                        </div>
                        <p className="text-sm text-gray-600">
                          {factory.description || t('noDescription')}
                        </p>
                      </div>
                      <Button
                        onClick={() => handleContactFactory(factory.id)}
                        variant="default"
                        size="sm"
                      >
                        {t('buttons.contact')}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default VendorDashboard;
