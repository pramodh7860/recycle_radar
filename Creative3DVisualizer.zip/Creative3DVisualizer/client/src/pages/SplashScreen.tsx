import { Link } from 'wouter';
import { useTranslation } from 'react-i18next';

const SplashScreen = () => {
  const { t } = useTranslation();

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-blue-50 to-green-50 p-4">
      <div className="text-center">
        <div className="mb-6 text-primary text-8xl">
          ♻️
        </div>
        
        <h1 className="text-4xl font-bold text-primary mb-2">
          RecycleRadar
        </h1>
        
        <p className="text-xl text-gray-700 mb-10">
          Empowering Recycling with Smart Consultancy
        </p>
        
        <Link href="/home">
          <button className="bg-primary hover:bg-primary-dark text-white font-bold py-3 px-8 rounded-full shadow-lg transform transition-all duration-300 hover:scale-105">
            Get Started
          </button>
        </Link>
      </div>
      
      <div className="absolute bottom-4 text-center text-sm text-gray-500">
        <p>Supporting Swachh Bharat Mission</p>
      </div>
    </div>
  );
};

export default SplashScreen;