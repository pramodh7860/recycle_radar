import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTranslation } from 'react-i18next';
import { ChevronLeft, MapPin, Camera } from 'lucide-react';
import { Link, useLocation } from 'wouter';

// Form schema
const vendorFormSchema = z.object({
  materialType: z.string().min(1, 'Please select a material type'),
  quantity: z.number().min(1, 'Quantity must be at least 1'),
  location: z.string().min(1, 'Location is required'),
  notes: z.string().optional(),
});

type VendorFormValues = z.infer<typeof vendorFormSchema>;

const VendorFormScreen = () => {
  const { t } = useTranslation();
  const [, navigate] = useLocation();
  const [image, setImage] = useState<string | null>(null);
  const [useCurrentLocation, setUseCurrentLocation] = useState(false);

  const { register, handleSubmit, setValue, formState: { errors } } = useForm<VendorFormValues>({
    resolver: zodResolver(vendorFormSchema),
    defaultValues: {
      materialType: '',
      quantity: 0,
      location: '',
      notes: '',
    },
  });

  const materialTypes = [
    { value: 'plastic', label: 'Plastic' },
    { value: 'paper', label: 'Paper' },
    { value: 'metal', label: 'Metal' },
    { value: 'ewaste', label: 'E-Waste' },
    { value: 'glass', label: 'Glass' },
    { value: 'organic', label: 'Organic Waste' },
  ];

  const handleImageCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setValue('location', `${latitude}, ${longitude}`);
          setUseCurrentLocation(true);
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  };

  const onSubmit = (data: VendorFormValues) => {
    console.log('Form data:', data, 'Image:', image);
    // Here you would typically send this data to your API
    alert('Listing submitted successfully!');
    navigate('/home');
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm p-4">
        <div className="flex items-center">
          <Link href="/home">
            <button className="mr-4">
              <ChevronLeft className="h-6 w-6" />
            </button>
          </Link>
          <h1 className="text-xl font-semibold">List Your Waste Material</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Material Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Material Type
            </label>
            <select
              {...register('materialType')}
              className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
            >
              <option value="">Select Material Type</option>
              {materialTypes.map(type => (
                <option key={type.value} value={type.value}>
                  {type.label}
                </option>
              ))}
            </select>
            {errors.materialType && (
              <p className="mt-1 text-sm text-red-600">{errors.materialType.message}</p>
            )}
          </div>

          {/* Quantity */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Quantity (kg)
            </label>
            <input
              type="number"
              {...register('quantity', { valueAsNumber: true })}
              className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
            />
            {errors.quantity && (
              <p className="mt-1 text-sm text-red-600">{errors.quantity.message}</p>
            )}
          </div>

          {/* Location */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Location
            </label>
            <div className="flex">
              <input
                type="text"
                {...register('location')}
                className="flex-1 py-2 px-3 border border-gray-300 bg-white rounded-l-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                placeholder={useCurrentLocation ? 'Using current location' : 'Enter location or use current'}
                readOnly={useCurrentLocation}
              />
              <button
                type="button"
                onClick={getCurrentLocation}
                className="bg-blue-100 text-blue-600 py-2 px-3 rounded-r-md border border-l-0 border-gray-300"
              >
                <MapPin className="h-5 w-5" />
              </button>
            </div>
            {errors.location && (
              <p className="mt-1 text-sm text-red-600">{errors.location.message}</p>
            )}
          </div>

          {/* Image Upload */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Upload Image (Optional)
            </label>
            <div className="flex flex-col items-center border-2 border-dashed border-gray-300 rounded-md p-4 bg-gray-50">
              {image ? (
                <div className="mb-4">
                  <img src={image} alt="Preview" className="w-full max-h-40 object-contain" />
                </div>
              ) : (
                <div className="text-center mb-4">
                  <Camera className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-500">Upload a photo of your material</p>
                </div>
              )}
              <input
                type="file"
                accept="image/*"
                onChange={handleImageCapture}
                className="hidden"
                id="image-upload"
              />
              <label
                htmlFor="image-upload"
                className="cursor-pointer bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                {image ? 'Change Photo' : 'Take Photo'}
              </label>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Notes (Optional)
            </label>
            <textarea
              {...register('notes')}
              rows={3}
              className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
              placeholder="Describe your material, condition, etc."
            />
          </div>

          {/* Submit Button */}
          <div>
            <button
              type="submit"
              className="w-full bg-primary hover:bg-primary-dark text-white font-medium py-3 px-4 rounded-md transition-colors"
            >
              Submit Listing
            </button>
          </div>
        </form>
      </main>
    </div>
  );
};

export default VendorFormScreen;