import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTranslation } from 'react-i18next';
import { ChevronLeft, Mail, Lock, User, Phone, Eye, EyeOff, Factory, Recycle, Briefcase, Users } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import ThreeBackground from '../components/ThreeBackground';

// Login schema
const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

// Signup schema
const signupSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  email: z.string().email('Invalid email address'),
  phone: z.string().min(10, 'Invalid phone number'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  userType: z.enum(['vendor', 'factory', 'entrepreneur', 'general'], {
    required_error: 'Please select a user type',
  }),
});

type LoginValues = z.infer<typeof loginSchema>;
type SignupValues = z.infer<typeof signupSchema>;

const LoginScreen = () => {
  const { t } = useTranslation();
  const [, navigate] = useLocation();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [showPassword, setShowPassword] = useState(false);

  const { 
    register: registerLogin, 
    handleSubmit: handleSubmitLogin, 
    formState: { errors: loginErrors } 
  } = useForm<LoginValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: '',
      password: '',
    },
  });

  const { 
    register: registerSignup, 
    handleSubmit: handleSubmitSignup, 
    formState: { errors: signupErrors } 
  } = useForm<SignupValues>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      name: '',
      email: '',
      phone: '',
      password: '',
      userType: 'vendor',
    },
  });

  const onLoginSubmit = (data: LoginValues) => {
    console.log('Login data:', data);
    // In a real app, this would call a login API
    navigate('/home');
  };

  const onSignupSubmit = (data: SignupValues) => {
    console.log('Signup data:', data);
    // In a real app, this would call a signup API
    navigate('/home');
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <div className="flex flex-col min-h-screen relative">
      {/* 3D Background */}
      <ThreeBackground />
      
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-sm shadow-sm p-4 z-10">
        <div className="flex items-center">
          <Link href="/">
            <button className="mr-4">
              <ChevronLeft className="h-6 w-6" />
            </button>
          </Link>
          <h1 className="text-xl font-semibold">
            {mode === 'login' ? 'Login' : 'Create Account'}
          </h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-6 relative z-10">
        <div className="max-w-md mx-auto bg-white/90 backdrop-blur-sm rounded-lg p-6 shadow-xl">
          {/* Mode Toggle */}
          <div className="bg-gray-100 p-1 rounded-lg flex mb-6">
            <button
              onClick={() => setMode('login')}
              className={`flex-1 py-2 rounded-md text-center ${
                mode === 'login' 
                  ? 'bg-white text-primary shadow-sm font-medium' 
                  : 'text-gray-600'
              }`}
            >
              Login
            </button>
            <button
              onClick={() => setMode('signup')}
              className={`flex-1 py-2 rounded-md text-center ${
                mode === 'signup' 
                  ? 'bg-white text-primary shadow-sm font-medium' 
                  : 'text-gray-600'
              }`}
            >
              Sign Up
            </button>
          </div>

          {mode === 'login' ? (
            // Login Form
            <form onSubmit={handleSubmitLogin(onLoginSubmit)} className="space-y-6">
              {/* Email */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="email"
                    {...registerLogin('email')}
                    className="w-full py-2 pl-10 pr-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                    placeholder="Enter your email"
                  />
                </div>
                {loginErrors.email && (
                  <p className="mt-1 text-sm text-red-600">{loginErrors.email.message}</p>
                )}
              </div>

              {/* Password */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type={showPassword ? "text" : "password"}
                    {...registerLogin('password')}
                    className="w-full py-2 pl-10 pr-10 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                    placeholder="Enter your password"
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                    <button 
                      type="button" 
                      onClick={togglePasswordVisibility} 
                      className="text-gray-400 hover:text-gray-500 focus:outline-none"
                    >
                      {showPassword ? (
                        <EyeOff className="h-5 w-5" />
                      ) : (
                        <Eye className="h-5 w-5" />
                      )}
                    </button>
                  </div>
                </div>
                {loginErrors.password && (
                  <p className="mt-1 text-sm text-red-600">{loginErrors.password.message}</p>
                )}
              </div>

              {/* Forgot Password */}
              <div className="text-right">
                <a href="#" className="text-sm text-primary hover:text-primary-dark">
                  Forgot password?
                </a>
              </div>

              {/* Login Button */}
              <div>
                <button
                  type="submit"
                  className="w-full bg-primary hover:bg-primary-dark text-white font-medium py-2 px-4 rounded-md transition-colors"
                >
                  Login
                </button>
              </div>
            </form>
          ) : (
            // Signup Form
            <form onSubmit={handleSubmitSignup(onSignupSubmit)} className="space-y-6">
              {/* Full Name */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    {...registerSignup('name')}
                    className="w-full py-2 pl-10 pr-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                    placeholder="Enter your full name"
                  />
                </div>
                {signupErrors.name && (
                  <p className="mt-1 text-sm text-red-600">{signupErrors.name.message}</p>
                )}
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="email"
                    {...registerSignup('email')}
                    className="w-full py-2 pl-10 pr-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                    placeholder="Enter your email"
                  />
                </div>
                {signupErrors.email && (
                  <p className="mt-1 text-sm text-red-600">{signupErrors.email.message}</p>
                )}
              </div>

              {/* Phone */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Phone Number
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Phone className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="tel"
                    {...registerSignup('phone')}
                    className="w-full py-2 pl-10 pr-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                    placeholder="Enter your phone number"
                  />
                </div>
                {signupErrors.phone && (
                  <p className="mt-1 text-sm text-red-600">{signupErrors.phone.message}</p>
                )}
              </div>

              {/* Password */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type={showPassword ? "text" : "password"}
                    {...registerSignup('password')}
                    className="w-full py-2 pl-10 pr-10 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                    placeholder="Create a password"
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                    <button 
                      type="button" 
                      onClick={togglePasswordVisibility} 
                      className="text-gray-400 hover:text-gray-500 focus:outline-none"
                    >
                      {showPassword ? (
                        <EyeOff className="h-5 w-5" />
                      ) : (
                        <Eye className="h-5 w-5" />
                      )}
                    </button>
                  </div>
                </div>
                {signupErrors.password && (
                  <p className="mt-1 text-sm text-red-600">{signupErrors.password.message}</p>
                )}
              </div>

              {/* User Type */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  I am a
                </label>
                <div className="grid grid-cols-4 gap-3">
                  <label className={`border rounded-md p-3 text-center cursor-pointer transition-all hover:border-primary hover:shadow-md ${
                    signupErrors.userType 
                      ? 'border-red-300' 
                      : 'border-gray-300'
                  }`}>
                    <input
                      type="radio"
                      value="vendor"
                      {...registerSignup('userType')}
                      className="sr-only"
                    />
                    <div className="flex flex-col items-center">
                      <Recycle className={`h-8 w-8 mb-1 ${
                        signupErrors.userType 
                          ? 'text-red-500' 
                          : 'text-primary'
                      }`} />
                      <span className={`block text-sm font-medium ${
                        signupErrors.userType 
                          ? 'text-red-600' 
                          : 'text-gray-900'
                      }`}>
                        Waste Vendor
                      </span>
                    </div>
                  </label>
                  
                  <label className={`border rounded-md p-3 text-center cursor-pointer transition-all hover:border-primary hover:shadow-md ${
                    signupErrors.userType 
                      ? 'border-red-300' 
                      : 'border-gray-300'
                  }`}>
                    <input
                      type="radio"
                      value="factory"
                      {...registerSignup('userType')}
                      className="sr-only"
                    />
                    <div className="flex flex-col items-center">
                      <Factory className={`h-8 w-8 mb-1 ${
                        signupErrors.userType 
                          ? 'text-red-500' 
                          : 'text-primary'
                      }`} />
                      <span className={`block text-sm font-medium ${
                        signupErrors.userType 
                          ? 'text-red-600' 
                          : 'text-gray-900'
                      }`}>
                        Factory Owner
                      </span>
                    </div>
                  </label>
                  
                  <label className={`border rounded-md p-3 text-center cursor-pointer transition-all hover:border-primary hover:shadow-md ${
                    signupErrors.userType 
                      ? 'border-red-300' 
                      : 'border-gray-300'
                  }`}>
                    <input
                      type="radio"
                      value="entrepreneur"
                      {...registerSignup('userType')}
                      className="sr-only"
                    />
                    <div className="flex flex-col items-center">
                      <Briefcase className={`h-8 w-8 mb-1 ${
                        signupErrors.userType 
                          ? 'text-red-500' 
                          : 'text-primary'
                      }`} />
                      <span className={`block text-sm font-medium ${
                        signupErrors.userType 
                          ? 'text-red-600' 
                          : 'text-gray-900'
                      }`}>
                        Entrepreneur
                      </span>
                    </div>
                  </label>
                  
                  <label className={`border rounded-md p-3 text-center cursor-pointer transition-all hover:border-primary hover:shadow-md ${
                    signupErrors.userType 
                      ? 'border-red-300' 
                      : 'border-gray-300'
                  }`}>
                    <input
                      type="radio"
                      value="general"
                      {...registerSignup('userType')}
                      className="sr-only"
                    />
                    <div className="flex flex-col items-center">
                      <Users className={`h-8 w-8 mb-1 ${
                        signupErrors.userType 
                          ? 'text-red-500' 
                          : 'text-primary'
                      }`} />
                      <span className={`block text-sm font-medium ${
                        signupErrors.userType 
                          ? 'text-red-600' 
                          : 'text-gray-900'
                      }`}>
                        General User
                      </span>
                    </div>
                  </label>
                </div>
                {signupErrors.userType && (
                  <p className="mt-1 text-sm text-red-600">{signupErrors.userType.message}</p>
                )}
              </div>

              {/* Signup Button */}
              <div>
                <button
                  type="submit"
                  className="w-full bg-primary hover:bg-primary-dark text-white font-medium py-2 px-4 rounded-md transition-colors"
                >
                  Create Account
                </button>
              </div>
            </form>
          )}

          {/* Alternative Options */}
          <div className="mt-8">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white/90 backdrop-blur-sm text-gray-500">OR</span>
              </div>
            </div>

            <div className="mt-6">
              <button
                type="button"
                className="w-full bg-white hover:bg-gray-50 text-gray-700 font-medium py-2 px-4 rounded-md border border-gray-300 transition-colors flex items-center justify-center"
              >
                <svg className="h-5 w-5 mr-2" viewBox="0 0 24 24">
                  <path
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    fill="#4285F4"
                  />
                  <path
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    fill="#34A853"
                  />
                  <path
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                    fill="#FBBC05"
                  />
                  <path
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    fill="#EA4335"
                  />
                  <path d="M1 1h22v22H1z" fill="none" />
                </svg>
                Continue with Google
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default LoginScreen;