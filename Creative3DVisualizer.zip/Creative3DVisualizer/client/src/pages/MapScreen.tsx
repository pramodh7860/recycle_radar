import { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { ChevronLeft, Layers, Navigation, X, Info } from 'lucide-react';
import { Link } from 'wouter';

interface MapPin {
  id: number;
  lat: number;
  lng: number;
  type: 'waste' | 'factory' | 'suggested';
  name: string;
  details: string;
}

const MapScreen = () => {
  const { t } = useTranslation();
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const [mapType, setMapType] = useState<'satellite' | 'roadmap'>('roadmap');
  const [selectedFilters, setSelectedFilters] = useState<string[]>(['waste', 'factory', 'suggested']);
  const [selectedPin, setSelectedPin] = useState<MapPin | null>(null);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);

  // Mock data
  const mockPins: MapPin[] = [
    { 
      id: 1, 
      lat: 19.076, 
      lng: 72.877, 
      type: 'waste', 
      name: 'Waste Collection Point', 
      details: 'Large quantity of mixed plastic waste available' 
    },
    { 
      id: 2, 
      lat: 19.082, 
      lng: 72.882, 
      type: 'factory', 
      name: 'ABC Recycling Center', 
      details: 'Processes plastic and paper waste, capacity: 5000kg/day' 
    },
    { 
      id: 3, 
      lat: 19.079, 
      lng: 72.870, 
      type: 'suggested', 
      name: 'Recommended Site', 
      details: 'Good location for new recycling business, close to waste sources' 
    },
    { 
      id: 4, 
      lat: 19.074, 
      lng: 72.890, 
      type: 'waste', 
      name: 'PET Bottle Collection', 
      details: 'Clean PET bottles, sorted and ready for recycling' 
    },
    { 
      id: 5, 
      lat: 19.065, 
      lng: 72.875, 
      type: 'factory', 
      name: 'Paper Recycling Mill', 
      details: 'Specializes in paper and cardboard recycling' 
    },
  ];

  // In a real app, you would use a library like Google Maps, Mapbox, or Leaflet
  // For this mockup, we'll simulate a map view
  
  useEffect(() => {
    // In a real implementation, this would initialize the map library
    console.log('Map initialized with container:', mapContainerRef.current);
    
    // Get user's location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    }
  }, []);

  const toggleFilter = (filter: string) => {
    if (selectedFilters.includes(filter)) {
      setSelectedFilters(selectedFilters.filter(f => f !== filter));
    } else {
      setSelectedFilters([...selectedFilters, filter]);
    }
  };

  const toggleMapType = () => {
    setMapType(mapType === 'roadmap' ? 'satellite' : 'roadmap');
  };

  // Filter pins based on selected filters
  const filteredPins = mockPins.filter(pin => selectedFilters.includes(pin.type));

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm p-4 z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/home">
              <button className="mr-4">
                <ChevronLeft className="h-6 w-6" />
              </button>
            </Link>
            <h1 className="text-xl font-semibold">Smart Map</h1>
          </div>
          <div className="flex space-x-2">
            <button 
              onClick={toggleMapType}
              className="p-2 bg-white rounded-full shadow-sm border border-gray-200"
            >
              <Layers className="h-5 w-5 text-gray-600" />
            </button>
            <button 
              onClick={() => userLocation && setSelectedPin(null)}
              className={`p-2 rounded-full shadow-sm border ${userLocation ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-400'}`}
              disabled={!userLocation}
            >
              <Navigation className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Filter Bar */}
      <div className="bg-white border-t border-b border-gray-200 px-4 py-2 flex items-center space-x-2 overflow-x-auto">
        <button
          onClick={() => toggleFilter('waste')}
          className={`px-3 py-1 rounded-full text-sm font-medium whitespace-nowrap ${
            selectedFilters.includes('waste')
              ? 'bg-green-100 text-green-700 border border-green-200'
              : 'bg-gray-100 text-gray-500 border border-gray-200'
          }`}
        >
          Waste Hotspots
        </button>
        <button
          onClick={() => toggleFilter('factory')}
          className={`px-3 py-1 rounded-full text-sm font-medium whitespace-nowrap ${
            selectedFilters.includes('factory')
              ? 'bg-blue-100 text-blue-700 border border-blue-200'
              : 'bg-gray-100 text-gray-500 border border-gray-200'
          }`}
        >
          Recycling Centers
        </button>
        <button
          onClick={() => toggleFilter('suggested')}
          className={`px-3 py-1 rounded-full text-sm font-medium whitespace-nowrap ${
            selectedFilters.includes('suggested')
              ? 'bg-amber-100 text-amber-700 border border-amber-200'
              : 'bg-gray-100 text-gray-500 border border-gray-200'
          }`}
        >
          Suggested Areas
        </button>
      </div>

      {/* Map Container */}
      <div 
        ref={mapContainerRef} 
        className="flex-1 relative bg-gray-200 overflow-hidden"
        style={{ 
          backgroundImage: `url(https://maps.googleapis.com/maps/api/staticmap?center=19.076,72.877&zoom=14&size=600x400&maptype=${mapType})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        {/* This would be replaced by an actual map component in a real implementation */}
        <div className="h-full w-full flex flex-col items-center justify-center">
          <div className="bg-white/80 backdrop-blur-sm p-4 rounded-lg text-center max-w-xs">
            <p className="text-gray-800">
              This is a map placeholder. In a real app, this would be an interactive map showing:
            </p>
            <ul className="text-left mt-3 space-y-1">
              {filteredPins.map(pin => (
                <li key={pin.id} className="flex items-center">
                  <span 
                    className={`inline-block w-3 h-3 rounded-full mr-2 ${
                      pin.type === 'waste' ? 'bg-green-500' :
                      pin.type === 'factory' ? 'bg-blue-500' : 'bg-amber-500'
                    }`}
                  ></span>
                  <span className="text-sm">{pin.name}</span>
                </li>
              ))}
            </ul>
            <button 
              className="mt-4 bg-primary text-white px-4 py-2 rounded-md text-sm"
              onClick={() => setSelectedPin(mockPins[0])}
            >
              Simulate Pin Click
            </button>
          </div>
        </div>
      </div>

      {/* Pin Info Panel */}
      {selectedPin && (
        <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-xl shadow-lg p-4 z-20 transition-transform duration-300">
          <div className="flex justify-between items-start mb-3">
            <div className="flex items-center">
              <span 
                className={`inline-block w-3 h-3 rounded-full mr-2 ${
                  selectedPin.type === 'waste' ? 'bg-green-500' :
                  selectedPin.type === 'factory' ? 'bg-blue-500' : 'bg-amber-500'
                }`}
              ></span>
              <h3 className="font-medium">{selectedPin.name}</h3>
            </div>
            <button onClick={() => setSelectedPin(null)}>
              <X className="h-5 w-5 text-gray-500" />
            </button>
          </div>
          <p className="text-sm text-gray-600 mb-3">{selectedPin.details}</p>
          <div className="flex justify-between">
            <div className="text-xs text-gray-500">
              Coordinates: {selectedPin.lat.toFixed(4)}, {selectedPin.lng.toFixed(4)}
            </div>
            <button className="flex items-center text-blue-600 text-sm">
              <Info className="h-4 w-4 mr-1" />
              More Info
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default MapScreen;