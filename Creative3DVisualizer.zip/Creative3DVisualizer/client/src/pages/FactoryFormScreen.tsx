import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTranslation } from 'react-i18next';
import { ChevronLeft, MapPin, Calendar } from 'lucide-react';
import { Link, useLocation } from 'wouter';

// Form schema
const factoryFormSchema = z.object({
  materialType: z.string().min(1, 'Please select a material type'),
  quantity: z.number().min(1, 'Quantity must be at least 1'),
  price: z.number().min(0, 'Price cannot be negative'),
  deadline: z.string().optional(),
  location: z.string().optional(),
  notes: z.string().optional(),
});

type FactoryFormValues = z.infer<typeof factoryFormSchema>;

const FactoryFormScreen = () => {
  const { t } = useTranslation();
  const [, navigate] = useLocation();
  const [useCurrentLocation, setUseCurrentLocation] = useState(false);

  const { register, handleSubmit, setValue, formState: { errors } } = useForm<FactoryFormValues>({
    resolver: zodResolver(factoryFormSchema),
    defaultValues: {
      materialType: '',
      quantity: 0,
      price: 0,
      deadline: '',
      location: '',
      notes: '',
    },
  });

  const materialTypes = [
    { value: 'plastic', label: 'Plastic' },
    { value: 'paper', label: 'Paper' },
    { value: 'metal', label: 'Metal' },
    { value: 'ewaste', label: 'E-Waste' },
    { value: 'glass', label: 'Glass' },
    { value: 'organic', label: 'Organic Waste' },
  ];

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setValue('location', `${latitude}, ${longitude}`);
          setUseCurrentLocation(true);
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  };

  const onSubmit = (data: FactoryFormValues) => {
    console.log('Form data:', data);
    // Here you would typically send this data to your API
    alert('Requirement submitted successfully!');
    navigate('/home');
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm p-4">
        <div className="flex items-center">
          <Link href="/home">
            <button className="mr-4">
              <ChevronLeft className="h-6 w-6" />
            </button>
          </Link>
          <h1 className="text-xl font-semibold">Post Material Requirement</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Material Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Material Required
            </label>
            <select
              {...register('materialType')}
              className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
            >
              <option value="">Select Material Type</option>
              {materialTypes.map(type => (
                <option key={type.value} value={type.value}>
                  {type.label}
                </option>
              ))}
            </select>
            {errors.materialType && (
              <p className="mt-1 text-sm text-red-600">{errors.materialType.message}</p>
            )}
          </div>

          {/* Quantity */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Quantity Needed (kg)
            </label>
            <input
              type="number"
              {...register('quantity', { valueAsNumber: true })}
              className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
            />
            {errors.quantity && (
              <p className="mt-1 text-sm text-red-600">{errors.quantity.message}</p>
            )}
          </div>

          {/* Price Offered */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Price Offered (₹/kg)
            </label>
            <input
              type="number"
              {...register('price', { valueAsNumber: true })}
              className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
            />
            {errors.price && (
              <p className="mt-1 text-sm text-red-600">{errors.price.message}</p>
            )}
          </div>

          {/* Deadline */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Deadline (Optional)
            </label>
            <div className="flex">
              <input
                type="date"
                {...register('deadline')}
                className="flex-1 py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
              />
              <div className="ml-2 bg-blue-100 text-blue-600 py-2 px-3 rounded-md border border-gray-300 flex items-center">
                <Calendar className="h-5 w-5" />
              </div>
            </div>
          </div>

          {/* Location */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Location (Optional)
            </label>
            <div className="flex">
              <input
                type="text"
                {...register('location')}
                className="flex-1 py-2 px-3 border border-gray-300 bg-white rounded-l-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
                placeholder={useCurrentLocation ? 'Using current location' : 'Enter location or use current'}
                readOnly={useCurrentLocation}
              />
              <button
                type="button"
                onClick={getCurrentLocation}
                className="bg-blue-100 text-blue-600 py-2 px-3 rounded-r-md border border-l-0 border-gray-300"
              >
                <MapPin className="h-5 w-5" />
              </button>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Additional Requirements (Optional)
            </label>
            <textarea
              {...register('notes')}
              rows={3}
              className="w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary"
              placeholder="Describe specific quality requirements, delivery preferences, etc."
            />
          </div>

          {/* Submit Button */}
          <div>
            <button
              type="submit"
              className="w-full bg-primary hover:bg-primary-dark text-white font-medium py-3 px-4 rounded-md transition-colors"
            >
              Submit Requirement
            </button>
          </div>
        </form>
      </main>
    </div>
  );
};

export default FactoryFormScreen;