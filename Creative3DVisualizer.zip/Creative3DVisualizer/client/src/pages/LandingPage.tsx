import { useTranslation } from 'react-i18next';
import { useLocation } from 'wouter';
import RecyclingCard from '../components/RecyclingCard';

const LandingPage = () => {
  const { t } = useTranslation();
  const [, setLocation] = useLocation();
  
  // Image URLs for the cards
  const vendorImage = "https://images.unsplash.com/photo-1553787434-e8a0c44b89f7?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80";
  const factoryImage = "https://images.unsplash.com/photo-1530981279698-37f9dbbaee0b?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80";
  const entrepreneurImage = "https://images.unsplash.com/photo-1513135467880-6c41603e6237?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80";
  
  // Navigate to respective dashboards
  const navigateToVendorDashboard = () => setLocation('/vendor-dashboard');
  const navigateToFactoryDashboard = () => setLocation('/factory-dashboard');
  const navigateToEntrepreneurDashboard = () => setLocation('/entrepreneur-dashboard');
  
  return (
    <section id="user-type-selection" className="my-8">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-4">
          {t('welcome')}
        </h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          {t('subheader')}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
        {/* Vendor Card */}
        <RecyclingCard
          role="vendor"
          image={vendorImage}
          title={t('vendorTitle')}
          description={t('vendorDesc')}
          features={[
            t('uploadWaste'),
            t('findFactories'),
            t('getFairPrices')
          ]}
          buttonText={t('signInVendor')}
          onClick={navigateToVendorDashboard}
        />

        {/* Factory Owner Card */}
        <RecyclingCard
          role="factory"
          image={factoryImage}
          title={t('factoryTitle')}
          description={t('factoryDesc')}
          features={[
            t('postMaterialNeeds'),
            t('manageBids'),
            t('stableSupply')
          ]}
          buttonText={t('signInFactory')}
          onClick={navigateToFactoryDashboard}
        />

        {/* Entrepreneur Card */}
        <RecyclingCard
          role="entrepreneur"
          image={entrepreneurImage}
          title={t('entrepreneurTitle')}
          description={t('entrepreneurDesc')}
          features={[
            t('feasibilityAnalysis'),
            t('licenseInfo'),
            t('subsidyProgram')
          ]}
          buttonText={t('signInEntrepreneur')}
          onClick={navigateToEntrepreneurDashboard}
        />
      </div>
    </section>
  );
};

export default LandingPage;
