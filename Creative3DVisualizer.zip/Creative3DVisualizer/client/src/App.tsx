import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { I18nextProvider } from "react-i18next";
import i18n from "./lib/i18n";
import ThreeBackground from "./components/ThreeBackground";
import Header from "./components/Header";
import Footer from "./components/Footer";

// Original pages
import LandingPage from "./pages/LandingPage";
import VendorDashboard from "./pages/VendorDashboard";
import FactoryDashboard from "./pages/FactoryDashboard";
import EntrepreneurDashboard from "./pages/EntrepreneurDashboard";

// New pages
import SplashScreen from "./pages/SplashScreen";
import HomeScreen from "./pages/HomeScreen";
import VendorFormScreen from "./pages/VendorFormScreen";
import FactoryFormScreen from "./pages/FactoryFormScreen";
import MatchmakingResultsScreen from "./pages/MatchmakingResultsScreen";
import FeasibilityAnalyzerScreen from "./pages/FeasibilityAnalyzerScreen";
import MapScreen from "./pages/MapScreen";
import FeedbackScreen from "./pages/FeedbackScreen";
import RequestReportScreen from "./pages/RequestReportScreen";
import ProfileScreen from "./pages/ProfileScreen";
import LoginScreen from "./pages/LoginScreen";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="relative min-h-screen flex flex-col justify-start">
      <Switch>
        {/* New app flow screens (full screen, no header/footer) */}
        <Route path="/" component={SplashScreen} />
        <Route path="/login" component={LoginScreen} />
        <Route path="/home" component={HomeScreen} />
        <Route path="/vendor-form" component={VendorFormScreen} />
        <Route path="/factory-form" component={FactoryFormScreen} />
        <Route path="/matches" component={MatchmakingResultsScreen} />
        <Route path="/feasibility" component={FeasibilityAnalyzerScreen} />
        <Route path="/map" component={MapScreen} />
        <Route path="/feedback" component={FeedbackScreen} />
        <Route path="/report" component={RequestReportScreen} />
        <Route path="/profile" component={ProfileScreen} />
        
        {/* Original screens (with ThreeBackground, Header and Footer) */}
        <Route path="/landing">
          <div className="relative min-h-screen flex flex-col justify-start">
            <ThreeBackground />
            <Header />
            <main className="flex-grow container mx-auto px-4 py-8">
              <LandingPage />
            </main>
            <Footer />
          </div>
        </Route>
        <Route path="/vendor-dashboard">
          <div className="relative min-h-screen flex flex-col justify-start">
            <ThreeBackground />
            <Header />
            <main className="flex-grow container mx-auto px-4 py-8">
              <VendorDashboard />
            </main>
            <Footer />
          </div>
        </Route>
        <Route path="/factory-dashboard">
          <div className="relative min-h-screen flex flex-col justify-start">
            <ThreeBackground />
            <Header />
            <main className="flex-grow container mx-auto px-4 py-8">
              <FactoryDashboard />
            </main>
            <Footer />
          </div>
        </Route>
        <Route path="/entrepreneur-dashboard">
          <div className="relative min-h-screen flex flex-col justify-start">
            <ThreeBackground />
            <Header />
            <main className="flex-grow container mx-auto px-4 py-8">
              <EntrepreneurDashboard />
            </main>
            <Footer />
          </div>
        </Route>
        <Route>
          <div className="relative min-h-screen flex flex-col justify-start">
            <ThreeBackground />
            <Header />
            <main className="flex-grow container mx-auto px-4 py-8">
              <NotFound />
            </main>
            <Footer />
          </div>
        </Route>
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <I18nextProvider i18n={i18n}>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </I18nextProvider>
    </QueryClientProvider>
  );
}

export default App;
