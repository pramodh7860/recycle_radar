import { useState, useEffect, useCallback } from 'react';

interface Coordinates {
  lat: number;
  lng: number;
  address?: string;
}

interface LocationHook {
  coordinates: Coordinates | null;
  error: string | null;
  loading: boolean;
  getLocation: () => Promise<void>;
  getAddressFromCoordinates: (lat: number, lng: number) => Promise<string>;
  getCoordinatesFromAddress: (address: string) => Promise<Coordinates | null>;
  calculateDistance: (coord1: Coordinates, coord2: Coordinates) => number;
}

export default function useLocation(): LocationHook {
  const [coordinates, setCoordinates] = useState<Coordinates | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  // Get current user location
  const getLocation = useCallback(async () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        });
      });

      const { latitude, longitude } = position.coords;
      const address = await getAddressFromCoordinates(latitude, longitude);
      
      setCoordinates({
        lat: latitude,
        lng: longitude,
        address
      });
    } catch (err) {
      setError('Unable to retrieve your location');
      console.error('Error getting location:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  // Get address from coordinates using reverse geocoding
  const getAddressFromCoordinates = async (lat: number, lng: number): Promise<string> => {
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&addressdetails=1`
      );
      
      if (!response.ok) {
        throw new Error('Failed to get address');
      }
      
      const data = await response.json();
      return data.display_name || 'Unknown location';
    } catch (error) {
      console.error('Error getting address:', error);
      return 'Unknown location';
    }
  };

  // Get coordinates from address using geocoding
  const getCoordinatesFromAddress = async (address: string): Promise<Coordinates | null> => {
    try {
      const encodedAddress = encodeURIComponent(address);
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodedAddress}&limit=1`
      );
      
      if (!response.ok) {
        throw new Error('Failed to get coordinates');
      }
      
      const data = await response.json();
      
      if (data && data.length > 0) {
        return {
          lat: parseFloat(data[0].lat),
          lng: parseFloat(data[0].lon),
          address: data[0].display_name
        };
      }
      
      return null;
    } catch (error) {
      console.error('Error getting coordinates:', error);
      return null;
    }
  };

  // Calculate distance between two coordinates in kilometers
  const calculateDistance = (coord1: Coordinates, coord2: Coordinates): number => {
    const R = 6371; // Radius of the earth in km
    const dLat = deg2rad(coord2.lat - coord1.lat);
    const dLon = deg2rad(coord2.lng - coord1.lng);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(deg2rad(coord1.lat)) * Math.cos(deg2rad(coord2.lat)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Distance in km
  };

  const deg2rad = (deg: number): number => {
    return deg * (Math.PI/180);
  };

  // Get location on mount
  useEffect(() => {
    getLocation();
  }, [getLocation]);

  return {
    coordinates,
    error,
    loading,
    getLocation,
    getAddressFromCoordinates,
    getCoordinatesFromAddress,
    calculateDistance
  };
}
