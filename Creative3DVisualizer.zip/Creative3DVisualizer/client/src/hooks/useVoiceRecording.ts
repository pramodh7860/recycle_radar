import { useState, useCallback, useRef } from 'react';
import { addPendingUpload, isOnline } from '../lib/offline-storage';

interface VoiceRecordingHook {
  isRecording: boolean;
  audioURL: string | null;
  audioBlob: Blob | null;
  startRecording: () => Promise<void>;
  stopRecording: () => Promise<Blob>;
  clearRecording: () => void;
  uploadVoiceNote: (metadata?: object) => Promise<{ url: string; success: boolean }>;
  error: Error | null;
}

export default function useVoiceRecording(): VoiceRecordingHook {
  const [isRecording, setIsRecording] = useState(false);
  const [audioURL, setAudioURL] = useState<string | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [error, setError] = useState<Error | null>(null);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  
  // Start recording audio
  const startRecording = useCallback(async () => {
    audioChunksRef.current = [];
    setError(null);
    
    try {
      // Request microphone access
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Create media recorder
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      
      // Event handler for when data is available
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };
      
      // Event handler for when recording stops
      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const audioUrl = URL.createObjectURL(audioBlob);
        setAudioURL(audioUrl);
        setAudioBlob(audioBlob);
        setIsRecording(false);
        
        // Stop all tracks of the stream
        stream.getTracks().forEach(track => track.stop());
      };
      
      // Start recording
      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      setError(err as Error);
      setIsRecording(false);
      console.error('Error starting recording:', err);
    }
  }, []);
  
  // Stop recording audio
  const stopRecording = useCallback(async () => {
    if (!mediaRecorderRef.current || !isRecording) {
      return Promise.reject(new Error('Not recording'));
    }
    
    return new Promise<Blob>((resolve, reject) => {
      try {
        mediaRecorderRef.current!.onstop = () => {
          const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
          const audioUrl = URL.createObjectURL(audioBlob);
          setAudioURL(audioUrl);
          setAudioBlob(audioBlob);
          setIsRecording(false);
          resolve(audioBlob);
        };
        
        mediaRecorderRef.current!.stop();
      } catch (err) {
        setError(err as Error);
        reject(err);
      }
    });
  }, [isRecording]);
  
  // Clear the recorded audio
  const clearRecording = useCallback(() => {
    if (audioURL) {
      URL.revokeObjectURL(audioURL);
    }
    
    setAudioURL(null);
    setAudioBlob(null);
    setError(null);
  }, [audioURL]);
  
  // Upload the voice note
  const uploadVoiceNote = useCallback(async (metadata = {}) => {
    if (!audioBlob) {
      return { url: '', success: false };
    }
    
    try {
      // Check if online
      if (!isOnline()) {
        // Store for later upload
        await addPendingUpload('voiceNote', { 
          blob: audioBlob, 
          metadata,
          timestamp: new Date().toISOString()
        });
        
        return { 
          url: audioURL || '', 
          success: true,
          offline: true
        };
      }
      
      // Create FormData for upload
      const formData = new FormData();
      formData.append('voiceNote', audioBlob, `voice_note_${Date.now()}.webm`);
      
      // Add metadata
      Object.entries(metadata).forEach(([key, value]) => {
        formData.append(key, String(value));
      });
      
      // Upload to server
      const response = await fetch('/api/upload-voice-note', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error('Failed to upload voice note');
      }
      
      const data = await response.json();
      return { url: data.url, success: true };
    } catch (err) {
      setError(err as Error);
      console.error('Error uploading voice note:', err);
      return { url: '', success: false };
    }
  }, [audioBlob, audioURL]);
  
  return {
    isRecording,
    audioURL,
    audioBlob,
    startRecording,
    stopRecording,
    clearRecording,
    uploadVoiceNote,
    error
  };
}
