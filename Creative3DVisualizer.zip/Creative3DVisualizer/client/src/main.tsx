import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
// PWA registration is disabled until properly configured
// import { registerSW } from "virtual:pwa-register";

// Register service worker for offline capabilities
// if ("serviceWorker" in navigator) {
//   registerSW({ immediate: true });
// }

createRoot(document.getElementById("root")!).render(<App />);
