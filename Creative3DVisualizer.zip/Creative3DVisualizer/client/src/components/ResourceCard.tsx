import { useTranslation } from 'react-i18next';
import { Resource } from '@shared/schema';

interface ResourceCardProps {
  resource: Resource;
  onViewDetails: (resource: Resource) => void;
}

const ResourceCard: React.FC<ResourceCardProps> = ({
  resource,
  onViewDetails
}) => {
  const { t } = useTranslation();
  
  // Get icon based on resource type
  const getIconClass = (type: string) => {
    switch (type) {
      case 'workshop':
        return 'fas fa-chalkboard-teacher';
      case 'guide':
        return 'fas fa-book';
      case 'directory':
        return 'fas fa-address-book';
      case 'mentorship':
        return 'fas fa-users';
      default:
        return 'fas fa-file-alt';
    }
  };
  
  // Get tag text and color based on type
  const getTagDetails = (type: string) => {
    switch (type) {
      case 'workshop':
        return { text: t('resourceTypes.workshop'), color: 'bg-blue-100 text-blue-800' };
      case 'guide':
        return { text: t('resourceTypes.guide'), color: 'bg-green-100 text-green-800' };
      case 'directory':
        return { text: t('resourceTypes.directory'), color: 'bg-purple-100 text-purple-800' };
      case 'mentorship':
        return { text: t('resourceTypes.mentorship'), color: 'bg-orange-100 text-orange-800' };
      default:
        return { text: type, color: 'bg-gray-100 text-gray-800' };
    }
  };
  
  // Extract resource details
  const details = resource.details as Record<string, string> || {};
  const tagDetails = getTagDetails(resource.type);
  
  // Format details for display
  const formattedDetails = [
    details.duration && `${details.duration}`,
    details.mode && `${details.mode}`,
    details.format && `${details.format}`,
    details.pages && `${details.pages} ${t('pages')}`,
    details.entries && `${details.entries} ${t('entries')}`,
    details.cost && `${details.cost}`,
    details.coverage && `${details.coverage}`
  ].filter(Boolean).join(' · ');
  
  return (
    <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
      <div className="flex items-start mb-2">
        <div className="mr-3 text-accent text-xl">
          <i className={getIconClass(resource.type)}></i>
        </div>
        <div>
          <h4 className="font-medium">{resource.title}</h4>
          <span className={`inline-block text-xs font-medium px-2 py-1 rounded mt-1 ${tagDetails.color}`}>
            {tagDetails.text}
          </span>
        </div>
      </div>
      
      <p className="text-sm text-gray-600 mb-2">
        {resource.description}
      </p>
      
      <div className="flex justify-between items-center">
        <span className="text-xs text-gray-500">{formattedDetails}</span>
        <button 
          onClick={() => onViewDetails(resource)}
          className="text-accent hover:text-accent-dark text-sm"
        >
          {resource.type === 'guide' ? t('buttons.download') : 
           resource.type === 'directory' ? t('buttons.viewDirectory') : 
           resource.type === 'mentorship' ? t('buttons.applyNow') : 
           t('buttons.viewDetails')}
        </button>
      </div>
    </div>
  );
};

export default ResourceCard;
