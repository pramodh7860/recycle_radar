import { useTranslation } from 'react-i18next';
import { format, formatDistance } from 'date-fns';
import { Button } from '@/components/ui/button';

interface RequirementCardProps {
  id: number;
  materialType: string;
  materialSubType?: string;
  quantity: number;
  price: number;
  description?: string;
  deadline: Date;
  createdAt: Date;
  bidsCount?: number;
  onViewBids?: (id: number) => void;
  onContact?: (id: number) => void;
  isActive?: boolean;
  variant?: 'compact' | 'full';
}

const RequirementCard: React.FC<RequirementCardProps> = ({
  id,
  materialType,
  materialSubType,
  quantity,
  price,
  description,
  deadline,
  createdAt,
  bidsCount = 0,
  onViewBids,
  onContact,
  isActive = true,
  variant = 'full'
}) => {
  const { t } = useTranslation();
  
  // Format material type for display
  const getMaterialDisplayName = (type: string, subType?: string) => {
    if (subType) {
      return t(`materials.${subType}`);
    }
    return t(`materials.${type}`);
  };
  
  // Calculate time remaining
  const timeAgo = formatDistance(new Date(createdAt), new Date(), { addSuffix: true });
  const daysLeft = Math.max(0, Math.ceil((new Date(deadline).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)));
  
  return (
    <div className={`border ${isActive ? 'border-gray-200' : 'border-gray-100 opacity-75'} rounded-lg p-4 transition-all hover:shadow-sm bg-white`}>
      <div className="flex justify-between items-start">
        <div>
          <h4 className="font-medium">
            {getMaterialDisplayName(materialType, materialSubType)} - {quantity}kg
          </h4>
          <p className="text-sm text-gray-500">
            {t('postedTimeAgo', { time: timeAgo })} · {t('deadlineDaysLeft', { days: daysLeft })}
          </p>
        </div>
        <span className="bg-green-100 text-green-800 text-xs font-medium px-2 py-1 rounded">
          ₹{price}/kg
        </span>
      </div>
      
      {variant === 'full' && description && (
        <p className="text-sm text-gray-600 mt-2">
          {description}
        </p>
      )}
      
      <div className="mt-2">
        <div className="flex justify-between text-sm">
          <span>
            {t('bidsReceived', { count: bidsCount })}
          </span>
          
          <div className="space-x-2">
            {onViewBids && (
              <button 
                onClick={() => onViewBids(id)}
                className="text-secondary hover:underline"
              >
                {t('viewBids')}
              </button>
            )}
            
            {onContact && variant === 'full' && (
              <Button
                size="sm"
                onClick={() => onContact(id)}
                variant="default"
              >
                {t('buttons.contact')}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RequirementCard;
