import { useState, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { addPendingUpload, isOnline } from '../lib/offline-storage';
import { toast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';

interface WasteImageUploaderProps {
  onImageUploaded?: (url: string) => void;
}

const WasteImageUploader: React.FC<WasteImageUploaderProps> = ({ onImageUploaded }) => {
  const { t } = useTranslation();
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const handleCameraClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Validate file type
    if (!file.type.includes('image/')) {
      toast({
        title: t('invalidFileType'),
        description: t('pleaseUploadImage'),
        variant: 'destructive'
      });
      return;
    }
    
    // Create preview
    const reader = new FileReader();
    reader.onload = (event) => {
      setImagePreview(event.target?.result as string);
    };
    reader.readAsDataURL(file);
    
    setImage(file);
  };
  
  const handleUpload = async () => {
    if (!image) return;
    
    setIsUploading(true);
    
    try {
      // Check if online
      if (!isOnline()) {
        // Store for later upload
        await addPendingUpload('image', { 
          file: image,
          timestamp: new Date().toISOString()
        });
        
        toast({
          title: t('imageStoredOffline'),
          description: t('willUploadWhenOnline'),
          variant: 'default'
        });
        
        if (onImageUploaded && imagePreview) {
          onImageUploaded(imagePreview);
        }
        
        setIsUploading(false);
        return;
      }
      
      // Create FormData for upload
      const formData = new FormData();
      formData.append('image', image);
      
      // Upload to server
      const response = await fetch('/api/upload-image', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error('Failed to upload image');
      }
      
      const data = await response.json();
      
      toast({
        title: t('imageUploaded'),
        description: t('imageUploadSuccess'),
        variant: 'default'
      });
      
      if (onImageUploaded) {
        onImageUploaded(data.url);
      }
    } catch (err) {
      console.error('Error uploading image:', err);
      toast({
        title: t('uploadFailed'),
        description: t('tryAgainLater'),
        variant: 'destructive'
      });
    } finally {
      setIsUploading(false);
    }
  };
  
  const handleRemove = () => {
    setImage(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };
  
  return (
    <div className="space-y-3">
      <label className="block text-gray-700 mb-2">{t('vendor.uploadPhoto')}</label>
      
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        capture="environment"
        className="hidden"
      />
      
      {!imagePreview ? (
        <div 
          className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:bg-gray-50 transition cursor-pointer"
          onClick={handleCameraClick}
        >
          <i className="fas fa-camera text-2xl text-gray-400 mb-2"></i>
          <p className="text-gray-500">{t('clickToTakePhoto')}</p>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="relative">
            <img 
              src={imagePreview} 
              alt="Preview" 
              className="w-full rounded-lg object-cover max-h-48"
            />
            <button
              type="button"
              onClick={handleRemove}
              className="absolute top-2 right-2 bg-white rounded-full w-8 h-8 flex items-center justify-center shadow-md hover:bg-gray-100 transition-colors"
            >
              <i className="fas fa-times text-red-500"></i>
            </button>
          </div>
          
          <Button
            onClick={handleUpload}
            disabled={isUploading}
            className="w-full"
          >
            {isUploading ? (
              <>
                <i className="fas fa-spinner fa-spin mr-2"></i>
                {t('uploading')}
              </>
            ) : (
              <>
                <i className="fas fa-cloud-upload-alt mr-2"></i>
                {t('upload')}
              </>
            )}
          </Button>
        </div>
      )}
      
      <p className="text-xs text-gray-500 mt-1">
        {t('imageUploadHint')}
      </p>
    </div>
  );
};

export default WasteImageUploader;
