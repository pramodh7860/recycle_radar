import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import useVoiceRecording from '../hooks/useVoiceRecording';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';

interface VoiceNoteRecorderProps {
  onRecordingComplete?: (url: string) => void;
}

const VoiceNoteRecorder: React.FC<VoiceNoteRecorderProps> = ({ onRecordingComplete }) => {
  const { t } = useTranslation();
  const { 
    isRecording, 
    audioURL, 
    startRecording, 
    stopRecording, 
    clearRecording, 
    uploadVoiceNote,
    error 
  } = useVoiceRecording();
  
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  
  // Show error toast if recording fails
  useEffect(() => {
    if (error) {
      toast({
        title: t('errorMicrophoneAccess'),
        description: error.message,
        variant: 'destructive'
      });
    }
  }, [error, t]);
  
  // Timer for recording duration
  useEffect(() => {
    let intervalId: number;
    
    if (isRecording) {
      setRecordingDuration(0);
      intervalId = window.setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);
    }
    
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [isRecording]);
  
  // Format seconds to MM:SS
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };
  
  const handleStartRecording = async () => {
    await startRecording();
  };
  
  const handleStopRecording = async () => {
    try {
      await stopRecording();
    } catch (err) {
      console.error('Failed to stop recording:', err);
    }
  };
  
  const handleUpload = async () => {
    if (!audioURL) return;
    
    setIsUploading(true);
    try {
      const result = await uploadVoiceNote();
      
      if (result.success) {
        toast({
          title: t('voiceNoteUploaded'),
          description: result.offline ? t('voiceNoteOffline') : t('voiceNoteSuccess'),
          variant: 'default'
        });
        
        if (onRecordingComplete) {
          onRecordingComplete(result.url);
        }
      } else {
        toast({
          title: t('uploadFailed'),
          description: t('tryAgainLater'),
          variant: 'destructive'
        });
      }
    } catch (err) {
      console.error('Failed to upload voice note:', err);
      toast({
        title: t('uploadFailed'),
        description: t('tryAgainLater'),
        variant: 'destructive'
      });
    } finally {
      setIsUploading(false);
    }
  };
  
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between mb-2">
        <label className="block text-gray-700 text-sm font-medium">
          {t('vendor.voiceDesc')}
        </label>
        {isRecording && (
          <div className="flex items-center text-red-500 animate-pulse">
            <span className="inline-block h-2 w-2 rounded-full bg-red-500 mr-2"></span>
            <span className="text-sm">{formatTime(recordingDuration)}</span>
          </div>
        )}
      </div>
      
      {!audioURL ? (
        <button
          type="button"
          className="w-full flex items-center justify-center bg-gray-100 hover:bg-gray-200 text-gray-700 py-3 px-4 rounded-lg transition relative overflow-hidden"
          onMouseDown={handleStartRecording}
          onMouseUp={handleStopRecording}
          onTouchStart={handleStartRecording}
          onTouchEnd={handleStopRecording}
        >
          <i className={`fas fa-microphone mr-2 ${isRecording ? 'text-red-500' : ''}`}></i>
          <span>{t('vendor.recordVoice')}</span>
          
          {isRecording && (
            <span 
              className="absolute bottom-0 left-0 h-1 bg-red-500"
              style={{ width: `${Math.min((recordingDuration / 60) * 100, 100)}%` }}
            ></span>
          )}
        </button>
      ) : (
        <div className="space-y-3">
          <div className="bg-gray-50 rounded-lg p-3">
            <audio src={audioURL} controls className="w-full" />
          </div>
          
          <div className="flex space-x-2">
            <Button
              onClick={handleUpload}
              disabled={isUploading}
              className="flex-1"
              variant="default"
            >
              {isUploading ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2"></i>
                  {t('uploading')}
                </>
              ) : (
                <>
                  <i className="fas fa-check mr-2"></i>
                  {t('useRecording')}
                </>
              )}
            </Button>
            
            <Button
              onClick={clearRecording}
              variant="outline"
              className="flex-shrink-0"
            >
              <i className="fas fa-trash-alt mr-2"></i>
              {t('discard')}
            </Button>
          </div>
        </div>
      )}
      
      <p className="text-xs text-gray-500 mt-1">
        {t('voiceDescription')}
      </p>
    </div>
  );
};

export default VoiceNoteRecorder;
