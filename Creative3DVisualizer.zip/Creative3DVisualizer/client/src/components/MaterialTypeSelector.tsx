import { useTranslation } from 'react-i18next';
import { 
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface MaterialTypeOption {
  value: string;
  label: string;
  group?: string;
}

interface MaterialTypeSelectorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  label?: string;
  required?: boolean;
  disabled?: boolean;
}

const MaterialTypeSelector: React.FC<MaterialTypeSelectorProps> = ({
  value,
  onChange,
  placeholder,
  label,
  required = false,
  disabled = false
}) => {
  const { t } = useTranslation();
  
  // Material type options grouped by category
  const materialTypeOptions: { [key: string]: MaterialTypeOption[] } = {
    plastic: [
      { value: 'plastic_hdpe', label: t('materials.plasticHDPE'), group: 'plastic' },
      { value: 'plastic_pet', label: t('materials.plasticPET'), group: 'plastic' },
      { value: 'plastic_ldpe', label: t('materials.plasticLDPE'), group: 'plastic' },
      { value: 'plastic_pp', label: t('materials.plasticPP'), group: 'plastic' },
      { value: 'plastic_other', label: t('materials.plasticOther'), group: 'plastic' }
    ],
    paper: [
      { value: 'paper_cardboard', label: t('materials.paperCardboard'), group: 'paper' },
      { value: 'paper_newspaper', label: t('materials.paperNewspaper'), group: 'paper' },
      { value: 'paper_mixed', label: t('materials.paperMixed'), group: 'paper' },
      { value: 'paper_other', label: t('materials.paperOther'), group: 'paper' }
    ],
    metal: [
      { value: 'metal_aluminum', label: t('materials.metalAluminum'), group: 'metal' },
      { value: 'metal_steel', label: t('materials.metalSteel'), group: 'metal' },
      { value: 'metal_copper', label: t('materials.metalCopper'), group: 'metal' },
      { value: 'metal_other', label: t('materials.metalOther'), group: 'metal' }
    ],
    glass: [
      { value: 'glass_clear', label: t('materials.glassClear'), group: 'glass' },
      { value: 'glass_colored', label: t('materials.glassColored'), group: 'glass' },
      { value: 'glass_other', label: t('materials.glassOther'), group: 'glass' }
    ],
    other: [
      { value: 'ewaste', label: t('materials.ewaste'), group: 'other' },
      { value: 'textile', label: t('materials.textile'), group: 'other' },
      { value: 'organic', label: t('materials.organic'), group: 'other' },
      { value: 'mixed', label: t('materials.mixed'), group: 'other' }
    ]
  };
  
  // Flatten all options for validation
  const allOptions = Object.values(materialTypeOptions).flat();
  
  // Handle change
  const handleChange = (newValue: string) => {
    onChange(newValue);
  };
  
  return (
    <div className="space-y-2">
      {label && (
        <label className="block text-gray-700 mb-1">
          {label} {required && <span className="text-red-500">*</span>}
        </label>
      )}
      
      <Select
        value={value}
        onValueChange={handleChange}
        disabled={disabled}
      >
        <SelectTrigger className="w-full">
          <SelectValue placeholder={placeholder || t('selectMaterialType')} />
        </SelectTrigger>
        
        <SelectContent>
          <SelectGroup>
            <SelectLabel>{t('materials.plastic')}</SelectLabel>
            {materialTypeOptions.plastic.map(option => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectGroup>
          
          <SelectGroup>
            <SelectLabel>{t('materials.paper')}</SelectLabel>
            {materialTypeOptions.paper.map(option => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectGroup>
          
          <SelectGroup>
            <SelectLabel>{t('materials.metal')}</SelectLabel>
            {materialTypeOptions.metal.map(option => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectGroup>
          
          <SelectGroup>
            <SelectLabel>{t('materials.glass')}</SelectLabel>
            {materialTypeOptions.glass.map(option => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectGroup>
          
          <SelectGroup>
            <SelectLabel>{t('materials.other')}</SelectLabel>
            {materialTypeOptions.other.map(option => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectGroup>
        </SelectContent>
      </Select>
    </div>
  );
};

export default MaterialTypeSelector;
