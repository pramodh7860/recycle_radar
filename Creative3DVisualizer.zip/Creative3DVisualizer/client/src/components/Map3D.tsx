import { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import useLocation from '../hooks/useLocation';
import * as THREE from 'three';
import { Location } from '@shared/schema';

interface MapPin {
  id: number;
  lat: number;
  lng: number;
  title: string;
  type: 'vendor' | 'factory';
  subType?: string; // e.g., 'plastic', 'paper', etc.
}

interface Map3DProps {
  pins: MapPin[];
  userLocation?: Location;
  mapType: 'vendor' | 'factory';
  onPinClick?: (pinId: number) => void;
  height?: string;
}

const Map3D: React.FC<Map3DProps> = ({
  pins,
  userLocation,
  mapType,
  onPinClick,
  height = 'h-80'
}) => {
  const { t } = useTranslation();
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLDivElement>(null);
  const { coordinates, getLocation } = useLocation();
  
  const [activePinId, setActivePinId] = useState<number | null>(null);
  const [isMapLoaded, setIsMapLoaded] = useState(false);

  // Group pins by type for the legend
  const plasticPinsCount = pins.filter(pin => pin.subType === 'plastic').length;
  const paperPinsCount = pins.filter(pin => pin.subType === 'paper').length;
  const metalPinsCount = pins.filter(pin => pin.subType === 'metal').length;
  
  // Initialize 3D map
  useEffect(() => {
    if (!canvasRef.current) return;
    
    // Setup scene
    const scene = new THREE.Scene();
    
    // Setup camera (top-down view for map)
    const camera = new THREE.PerspectiveCamera(60, mapContainerRef.current!.clientWidth / mapContainerRef.current!.clientHeight, 0.1, 1000);
    camera.position.set(0, 20, 0);
    camera.lookAt(0, 0, 0);
    
    // Setup renderer
    const renderer = new THREE.WebGLRenderer({ 
      antialias: true,
      alpha: true
    });
    renderer.setSize(mapContainerRef.current!.clientWidth, mapContainerRef.current!.clientHeight);
    canvasRef.current.appendChild(renderer.domElement);
    
    // Add ambient light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);
    
    // Add directional light (sunlight effect)
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(10, 20, 10);
    scene.add(directionalLight);
    
    // Create ground plane (map base)
    const groundGeometry = new THREE.PlaneGeometry(50, 50);
    const groundMaterial = new THREE.MeshStandardMaterial({
      color: 0xeeeeee,
      roughness: 0.8,
      transparent: true,
      opacity: 0.7
    });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = -Math.PI / 2; // rotate to be horizontal
    scene.add(ground);
    
    // Add grid lines
    const gridHelper = new THREE.GridHelper(50, 20, 0x888888, 0xcccccc);
    scene.add(gridHelper);
    
    // Create function to add pins
    const createPin = (x: number, z: number, pinType: 'vendor' | 'factory', materialType?: string) => {
      const group = new THREE.Group();
      
      // Choose color based on type
      let color: number;
      if (pinType === 'vendor') {
        // Vendor pins - different colors based on material type
        if (materialType === 'plastic') {
          color = 0x2E7D32; // Green for plastic
        } else if (materialType === 'paper') {
          color = 0xFF9800; // Orange for paper
        } else if (materialType === 'metal') {
          color = 0x1976D2; // Blue for metal
        } else {
          color = 0x9C27B0; // Purple for others
        }
      } else {
        // Factory pins
        if (materialType === 'plastic') {
          color = 0x388E3C; // Dark green for plastic factories
        } else if (materialType === 'paper') {
          color = 0xE65100; // Dark orange for paper factories
        } else if (materialType === 'metal') {
          color = 0x0D47A1; // Dark blue for metal factories
        } else {
          color = 0x6A1B9A; // Dark purple for others
        }
      }
      
      // Create pin base (cone shape for vendor, cylinder for factory)
      let baseGeometry;
      if (pinType === 'vendor') {
        baseGeometry = new THREE.ConeGeometry(0.5, 1.5, 16);
      } else {
        baseGeometry = new THREE.CylinderGeometry(0.3, 0.5, 1.2, 16);
      }
      
      const baseMaterial = new THREE.MeshStandardMaterial({ color });
      const base = new THREE.Mesh(baseGeometry, baseMaterial);
      
      // Position the pin base
      if (pinType === 'vendor') {
        base.position.y = 0.75; // Half of the cone height
      } else {
        base.position.y = 0.6; // Half of the cylinder height
      }
      
      group.add(base);
      
      // Add a sphere on top for better visibility
      const headGeometry = new THREE.SphereGeometry(0.3, 16, 16);
      const headMaterial = new THREE.MeshStandardMaterial({ color });
      const head = new THREE.Mesh(headGeometry, headMaterial);
      head.position.y = 1.6; // Position on top of the base
      
      group.add(head);
      
      // Position the entire pin
      group.position.set(x, 0, z);
      
      return group;
    };
    
    // Add pins to the scene
    pins.forEach(pin => {
      // Convert lat/lng to x/z coordinates (simplified mapping)
      // In a real app, you would use proper geo-mapping
      const x = (pin.lng - (coordinates?.lng || 0)) * 10;
      const z = (pin.lat - (coordinates?.lat || 0)) * 10;
      
      const pinMesh = createPin(x, z, pin.type, pin.subType);
      pinMesh.userData = { id: pin.id }; // Store pin ID for click detection
      scene.add(pinMesh);
    });
    
    // Add user location pin if available
    if (coordinates) {
      const userPin = createPin(0, 0, 'vendor');
      
      // Make user pin distinctive
      const userPinHead = userPin.children[1] as THREE.Mesh;
      (userPinHead.material as THREE.MeshStandardMaterial).color.set(0xFF0000); // Red color
      userPinHead.scale.set(1.5, 1.5, 1.5); // Make it larger
      
      scene.add(userPin);
    }
    
    // Handle window resize
    const handleResize = () => {
      if (!mapContainerRef.current) return;
      
      const width = mapContainerRef.current.clientWidth;
      const height = mapContainerRef.current.clientHeight;
      
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };
    
    // Add orbit controls-like animation
    let angle = 0;
    const animate = () => {
      requestAnimationFrame(animate);
      
      // Rotate camera around the center for a dynamic view
      angle += 0.001;
      camera.position.x = Math.sin(angle) * 25;
      camera.position.z = Math.cos(angle) * 25;
      camera.lookAt(new THREE.Vector3(0, 0, 0));
      
      renderer.render(scene, camera);
    };
    
    window.addEventListener('resize', handleResize);
    animate();
    setIsMapLoaded(true);
    
    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      if (canvasRef.current && canvasRef.current.contains(renderer.domElement)) {
        canvasRef.current.removeChild(renderer.domElement);
      }
      
      // Dispose resources
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh) {
          object.geometry.dispose();
          if (Array.isArray(object.material)) {
            object.material.forEach(material => material.dispose());
          } else {
            object.material.dispose();
          }
        }
      });
    };
  }, [pins, coordinates]);

  return (
    <div id={`${mapType}-map`} className={`${height} w-full bg-gray-200 relative`} ref={mapContainerRef}>
      {/* Map Canvas Element */}
      <div id={`${mapType}-map-canvas`} className="absolute top-0 left-0 w-full h-full" ref={canvasRef}></div>
      
      {/* Loading State */}
      {!isMapLoaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-100 bg-opacity-80">
          <div className="text-primary-dark">
            <i className="fas fa-spinner fa-spin text-3xl mr-2"></i>
            <span>{t('loading')}</span>
          </div>
        </div>
      )}
      
      {/* Map Controls Overlay */}
      <div className="absolute top-4 right-4 z-10">
        <button 
          className="bg-white rounded-full p-2 shadow-md text-primary-dark hover:bg-gray-100"
          onClick={getLocation}
          title={t('getCurrentLocation')}
        >
          <i className="fas fa-location-crosshairs"></i>
        </button>
      </div>
      
      {/* Pins Legend */}
      <div className="absolute bottom-4 left-4 z-10 bg-white rounded-lg shadow-md p-3">
        {mapType === 'vendor' ? (
          <>
            {plasticPinsCount > 0 && (
              <div className="flex items-center text-sm mb-1">
                <i className="fas fa-industry text-secondary-dark mr-2"></i>
                <span>{t('plasticFactories', { count: plasticPinsCount })}</span>
              </div>
            )}
            {paperPinsCount > 0 && (
              <div className="flex items-center text-sm">
                <i className="fas fa-industry text-accent-dark mr-2"></i>
                <span>{t('paperMills', { count: paperPinsCount })}</span>
              </div>
            )}
            {metalPinsCount > 0 && (
              <div className="flex items-center text-sm">
                <i className="fas fa-industry text-secondary mr-2"></i>
                <span>{t('metalFactories', { count: metalPinsCount })}</span>
              </div>
            )}
          </>
        ) : (
          <>
            {plasticPinsCount > 0 && (
              <div className="flex items-center text-sm mb-1">
                <i className="fas fa-recycle text-primary-dark mr-2"></i>
                <span>{t('plasticVendors', { count: plasticPinsCount })}</span>
              </div>
            )}
            {paperPinsCount > 0 && (
              <div className="flex items-center text-sm">
                <i className="fas fa-recycle text-accent-dark mr-2"></i>
                <span>{t('paperVendors', { count: paperPinsCount })}</span>
              </div>
            )}
            {metalPinsCount > 0 && (
              <div className="flex items-center text-sm">
                <i className="fas fa-recycle text-primary mr-2"></i>
                <span>{t('metalVendors', { count: metalPinsCount })}</span>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default Map3D;
