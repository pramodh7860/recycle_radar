import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useTranslation } from 'react-i18next';
import LanguageSelector from './LanguageSelector';

const Header = () => {
  const { t } = useTranslation();
  const [location] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  
  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  const isHome = location === '/';
  
  return (
    <header className="bg-glass sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/" className="flex items-center">
              <div className="text-primary-dark text-3xl mr-2 animate-float">
                <i className="fas fa-recycle"></i>
              </div>
              <h1 className="text-2xl font-bold text-primary-dark">RecycleRadar</h1>
          </Link>
        </div>
        
        <div className="hidden md:flex items-center space-x-6">
          {!isHome && (
            <nav>
              <ul className="flex space-x-6">
                <li>
                  <Link href="/" className="text-gray-700 hover:text-primary-dark transition-colors">
                    {t('common.home')}
                  </Link>
                </li>
                <li>
                  <Link href="/vendor-dashboard" className={`hover:text-primary-dark transition-colors ${location === '/vendor-dashboard' ? 'text-primary-dark font-medium' : 'text-gray-700'}`}>
                    {t('userTypes.vendor')}
                  </Link>
                </li>
                <li>
                  <Link href="/factory-dashboard" className={`hover:text-primary-dark transition-colors ${location === '/factory-dashboard' ? 'text-primary-dark font-medium' : 'text-gray-700'}`}>
                    {t('userTypes.factory')}
                  </Link>
                </li>
                <li>
                  <Link href="/entrepreneur-dashboard" className={`hover:text-primary-dark transition-colors ${location === '/entrepreneur-dashboard' ? 'text-primary-dark font-medium' : 'text-gray-700'}`}>
                    {t('userTypes.entrepreneur')}
                  </Link>
                </li>
              </ul>
            </nav>
          )}
          
          <LanguageSelector />
        </div>
        
        {/* Mobile menu button */}
        <div className="md:hidden flex items-center">
          <LanguageSelector />
          {!isHome && (
            <button 
              onClick={toggleMenu}
              className="ml-4 p-2 rounded-md text-gray-700 hover:bg-gray-100 hover:text-primary-dark focus:outline-none"
            >
              <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={menuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} />
              </svg>
            </button>
          )}
        </div>
      </div>
      
      {/* Mobile menu */}
      {menuOpen && !isHome && (
        <div className="md:hidden bg-white py-2 px-4 shadow-md">
          <nav>
            <ul className="space-y-2">
              <li>
                <Link 
                  href="/" 
                  className="block py-2 text-gray-700 hover:text-primary-dark transition-colors"
                  onClick={() => setMenuOpen(false)}
                >
                  {t('common.home')}
                </Link>
              </li>
              <li>
                <Link 
                  href="/vendor-dashboard" 
                  className={`block py-2 hover:text-primary-dark transition-colors ${location === '/vendor-dashboard' ? 'text-primary-dark font-medium' : 'text-gray-700'}`}
                  onClick={() => setMenuOpen(false)}
                >
                  {t('userTypes.vendor')}
                </Link>
              </li>
              <li>
                <Link 
                  href="/factory-dashboard" 
                  className={`block py-2 hover:text-primary-dark transition-colors ${location === '/factory-dashboard' ? 'text-primary-dark font-medium' : 'text-gray-700'}`}
                  onClick={() => setMenuOpen(false)}
                >
                  {t('userTypes.factory')}
                </Link>
              </li>
              <li>
                <Link 
                  href="/entrepreneur-dashboard" 
                  className={`block py-2 hover:text-primary-dark transition-colors ${location === '/entrepreneur-dashboard' ? 'text-primary-dark font-medium' : 'text-gray-700'}`}
                  onClick={() => setMenuOpen(false)}
                >
                  {t('userTypes.entrepreneur')}
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
