import { useEffect, useRef } from 'react';
import * as THREE from 'three';

// Silence TypeScript errors for now
// @ts-ignore

const ThreeBackground = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!containerRef.current) return;
    
    // Setup scene
    const scene = new THREE.Scene();
    
    // Setup camera
    const camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.z = 15;
    
    // Setup renderer
    const renderer = new THREE.WebGLRenderer({ 
      alpha: true, 
      antialias: true 
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    
    // Add renderer to DOM
    containerRef.current.appendChild(renderer.domElement);
    
    // Add ambient light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);
    
    // Add directional light
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(0, 10, 5);
    scene.add(directionalLight);
    
    // Create recycling objects with different geometries
    const objects: (THREE.Mesh | THREE.Group)[] = [];
    
    // Create recycling symbol geometries
    const createRecyclingArrow = () => {
      const shape = new THREE.Shape();
      
      // Define arrow shape
      shape.moveTo(0, 0);
      shape.lineTo(1, 0);
      shape.lineTo(1, 0.3);
      shape.lineTo(1.5, 0.3);
      shape.lineTo(0.75, 1);
      shape.lineTo(0, 0.3);
      shape.lineTo(0.5, 0.3);
      shape.lineTo(0.5, 0);
      
      const extrudeSettings = {
        steps: 1,
        depth: 0.1,
        bevelEnabled: true,
        bevelThickness: 0.05,
        bevelSize: 0.05,
        bevelSegments: 3
      };
      
      return new THREE.ExtrudeGeometry(shape, extrudeSettings);
    };
    
    // Add recycling arrows in triangular formation
    const createRecyclingSymbol = () => {
      const group = new THREE.Group();
      
      const arrow1 = createRecyclingArrow();
      const arrow2 = createRecyclingArrow();
      const arrow3 = createRecyclingArrow();
      
      const colorChoices = [
        new THREE.MeshPhongMaterial({ color: 0x2E7D32, transparent: true, opacity: 0.8 }), // Green
        new THREE.MeshPhongMaterial({ color: 0x1976D2, transparent: true, opacity: 0.8 }), // Blue
        new THREE.MeshPhongMaterial({ color: 0xFF9800, transparent: true, opacity: 0.8 })  // Orange
      ];
      
      const mesh1 = new THREE.Mesh(arrow1, colorChoices[0]);
      const mesh2 = new THREE.Mesh(arrow2, colorChoices[1]);
      const mesh3 = new THREE.Mesh(arrow3, colorChoices[2]);
      
      mesh1.position.set(0, 0, 0);
      
      mesh2.position.set(-0.5, -0.8, 0);
      mesh2.rotation.z = Math.PI * 2 / 3;
      
      mesh3.position.set(0.5, -0.8, 0);
      mesh3.rotation.z = -Math.PI * 2 / 3;
      
      group.add(mesh1);
      group.add(mesh2);
      group.add(mesh3);
      
      return group;
    };
    
    // Create plastic bottle geometry
    const createBottle = () => {
      const points = [];
      for (let i = 0; i < 20; i++) {
        const t = i / 19;
        const y = t * 2 - 1; // Range from -1 to 1
        let radius;
        
        if (t < 0.1) {
          // Bottle cap
          radius = 0.2;
        } else if (t < 0.2) {
          // Bottle neck
          radius = 0.2 + (t - 0.1) * 3;
        } else if (t < 0.8) {
          // Bottle body
          radius = 0.5;
        } else {
          // Bottle base
          radius = 0.5 - (t - 0.8) * 2.5;
        }
        
        points.push(new THREE.Vector2(radius, y));
      }
      
      return new THREE.LatheGeometry(points, 20);
    };
    
    // Create paper geometry
    const createPaper = () => {
      const geometry = new THREE.BoxGeometry(1.2, 1.5, 0.05);
      return geometry;
    };
    
    // Create tin can geometry
    const createCan = () => {
      const geometry = new THREE.CylinderGeometry(0.5, 0.5, 1.5, 32);
      return geometry;
    };
    
    // Create various recycling-related geometries
    const geometries = [
      createBottle(),
      createPaper(),
      createCan(),
      new THREE.TorusKnotGeometry(0.6, 0.2, 64, 8, 2, 3), // Complex shape
      new THREE.IcosahedronGeometry(0.8, 0)                // Another complex shape
    ];
    
    // Materials with recycling colors
    const materials = [
      new THREE.MeshPhongMaterial({ color: 0x2E7D32, transparent: true, opacity: 0.8 }), // Green
      new THREE.MeshPhongMaterial({ color: 0x1976D2, transparent: true, opacity: 0.8 }), // Blue
      new THREE.MeshPhongMaterial({ color: 0xFF9800, transparent: true, opacity: 0.8 })  // Orange
    ];
    
    // Add recycling symbols
    for (let i = 0; i < 5; i++) {
      const symbol = createRecyclingSymbol();
      symbol.position.x = Math.random() * 30 - 15;
      symbol.position.y = Math.random() * 30 - 15;
      symbol.position.z = Math.random() * 30 - 25;
      symbol.rotation.x = Math.random() * Math.PI;
      symbol.rotation.y = Math.random() * Math.PI;
      symbol.scale.set(0.7, 0.7, 0.7);
      scene.add(symbol);
      
      // Add to objects for animation
      objects.push(symbol);
    }
    
    // Add other recycling objects
    for (let i = 0; i < 10; i++) {
      const geometryIndex = Math.floor(Math.random() * geometries.length);
      const materialIndex = Math.floor(Math.random() * materials.length);
      
      const object = new THREE.Mesh(geometries[geometryIndex], materials[materialIndex]);
      
      // Position randomly in the scene
      object.position.x = Math.random() * 40 - 20;
      object.position.y = Math.random() * 40 - 20;
      object.position.z = Math.random() * 40 - 30;
      
      // Random rotation
      object.rotation.x = Math.random() * 2 * Math.PI;
      object.rotation.y = Math.random() * 2 * Math.PI;
      object.rotation.z = Math.random() * 2 * Math.PI;
      
      // Random scale
      const scale = Math.random() * 0.5 + 0.3;
      object.scale.set(scale, scale, scale);
      
      scene.add(object);
      objects.push(object);
    }
    
    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);
      
      // Rotate all objects
      objects.forEach(object => {
        object.rotation.x += 0.003;
        object.rotation.y += 0.005;
      });
      
      // Rotate camera slightly for parallax effect
      camera.position.x = Math.sin(Date.now() * 0.0001) * 3;
      camera.position.y = Math.cos(Date.now() * 0.0001) * 3;
      camera.lookAt(scene.position);
      
      renderer.render(scene, camera);
    };
    
    // Handle window resize
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    
    window.addEventListener('resize', handleResize);
    
    // Start animation
    animate();
    
    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      if (containerRef.current) {
        containerRef.current.removeChild(renderer.domElement);
      }
      
      // Dispose geometries and materials
      objects.forEach(object => {
        // Handle different object types
        if (object instanceof THREE.Mesh) {
          // It's a mesh, dispose geometry and material
          if (object.geometry) {
            object.geometry.dispose();
          }
          
          if (object.material) {
            if (Array.isArray(object.material)) {
              object.material.forEach((material: THREE.Material) => material.dispose());
            } else {
              object.material.dispose();
            }
          }
        } else if (object instanceof THREE.Group) {
          // It's a group, recursively traverse children
          object.traverse(child => {
            if (child instanceof THREE.Mesh) {
              if (child.geometry) {
                child.geometry.dispose();
              }
              
              if (child.material) {
                if (Array.isArray(child.material)) {
                  child.material.forEach((material: THREE.Material) => material.dispose());
                } else {
                  child.material.dispose();
                }
              }
            }
          });
        }
      });
      
      // Dispose all geometries
      geometries.forEach(geometry => {
        geometry.dispose();
      });
      
      // Dispose all materials
      materials.forEach(material => {
        material.dispose();
      });
      
      // Clear scene
      scene.clear();
    };
  }, []);
  
  return (
    <div 
      ref={containerRef} 
      className="canvas-container" 
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        zIndex: -1
      }}
    />
  );
};

export default ThreeBackground;
