import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';

interface RecyclingCardProps {
  role: 'vendor' | 'factory' | 'entrepreneur';
  image: string;
  title: string;
  description: string;
  features: string[];
  buttonText: string;
  onClick: () => void;
}

const RecyclingCard: React.FC<RecyclingCardProps> = ({
  role,
  image,
  title,
  description,
  features,
  buttonText,
  onClick
}) => {
  const { t } = useTranslation();
  
  // Define background color based on role
  const getBgColor = () => {
    switch (role) {
      case 'vendor':
        return 'bg-primary-light';
      case 'factory':
        return 'bg-secondary-light';
      case 'entrepreneur':
        return 'bg-accent-light';
      default:
        return 'bg-primary-light';
    }
  };
  
  // Define button color based on role
  const getButtonClass = () => {
    switch (role) {
      case 'vendor':
        return 'bg-primary hover:bg-primary-dark';
      case 'factory':
        return 'bg-secondary hover:bg-secondary-dark';
      case 'entrepreneur':
        return 'bg-accent hover:bg-accent-dark';
      default:
        return 'bg-primary hover:bg-primary-dark';
    }
  };
  
  return (
    <motion.div 
      className="recycling-card card-3d bg-white rounded-xl shadow-lg overflow-hidden"
      whileHover={{ 
        translateY: -5,
        scale: 1.02,
        boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)" 
      }}
      transition={{ duration: 0.3 }}
      data-role={role}
    >
      <div className={`h-48 ${getBgColor()} relative overflow-hidden`}>
        <img 
          src={image}
          className="w-full h-full object-cover"
          alt={title}
        />
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/70 to-transparent">
          <h3 className="text-white text-xl font-bold">{title}</h3>
        </div>
      </div>
      
      <div className="p-6">
        <p className="text-gray-600 mb-6">{description}</p>
        
        <ul className="mb-6 text-sm text-gray-700">
          {features.map((feature, index) => (
            <li key={index} className="flex items-center mb-2">
              <i className="fas fa-check-circle text-success mr-2"></i>
              {feature}
            </li>
          ))}
        </ul>
        
        <button 
          onClick={onClick} 
          className={`w-full py-3 ${getButtonClass()} rounded-lg text-white font-medium transition-colors duration-300`}
        >
          {buttonText}
        </button>
      </div>
    </motion.div>
  );
};

export default RecyclingCard;
