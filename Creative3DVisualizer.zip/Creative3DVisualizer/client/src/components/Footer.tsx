import { Link } from 'wouter';
import { useTranslation } from 'react-i18next';

const Footer = () => {
  const { t } = useTranslation();
  
  return (
    <footer className="bg-glass py-6 mt-auto">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <div className="flex items-center justify-center md:justify-start">
              <div className="text-primary-dark text-2xl mr-2">
                <i className="fas fa-recycle"></i>
              </div>
              <h2 className="text-xl font-bold text-primary-dark">RecycleRadar</h2>
            </div>
            <p className="text-sm text-gray-600 mt-1 text-center md:text-left">
              {t('footerTagline')}
            </p>
          </div>
          
          <div className="flex space-x-8">
            <div>
              <h3 className="text-sm font-semibold text-gray-700 mb-2">
                {t('support')}
              </h3>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>
                  <Link href="#" className="hover:text-primary-dark">
                    {t('helpCenter')}
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-primary-dark">
                    {t('contactUs')}
                  </Link>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-sm font-semibold text-gray-700 mb-2">
                {t('legal')}
              </h3>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>
                  <Link href="#" className="hover:text-primary-dark">
                    {t('privacyPolicy')}
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-primary-dark">
                    {t('termsOfUse')}
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="mt-6 pt-6 border-t border-gray-200">
          <p className="text-center text-sm text-gray-500">
            {t('copyright')}
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
