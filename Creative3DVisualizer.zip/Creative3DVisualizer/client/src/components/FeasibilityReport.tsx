import { useTranslation } from 'react-i18next';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/hooks/use-toast';
import { downloadFeasibilityReport, emailFeasibilityReport } from '../lib/reportsGenerator';

interface InvestmentItem {
  name: string;
  amount: number;
}

interface RevenueItem {
  name: string;
  value: string | number;
}

interface FeasibilityReportProps {
  businessType: string;
  roiMonths: number;
  investment: InvestmentItem[];
  revenue: RevenueItem[];
  subsidies: string[];
  licenses: string[];
  location?: string;
  budget?: string;
  land?: number;
  capacity?: number;
}

const FeasibilityReport: React.FC<FeasibilityReportProps> = ({
  businessType,
  roiMonths,
  investment,
  revenue,
  subsidies,
  licenses,
  location,
  budget,
  land,
  capacity
}) => {
  const { t, i18n } = useTranslation();
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [isSending, setIsSending] = useState(false);
  
  const totalInvestment = investment.reduce((sum, item) => sum + item.amount, 0);
  
  const handleDownload = () => {
    downloadFeasibilityReport({
      businessType,
      roiMonths,
      investment,
      revenue,
      subsidies,
      licenses,
      location,
      budget,
      land,
      capacity
    }, 'recycleradar-feasibility-report.pdf', i18n.language);
    
    toast({
      title: t('reportDownloaded'),
      description: t('reportDownloadSuccess'),
      variant: 'default'
    });
  };
  
  const handleEmailReport = async () => {
    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
      toast({
        title: t('invalidEmail'),
        description: t('pleaseEnterValidEmail'),
        variant: 'destructive'
      });
      return;
    }
    
    setIsSending(true);
    
    try {
      const result = await emailFeasibilityReport({
        businessType,
        roiMonths,
        investment,
        revenue,
        subsidies,
        licenses,
        location,
        budget,
        land,
        capacity
      }, email, i18n.language);
      
      if (result) {
        toast({
          title: t('reportEmailed'),
          description: t('reportEmailSuccess', { email }),
          variant: 'default'
        });
        setIsEmailModalOpen(false);
      } else {
        throw new Error('Failed to send email');
      }
    } catch (err) {
      toast({
        title: t('emailFailed'),
        description: t('tryAgainLater'),
        variant: 'destructive'
      });
    } finally {
      setIsSending(false);
    }
  };
  
  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-xl font-semibold">{t('entrepreneur.feasibilityReport')}</h3>
        <div>
          <Button 
            onClick={handleDownload}
            variant="default"
            className="bg-accent hover:bg-accent-dark text-white mr-2"
          >
            <i className="fas fa-download mr-1"></i> {t('buttons.download')}
          </Button>
          <Button 
            onClick={() => setIsEmailModalOpen(true)}
            variant="outline"
          >
            <i className="fas fa-envelope mr-1"></i> {t('buttons.email')}
          </Button>
        </div>
      </div>
      
      <div className="border rounded-lg p-5">
        <div className="mb-4 pb-4 border-b border-gray-200">
          <h4 className="font-semibold text-lg mb-2">{t('entrepreneur.businessRecommendation')}</h4>
          <p className="text-md">
            <span className="text-accent-dark font-medium">{businessType}</span> - {t('estimatedRoi')} {roiMonths} {t('months')}
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <h5 className="font-medium mb-2">{t('entrepreneur.investmentBreakdown')}</h5>
            <ul className="text-sm space-y-1">
              {investment.map((item, index) => (
                <li key={index} className="flex justify-between">
                  <span>{item.name}:</span> 
                  <span>₹{item.amount.toLocaleString()}</span>
                </li>
              ))}
              <li className="flex justify-between font-medium">
                <span>{t('totalInvestment')}:</span> 
                <span>₹{totalInvestment.toLocaleString()}</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h5 className="font-medium mb-2">{t('entrepreneur.revenueProjection')}</h5>
            <ul className="text-sm space-y-1">
              {revenue.map((item, index) => (
                <li key={index} className="flex justify-between">
                  <span>{item.name}:</span> 
                  <span>
                    {typeof item.value === 'number' && item.name.includes('₹') 
                      ? `₹${item.value.toLocaleString()}` 
                      : item.value}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="mb-4 pb-4 border-b border-gray-200">
          <h5 className="font-medium mb-2">{t('entrepreneur.eligibleSubsidies')}</h5>
          <div className="flex flex-wrap gap-2">
            {subsidies.map((subsidy, index) => (
              <span key={index} className="bg-green-100 text-green-800 text-xs font-medium px-2 py-1 rounded">{subsidy}</span>
            ))}
          </div>
        </div>
        
        <div>
          <h5 className="font-medium mb-2">{t('entrepreneur.requiredLicenses')}</h5>
          <ul className="text-sm list-disc list-inside space-y-1">
            {licenses.map((license, index) => (
              <li key={index}>{license}</li>
            ))}
          </ul>
        </div>
      </div>
      
      {/* Email Modal */}
      {isEmailModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h4 className="text-lg font-semibold mb-4">{t('emailReport')}</h4>
            
            <div className="space-y-4">
              <div>
                <label className="block text-gray-700 mb-2">{t('emailAddress')}</label>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                />
              </div>
              
              <div className="flex space-x-2">
                <Button
                  onClick={handleEmailReport}
                  variant="default"
                  className="flex-1"
                  disabled={isSending}
                >
                  {isSending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      {t('sending')}
                    </>
                  ) : (
                    t('sendReport')
                  )}
                </Button>
                
                <Button
                  onClick={() => setIsEmailModalOpen(false)}
                  variant="outline"
                >
                  {t('cancel')}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FeasibilityReport;
