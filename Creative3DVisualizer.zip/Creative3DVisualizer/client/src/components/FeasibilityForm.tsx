import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import MaterialTypeSelector from './MaterialTypeSelector';

interface FeasibilityFormData {
  businessType: string;
  availableLand: number;
  investmentBudget: string;
  location: string;
  processingCapacity: number;
  materialType: string;
}

interface FeasibilityFormProps {
  onSubmit: (data: FeasibilityFormData) => void;
  isLoading?: boolean;
}

const FeasibilityForm: React.FC<FeasibilityFormProps> = ({ 
  onSubmit,
  isLoading = false
}) => {
  const { t } = useTranslation();
  const { register, handleSubmit, setValue, watch, formState: { errors } } = useForm<FeasibilityFormData>({
    defaultValues: {
      businessType: '',
      availableLand: 100,
      investmentBudget: '',
      location: 'urban',
      processingCapacity: 200,
      materialType: ''
    }
  });
  
  const [materialType, setMaterialType] = useState('');
  
  const handleMaterialTypeChange = (value: string) => {
    setMaterialType(value);
    setValue('materialType', value);
  };
  
  const selectedBusinessType = watch('businessType');
  
  const businessTypes = [
    { value: 'plastic_recycling', label: t('businessTypes.plasticRecycling') },
    { value: 'paper_recycling', label: t('businessTypes.paperRecycling') },
    { value: 'metal_recycling', label: t('businessTypes.metalRecycling') },
    { value: 'ewaste_recycling', label: t('businessTypes.ewasteRecycling') },
    { value: 'collection_center', label: t('businessTypes.collectionCenter') },
    { value: 'waste_aggregation', label: t('businessTypes.wasteAggregation') }
  ];
  
  const budgetRanges = [
    { value: 'under_5_lakhs', label: t('budgetRanges.under5Lakhs') },
    { value: '5_10_lakhs', label: t('budgetRanges.5to10Lakhs') },
    { value: '10_25_lakhs', label: t('budgetRanges.10to25Lakhs') },
    { value: '25_50_lakhs', label: t('budgetRanges.25to50Lakhs') },
    { value: '50_lakhs_1_crore', label: t('budgetRanges.50LakhsTo1Crore') },
    { value: 'above_1_crore', label: t('budgetRanges.above1Crore') }
  ];
  
  const locationTypes = [
    { value: 'urban', label: t('locationTypes.urban') },
    { value: 'peri_urban', label: t('locationTypes.periUrban') },
    { value: 'rural', label: t('locationTypes.rural') }
  ];
  
  const onSubmitForm = (data: FeasibilityFormData) => {
    onSubmit(data);
  };
  
  return (
    <form onSubmit={handleSubmit(onSubmitForm)} className="space-y-4">
      <div>
        <Label htmlFor="businessType">{t('entrepreneur.businessType')}</Label>
        <Select
          onValueChange={(value) => setValue('businessType', value)}
          defaultValue={selectedBusinessType}
        >
          <SelectTrigger>
            <SelectValue placeholder={t('selectBusinessType')} />
          </SelectTrigger>
          <SelectContent>
            {businessTypes.map(type => (
              <SelectItem key={type.value} value={type.value}>
                {type.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {errors.businessType && (
          <p className="text-sm text-red-500 mt-1">{t('requiredField')}</p>
        )}
      </div>
      
      <div>
        <MaterialTypeSelector
          value={materialType}
          onChange={handleMaterialTypeChange}
          label={t('materials.primaryMaterial')}
        />
      </div>
      
      <div>
        <Label htmlFor="availableLand">{t('entrepreneur.availableLand')}</Label>
        <div className="flex">
          <Input
            id="availableLand"
            type="number"
            {...register('availableLand', { required: true, min: 1 })}
          />
          <span className="ml-2 flex items-center text-gray-500">m²</span>
        </div>
        {errors.availableLand && (
          <p className="text-sm text-red-500 mt-1">{t('validLandRequired')}</p>
        )}
      </div>
      
      <div>
        <Label htmlFor="investmentBudget">{t('entrepreneur.investmentBudget')}</Label>
        <Select
          onValueChange={(value) => setValue('investmentBudget', value)}
          defaultValue={watch('investmentBudget')}
        >
          <SelectTrigger>
            <SelectValue placeholder={t('selectBudgetRange')} />
          </SelectTrigger>
          <SelectContent>
            {budgetRanges.map(range => (
              <SelectItem key={range.value} value={range.value}>
                {range.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {errors.investmentBudget && (
          <p className="text-sm text-red-500 mt-1">{t('requiredField')}</p>
        )}
      </div>
      
      <div>
        <Label htmlFor="location">{t('entrepreneur.location')}</Label>
        <Select
          onValueChange={(value) => setValue('location', value)}
          defaultValue={watch('location')}
        >
          <SelectTrigger>
            <SelectValue placeholder={t('selectLocationType')} />
          </SelectTrigger>
          <SelectContent>
            {locationTypes.map(locType => (
              <SelectItem key={locType.value} value={locType.value}>
                {locType.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <Label htmlFor="processingCapacity">{t('entrepreneur.processingCapacity')}</Label>
        <div className="flex">
          <Input
            id="processingCapacity"
            type="number"
            {...register('processingCapacity', { required: true, min: 1 })}
          />
          <span className="ml-2 flex items-center text-gray-500">kg/day</span>
        </div>
        {errors.processingCapacity && (
          <p className="text-sm text-red-500 mt-1">{t('validCapacityRequired')}</p>
        )}
      </div>
      
      <Button 
        type="submit" 
        className="w-full py-3 bg-accent hover:bg-accent-dark"
        disabled={isLoading}
      >
        {isLoading ? (
          <>
            <i className="fas fa-spinner fa-spin mr-2"></i>
            {t('generating')}
          </>
        ) : (
          t('buttons.generateReport')
        )}
      </Button>
    </form>
  );
};

export default FeasibilityForm;
