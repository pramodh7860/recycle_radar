import {
  users, wasteMaterials, factoryRequirements, bids, messages, businessTypes, resources,
  type User, type WasteMaterial, type FactoryRequirement, type Bid, type Message, type BusinessType, type Resource,
  type InsertUser, type InsertWasteMaterial, type InsertFactoryRequirement, type InsertBid, type InsertMessage,
  type InsertBusinessType, type InsertResource, type Location
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, sql } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Waste material methods
  createWasteMaterial(wasteMaterial: InsertWasteMaterial): Promise<WasteMaterial>;
  getWasteMaterialById(id: number): Promise<WasteMaterial | undefined>;
  getWasteMaterialsByVendor(vendorId: number): Promise<WasteMaterial[]>;
  getAvailableWasteMaterials(): Promise<WasteMaterial[]>;
  getWasteMaterialsByLocation(location: Location, radiusKm: number): Promise<WasteMaterial[]>;
  updateWasteMaterial(id: number, wasteMaterial: Partial<WasteMaterial>): Promise<WasteMaterial | undefined>;

  // Factory requirement methods
  createFactoryRequirement(requirement: InsertFactoryRequirement): Promise<FactoryRequirement>;
  getFactoryRequirementById(id: number): Promise<FactoryRequirement | undefined>;
  getFactoryRequirementsByFactory(factoryId: number): Promise<FactoryRequirement[]>;
  getActiveFactoryRequirements(): Promise<FactoryRequirement[]>;
  getFactoryRequirementsByLocation(location: Location, radiusKm: number): Promise<FactoryRequirement[]>;
  updateFactoryRequirement(id: number, requirement: Partial<FactoryRequirement>): Promise<FactoryRequirement | undefined>;

  // Bid methods
  createBid(bid: InsertBid): Promise<Bid>;
  getBidById(id: number): Promise<Bid | undefined>;
  getBidsByVendor(vendorId: number): Promise<Bid[]>;
  getBidsByRequirement(requirementId: number): Promise<Bid[]>;
  updateBid(id: number, bid: Partial<Bid>): Promise<Bid | undefined>;

  // Message methods
  createMessage(message: InsertMessage): Promise<Message>;
  getMessageById(id: number): Promise<Message | undefined>;
  getMessagesBetweenUsers(user1Id: number, user2Id: number): Promise<Message[]>;
  getUserUnreadMessageCount(userId: number): Promise<number>;
  markMessageAsRead(id: number): Promise<Message | undefined>;

  // Business type methods
  createBusinessType(businessType: InsertBusinessType): Promise<BusinessType>;
  getBusinessTypeById(id: number): Promise<BusinessType | undefined>;
  getAllBusinessTypes(): Promise<BusinessType[]>;
  getBusinessTypesByFilter(filters: Partial<BusinessType>): Promise<BusinessType[]>;

  // Resource methods
  createResource(resource: InsertResource): Promise<Resource>;
  getResourceById(id: number): Promise<Resource | undefined>;
  getAllResources(): Promise<Resource[]>;
  getResourcesByType(type: string): Promise<Resource[]>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }
  
  // Waste material methods
  async createWasteMaterial(wasteMaterial: InsertWasteMaterial): Promise<WasteMaterial> {
    const [newWasteMaterial] = await db
      .insert(wasteMaterials)
      .values(wasteMaterial)
      .returning();
    return newWasteMaterial;
  }

  async getWasteMaterialById(id: number): Promise<WasteMaterial | undefined> {
    const [material] = await db
      .select()
      .from(wasteMaterials)
      .where(eq(wasteMaterials.id, id));
    return material;
  }

  async getWasteMaterialsByVendor(vendorId: number): Promise<WasteMaterial[]> {
    return db
      .select()
      .from(wasteMaterials)
      .where(eq(wasteMaterials.vendorId, vendorId));
  }

  async getAvailableWasteMaterials(): Promise<WasteMaterial[]> {
    return db
      .select()
      .from(wasteMaterials)
      .where(eq(wasteMaterials.isAvailable, true));
  }

  async getWasteMaterialsByLocation(location: Location, radiusKm: number): Promise<WasteMaterial[]> {
    // This is a simplified approach - in a real app, you would use PostGIS or similar
    // for proper geo queries with radius search
    const materials = await this.getAvailableWasteMaterials();
    return materials.filter(material => {
      if (!material.location) return false;
      return this.calculateDistance(location, material.location as Location) <= radiusKm;
    });
  }

  async updateWasteMaterial(id: number, wasteMaterialData: Partial<WasteMaterial>): Promise<WasteMaterial | undefined> {
    const [updatedMaterial] = await db
      .update(wasteMaterials)
      .set(wasteMaterialData)
      .where(eq(wasteMaterials.id, id))
      .returning();
    return updatedMaterial;
  }

  // Factory requirement methods
  async createFactoryRequirement(requirement: InsertFactoryRequirement): Promise<FactoryRequirement> {
    const [newRequirement] = await db
      .insert(factoryRequirements)
      .values(requirement)
      .returning();
    return newRequirement;
  }

  async getFactoryRequirementById(id: number): Promise<FactoryRequirement | undefined> {
    const [requirement] = await db
      .select()
      .from(factoryRequirements)
      .where(eq(factoryRequirements.id, id));
    return requirement;
  }

  async getFactoryRequirementsByFactory(factoryId: number): Promise<FactoryRequirement[]> {
    return db
      .select()
      .from(factoryRequirements)
      .where(eq(factoryRequirements.factoryId, factoryId));
  }

  async getActiveFactoryRequirements(): Promise<FactoryRequirement[]> {
    return db
      .select()
      .from(factoryRequirements)
      .where(eq(factoryRequirements.isActive, true));
  }

  async getFactoryRequirementsByLocation(location: Location, radiusKm: number): Promise<FactoryRequirement[]> {
    // Similar to waste materials location search
    const requirements = await this.getActiveFactoryRequirements();
    return requirements.filter(req => {
      if (!req.location) return false;
      return this.calculateDistance(location, req.location as Location) <= radiusKm;
    });
  }

  async updateFactoryRequirement(id: number, requirementData: Partial<FactoryRequirement>): Promise<FactoryRequirement | undefined> {
    const [updatedRequirement] = await db
      .update(factoryRequirements)
      .set(requirementData)
      .where(eq(factoryRequirements.id, id))
      .returning();
    return updatedRequirement;
  }

  // Bid methods
  async createBid(bid: InsertBid): Promise<Bid> {
    const [newBid] = await db
      .insert(bids)
      .values(bid)
      .returning();
    return newBid;
  }

  async getBidById(id: number): Promise<Bid | undefined> {
    const [bid] = await db
      .select()
      .from(bids)
      .where(eq(bids.id, id));
    return bid;
  }

  async getBidsByVendor(vendorId: number): Promise<Bid[]> {
    return db
      .select()
      .from(bids)
      .where(eq(bids.vendorId, vendorId));
  }

  async getBidsByRequirement(requirementId: number): Promise<Bid[]> {
    return db
      .select()
      .from(bids)
      .where(eq(bids.requirementId, requirementId));
  }

  async updateBid(id: number, bidData: Partial<Bid>): Promise<Bid | undefined> {
    const [updatedBid] = await db
      .update(bids)
      .set(bidData)
      .where(eq(bids.id, id))
      .returning();
    return updatedBid;
  }

  // Message methods
  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db
      .insert(messages)
      .values(message)
      .returning();
    return newMessage;
  }

  async getMessageById(id: number): Promise<Message | undefined> {
    const [message] = await db
      .select()
      .from(messages)
      .where(eq(messages.id, id));
    return message;
  }

  async getMessagesBetweenUsers(user1Id: number, user2Id: number): Promise<Message[]> {
    return db
      .select()
      .from(messages)
      .where(
        or(
          and(
            eq(messages.senderId, user1Id),
            eq(messages.receiverId, user2Id)
          ),
          and(
            eq(messages.senderId, user2Id),
            eq(messages.receiverId, user1Id)
          )
        )
      )
      .orderBy(messages.createdAt);
  }

  async getUserUnreadMessageCount(userId: number): Promise<number> {
    const result = await db
      .select({ count: sql<number>`count(*)` })
      .from(messages)
      .where(
        and(
          eq(messages.receiverId, userId),
          eq(messages.isRead, false)
        )
      );
    return result[0]?.count || 0;
  }

  async markMessageAsRead(id: number): Promise<Message | undefined> {
    const [updatedMessage] = await db
      .update(messages)
      .set({ isRead: true })
      .where(eq(messages.id, id))
      .returning();
    return updatedMessage;
  }

  // Business type methods
  async createBusinessType(businessType: InsertBusinessType): Promise<BusinessType> {
    const [newBusinessType] = await db
      .insert(businessTypes)
      .values(businessType)
      .returning();
    return newBusinessType;
  }

  async getBusinessTypeById(id: number): Promise<BusinessType | undefined> {
    const [businessType] = await db
      .select()
      .from(businessTypes)
      .where(eq(businessTypes.id, id));
    return businessType;
  }

  async getAllBusinessTypes(): Promise<BusinessType[]> {
    return db.select().from(businessTypes);
  }

  async getBusinessTypesByFilter(filters: Partial<BusinessType>): Promise<BusinessType[]> {
    // For simplicity, we'll just filter by name if provided
    if (filters.name) {
      return db
        .select()
        .from(businessTypes)
        .where(eq(businessTypes.name, filters.name));
    }
    // Otherwise, return all
    return this.getAllBusinessTypes();
  }

  // Resource methods
  async createResource(resource: InsertResource): Promise<Resource> {
    const [newResource] = await db
      .insert(resources)
      .values(resource)
      .returning();
    return newResource;
  }

  async getResourceById(id: number): Promise<Resource | undefined> {
    const [resource] = await db
      .select()
      .from(resources)
      .where(eq(resources.id, id));
    return resource;
  }

  async getAllResources(): Promise<Resource[]> {
    return db.select().from(resources);
  }

  async getResourcesByType(type: string): Promise<Resource[]> {
    return db
      .select()
      .from(resources)
      .where(eq(resources.type, type));
  }

  // Helper method for distance calculation
  private calculateDistance(loc1: Location, loc2: Location): number {
    const earthRadiusKm = 6371;
    const dLat = this.deg2rad(loc2.lat - loc1.lat);
    const dLon = this.deg2rad(loc2.lng - loc1.lng);
    
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(this.deg2rad(loc1.lat)) * Math.cos(this.deg2rad(loc2.lat)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = earthRadiusKm * c;
    
    return distance;
  }
  
  private deg2rad(deg: number): number {
    return deg * (Math.PI/180);
  }
}

export const storage = new DatabaseStorage();