import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { locationSchema, insertUserSchema, insertWasteMaterialSchema, insertFactoryRequirementSchema, insertBidSchema, insertMessageSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  const router = express.Router();
  
  // Error handler middleware
  const handleValidationError = (err: unknown, res: Response) => {
    if (err instanceof ZodError) {
      const validationError = fromZodError(err);
      return res.status(400).json({ error: validationError.message });
    }
    
    console.error("Server error:", err);
    return res.status(500).json({ error: "Internal server error" });
  };

  // User routes
  router.post("/users", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(userData.username);
      
      if (existingUser) {
        return res.status(409).json({ error: "Username already exists" });
      }
      
      const newUser = await storage.createUser(userData);
      res.status(201).json(newUser);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.get("/users/:id", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      res.json(user);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.put("/users/:id", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const userData = req.body;
      
      const updatedUser = await storage.updateUser(userId, userData);
      
      if (!updatedUser) {
        return res.status(404).json({ error: "User not found" });
      }
      
      res.json(updatedUser);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.post("/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ error: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ error: "Invalid username or password" });
      }
      
      res.json({ user });
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  // Waste material routes
  router.post("/waste-materials", async (req: Request, res: Response) => {
    try {
      const wasteMaterialData = insertWasteMaterialSchema.parse(req.body);
      const newWasteMaterial = await storage.createWasteMaterial(wasteMaterialData);
      res.status(201).json(newWasteMaterial);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.get("/waste-materials", async (req: Request, res: Response) => {
    try {
      const { vendorId, lat, lng, radius } = req.query;
      
      if (vendorId) {
        const materials = await storage.getWasteMaterialsByVendor(parseInt(vendorId as string));
        return res.json(materials);
      }
      
      if (lat && lng && radius) {
        const location = locationSchema.parse({
          lat: parseFloat(lat as string),
          lng: parseFloat(lng as string)
        });
        
        const radiusKm = parseFloat(radius as string);
        const materials = await storage.getWasteMaterialsByLocation(location, radiusKm);
        return res.json(materials);
      }
      
      const materials = await storage.getAvailableWasteMaterials();
      res.json(materials);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.get("/waste-materials/:id", async (req: Request, res: Response) => {
    try {
      const materialId = parseInt(req.params.id);
      const material = await storage.getWasteMaterialById(materialId);
      
      if (!material) {
        return res.status(404).json({ error: "Waste material not found" });
      }
      
      res.json(material);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.put("/waste-materials/:id", async (req: Request, res: Response) => {
    try {
      const materialId = parseInt(req.params.id);
      const materialData = req.body;
      
      const updatedMaterial = await storage.updateWasteMaterial(materialId, materialData);
      
      if (!updatedMaterial) {
        return res.status(404).json({ error: "Waste material not found" });
      }
      
      res.json(updatedMaterial);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  // Factory requirement routes
  router.post("/factory-requirements", async (req: Request, res: Response) => {
    try {
      const requirementData = insertFactoryRequirementSchema.parse(req.body);
      const newRequirement = await storage.createFactoryRequirement(requirementData);
      res.status(201).json(newRequirement);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.get("/factory-requirements", async (req: Request, res: Response) => {
    try {
      const { factoryId, lat, lng, radius } = req.query;
      
      if (factoryId) {
        const requirements = await storage.getFactoryRequirementsByFactory(parseInt(factoryId as string));
        return res.json(requirements);
      }
      
      if (lat && lng && radius) {
        const location = locationSchema.parse({
          lat: parseFloat(lat as string),
          lng: parseFloat(lng as string)
        });
        
        const radiusKm = parseFloat(radius as string);
        const requirements = await storage.getFactoryRequirementsByLocation(location, radiusKm);
        return res.json(requirements);
      }
      
      const requirements = await storage.getActiveFactoryRequirements();
      res.json(requirements);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.get("/factory-requirements/:id", async (req: Request, res: Response) => {
    try {
      const requirementId = parseInt(req.params.id);
      const requirement = await storage.getFactoryRequirementById(requirementId);
      
      if (!requirement) {
        return res.status(404).json({ error: "Factory requirement not found" });
      }
      
      res.json(requirement);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.put("/factory-requirements/:id", async (req: Request, res: Response) => {
    try {
      const requirementId = parseInt(req.params.id);
      const requirementData = req.body;
      
      const updatedRequirement = await storage.updateFactoryRequirement(requirementId, requirementData);
      
      if (!updatedRequirement) {
        return res.status(404).json({ error: "Factory requirement not found" });
      }
      
      res.json(updatedRequirement);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  // Bid routes
  router.post("/bids", async (req: Request, res: Response) => {
    try {
      const bidData = insertBidSchema.parse(req.body);
      const newBid = await storage.createBid(bidData);
      res.status(201).json(newBid);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.get("/bids", async (req: Request, res: Response) => {
    try {
      const { vendorId, requirementId } = req.query;
      
      if (vendorId) {
        const bids = await storage.getBidsByVendor(parseInt(vendorId as string));
        return res.json(bids);
      }
      
      if (requirementId) {
        const bids = await storage.getBidsByRequirement(parseInt(requirementId as string));
        return res.json(bids);
      }
      
      res.status(400).json({ error: "Vendor ID or requirement ID is required" });
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.get("/bids/:id", async (req: Request, res: Response) => {
    try {
      const bidId = parseInt(req.params.id);
      const bid = await storage.getBidById(bidId);
      
      if (!bid) {
        return res.status(404).json({ error: "Bid not found" });
      }
      
      res.json(bid);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.put("/bids/:id", async (req: Request, res: Response) => {
    try {
      const bidId = parseInt(req.params.id);
      const bidData = req.body;
      
      const updatedBid = await storage.updateBid(bidId, bidData);
      
      if (!updatedBid) {
        return res.status(404).json({ error: "Bid not found" });
      }
      
      res.json(updatedBid);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  // Message routes
  router.post("/messages", async (req: Request, res: Response) => {
    try {
      const messageData = insertMessageSchema.parse(req.body);
      const newMessage = await storage.createMessage(messageData);
      res.status(201).json(newMessage);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.get("/messages", async (req: Request, res: Response) => {
    try {
      const { user1Id, user2Id } = req.query;
      
      if (!user1Id || !user2Id) {
        return res.status(400).json({ error: "Both user IDs are required" });
      }
      
      const messages = await storage.getMessagesBetweenUsers(
        parseInt(user1Id as string),
        parseInt(user2Id as string)
      );
      
      res.json(messages);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.get("/users/:userId/unread-messages", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const count = await storage.getUserUnreadMessageCount(userId);
      res.json({ count });
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.post("/messages/:id/read", async (req: Request, res: Response) => {
    try {
      const messageId = parseInt(req.params.id);
      const updatedMessage = await storage.markMessageAsRead(messageId);
      
      if (!updatedMessage) {
        return res.status(404).json({ error: "Message not found" });
      }
      
      res.json(updatedMessage);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  // Business type routes
  router.get("/business-types", async (req: Request, res: Response) => {
    try {
      const allBusinessTypes = await storage.getAllBusinessTypes();
      res.json(allBusinessTypes);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.get("/business-types/:id", async (req: Request, res: Response) => {
    try {
      const businessTypeId = parseInt(req.params.id);
      const businessType = await storage.getBusinessTypeById(businessTypeId);
      
      if (!businessType) {
        return res.status(404).json({ error: "Business type not found" });
      }
      
      res.json(businessType);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.get("/business-types/filter", async (req: Request, res: Response) => {
    try {
      const filters = req.query;
      const filteredBusinessTypes = await storage.getBusinessTypesByFilter(filters);
      res.json(filteredBusinessTypes);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  // Resource routes
  router.get("/resources", async (req: Request, res: Response) => {
    try {
      const { type } = req.query;
      
      if (type) {
        const resources = await storage.getResourcesByType(type as string);
        return res.json(resources);
      }
      
      const allResources = await storage.getAllResources();
      res.json(allResources);
    } catch (err) {
      handleValidationError(err, res);
    }
  });

  router.get("/resources/:id", async (req: Request, res: Response) => {
    try {
      const resourceId = parseInt(req.params.id);
      const resource = await storage.getResourceById(resourceId);
      
      if (!resource) {
        return res.status(404).json({ error: "Resource not found" });
      }
      
      res.json(resource);
    } catch (err) {
      handleValidationError(err, res);
    }
  });
  
  // Register the API router with the /api prefix
  app.use("/api", router);

  const httpServer = createServer(app);
  return httpServer;
}
