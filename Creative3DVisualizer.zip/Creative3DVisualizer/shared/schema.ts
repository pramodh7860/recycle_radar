import { pgTable, text, serial, integer, boolean, timestamp, jsonb, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
import { z } from "zod";

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  userType: text("user_type").notNull(), // "vendor", "factory", "entrepreneur"
  phoneNumber: text("phone_number"),
  preferredLanguage: text("preferred_language").default("en"),
  location: jsonb("location"), // { lat: number, lng: number, address: string }
  createdAt: timestamp("created_at").defaultNow(),
});

// Define user relations
export const usersRelations = relations(users, ({ many }) => ({
  wasteMaterials: many(wasteMaterials),
  factoryRequirements: many(factoryRequirements),
  bidsAsVendor: many(bids, { relationName: "vendorBids" }),
  sentMessages: many(messages, { relationName: "sentMessages" }),
  receivedMessages: many(messages, { relationName: "receivedMessages" }),
}));

// Waste materials
export const wasteMaterials = pgTable("waste_materials", {
  id: serial("id").primaryKey(),
  vendorId: integer("vendor_id").notNull().references(() => users.id),
  materialType: text("material_type").notNull(), // plastic, paper, metal, etc.
  subType: text("sub_type"), // HDPE, PET, etc.
  quantity: integer("quantity").notNull(), // in kilograms
  price: integer("price"), // price per kg in rupees
  description: text("description"),
  imageUrl: text("image_url"),
  voiceNoteUrl: text("voice_note_url"),
  location: jsonb("location"), // { lat: number, lng: number, address: string }
  isAvailable: boolean("is_available").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Define waste materials relations
export const wasteMaterialsRelations = relations(wasteMaterials, ({ one }) => ({
  vendor: one(users, {
    fields: [wasteMaterials.vendorId],
    references: [users.id],
  }),
}));

// Factory requirements
export const factoryRequirements = pgTable("factory_requirements", {
  id: serial("id").primaryKey(),
  factoryId: integer("factory_id").notNull().references(() => users.id),
  materialType: text("material_type").notNull(),
  subType: text("sub_type"),
  quantityNeeded: integer("quantity_needed").notNull(), // in kilograms
  priceOffered: integer("price_offered").notNull(), // per kg in rupees
  description: text("description"),
  deadline: timestamp("deadline"),
  location: jsonb("location"), // { lat: number, lng: number, address: string }
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Define factory requirements relations
export const factoryRequirementsRelations = relations(factoryRequirements, ({ one, many }) => ({
  factory: one(users, {
    fields: [factoryRequirements.factoryId],
    references: [users.id],
  }),
  bids: many(bids),
}));

// Bids (from vendors to factories)
export const bids = pgTable("bids", {
  id: serial("id").primaryKey(),
  vendorId: integer("vendor_id").notNull().references(() => users.id),
  requirementId: integer("requirement_id").notNull().references(() => factoryRequirements.id),
  quantity: integer("quantity").notNull(),
  pricePerKg: integer("price_per_kg").notNull(),
  message: text("message"),
  status: text("status").default("pending"), // pending, accepted, rejected
  createdAt: timestamp("created_at").defaultNow(),
});

// Define bids relations
export const bidsRelations = relations(bids, ({ one }) => ({
  vendor: one(users, {
    fields: [bids.vendorId],
    references: [users.id],
    relationName: "vendorBids",
  }),
  requirement: one(factoryRequirements, {
    fields: [bids.requirementId],
    references: [factoryRequirements.id],
  }),
}));

// Messages between users
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").notNull().references(() => users.id),
  receiverId: integer("receiver_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  isRead: boolean("is_read").default(false),
});

// Define messages relations
export const messagesRelations = relations(messages, ({ one }) => ({
  sender: one(users, {
    fields: [messages.senderId],
    references: [users.id],
    relationName: "sentMessages",
  }),
  receiver: one(users, {
    fields: [messages.receiverId],
    references: [users.id],
    relationName: "receivedMessages",
  }),
}));

// Business types for entrepreneurs
export const businessTypes = pgTable("business_types", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  minInvestment: integer("min_investment"), // in rupees
  maxInvestment: integer("max_investment"), // in rupees
  minLandRequired: integer("min_land_required"), // in sq meters
  processingCapacity: integer("processing_capacity"), // in kg per day
  licenseRequired: jsonb("license_required").default([]), // array of licenses
  subsidies: jsonb("subsidies").default([]), // array of eligible subsidies
  roiMonths: integer("roi_months"), // estimated return on investment in months
});

// Resources for entrepreneurs
export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  type: text("type").notNull(), // workshop, guide, directory, mentorship
  url: text("url"),
  thumbnailUrl: text("thumbnail_url"),
  details: jsonb("details"), // additional details like duration, pages, etc.
});

// Location coordinate type
export const locationSchema = z.object({
  lat: z.number(),
  lng: z.number(),
  address: z.string().optional(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertWasteMaterialSchema = createInsertSchema(wasteMaterials).omit({ id: true, createdAt: true });
export const insertFactoryRequirementSchema = createInsertSchema(factoryRequirements).omit({ id: true, createdAt: true });
export const insertBidSchema = createInsertSchema(bids).omit({ id: true, createdAt: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, createdAt: true });
export const insertBusinessTypeSchema = createInsertSchema(businessTypes).omit({ id: true });
export const insertResourceSchema = createInsertSchema(resources).omit({ id: true });

// Types
export type User = typeof users.$inferSelect;
export type WasteMaterial = typeof wasteMaterials.$inferSelect;
export type FactoryRequirement = typeof factoryRequirements.$inferSelect;
export type Bid = typeof bids.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type BusinessType = typeof businessTypes.$inferSelect;
export type Resource = typeof resources.$inferSelect;
export type Location = z.infer<typeof locationSchema>;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertWasteMaterial = z.infer<typeof insertWasteMaterialSchema>;
export type InsertFactoryRequirement = z.infer<typeof insertFactoryRequirementSchema>;
export type InsertBid = z.infer<typeof insertBidSchema>;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type InsertBusinessType = z.infer<typeof insertBusinessTypeSchema>;
export type InsertResource = z.infer<typeof insertResourceSchema>;
